<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
/*
Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();


});
*/
Route::Post('/register','authApiController@register')->name('register');
Route::Post('/login','authApiController@login')->name('login');
Route::Post('/logout','authApiController@logout')->middleware('auth:api');
Route::Post('/resetpassword','authApiController@resetpassword')->middleware('auth:api');
Route::Post('/forgetpassword','authApiController@forgetpassword')->name('forgetpassword');
Route::Post('/resendVerifiedEmail','authApiController@resendVerifiedEmail')->name('resendVerifiedEmail');
Route::Post('/KeepLogin','UserController@KeepLogin')->name('KeepLogin');


// Patient Routes
Route::prefix('patient')->group(function(){
  Route::Get('/','PatientController@show')->name('showpatient');  // view patient account
  Route::Post('/edit','PatientController@edit')->name('editpatient');
  Route::GET('/getdata','PatientController@get_patient_from_request')->name('getpatientdata');
});

Route::Post('/arrived','PatientController@arrived')->name('arrived');

Route::prefix('secretary')->group(function(){
  Route::Post('/edit','SecretaryController@edit')->name('editsecretary');
});

Route::get('/allspeciality','SpecialtiesController@specialities_func')->name('specialities');
//Route::post('/addspeciality','MedicalProvider@addspeciality')->name('addspeciality');
Route::get('/allservices','ServicesController@services_func')->name('services');
//Route::post('/addservices','MedicalProvider@addservices')->name('addservices');

Route::Post('/doctor/edit','DoctorController@edit')->name('editdoctor');
Route::Post('/hospital/profile/edit','MedicalProviderController@edithospital')->name('edit_hospital_profile');
Route::Post('/clinic/profile/edit','MedicalProviderController@editclinic')->name('edit_clinic_profile');

Route::get('/requests',"RequestController@ViewRequests")->name("list_requests");
Route::get('/requests/medicalproviderinfo',"RequestController@medicalProviderInfo")->name("medical_provider_info");

Route::get('/regions','RegionController@index')->name('regions');
Route::get('/governrates','GovernrateController@index')->name('governrates');
Route::get('/jobtitles','JobtitleController@index')->name('jobtitles');


Route::Get('/lang/{local}','LangController@setLang')->name('set_lang');
Route::Post('/uploadimage','UserController@uploadimage')->name('uploadimage');
Route::Get('/getnotifications','NotificationController@getnotifiactions')->name('get_notifiactions');
Route::Get('/readnotifiactions','NotificationController@readnotifiactions')->name('read_notifiactions');

Route::Post('/addrequest','RequestController@addrequest')->name('addrequest');
Route::Post('/addbulkrequest','RequestController@addbulkrequest')->name('addbulkrequest');
Route::Post('/searchdoctors','DoctorController@search')->name('search_doctors');

Route::Post('/respondrequest','RequestController@respondrequest')->name('respond_request');

Route::Post('/addreview','ReviewController@addreview')->name('add_review');

Route::Get('/page/{slug}','StaticPagesController@getpage')->name('get_page');
Route::Get('/terms/{slug}','TermsController@getTerms')->name('get_Terms');
Route::Get('/medicalProvider/fetch','MedicalProviderController@fetchMedicalProvider')->name('fetch_medical_provider');
Route::Get('/medicalProvider/breif','MedicalProviderController@fetchMedicalProviderInfo')->name('fetch_medical_provider_brief');
Route::post('/medicalProvider/setLoction','MedicalProviderController@setLoction')->name('set_loction');
Route::get('/medicalProvider/getLoction','MedicalProviderController@getLoction')->name('get_loction');
Route::get('/getPlans','SubscriptionPlansController@subscriptionPlans')->name('get_plans');
Route::get('/getPlan/{id}','SubscriptionPlansController@subscriptionPlan')->name('get_plan');

Route::post('/addSubscriptionOrder','SubscriptionPlansController@subscriptionOrder')->name('subscription_order');
Route::post('/addSubscriptionOrderPay','SubscriptionPlansController@subscriptionOrderPay')->name('subscription_order_pay');

Route::get('/userSubscriptionOrders','SubscriptionPlansController@getUsersSubscriptionOrders')->name('subscription_order');
Route::get('/loginAds','SubscriptionPlansController@loginAds')->name('login.ads');
Route::Post('/doctor/dashboard','DoctorController@apiDashboard')->name('doctor.dashboard');
Route::Post('/medicalProvider/dashboard','MedicalProviderController@apiDashboard')->name('medicalProvider.dashboard');
Route::Post('/secretary/dashboard','SecretaryController@apiDashboard')->name('secretary.dashboard');
Route::Post('/privateReservations/dashboard','SecretaryController@apiDashboardPrivateReservation')->name('privateReservation.dashboard');
Route::Post('/patient/dashboard','PatientController@apiDashboard')->name('patient.dashboard');
Route::get('/doctor/pendingRequests','DoctorController@pendingRequests')->name('doctor.pendingRequests');
Route::get('/medicalProvider/pendingRequests','MedicalProviderController@pendingRequests')->name('medicalProvider.pendingRequests');
Route::get('/secretary/pendingRequests','SecretaryController@pendingRequests')->name('secretary.pendingRequests');
Route::get('/privateReservations/pendingRequests','SecretaryController@pendingPrivateReservation')->name('PrivateReservation.pendingRequests');
Route::get('/patient/pendingRequests','PatientController@pendingRequests')->name('patient.pendingRequests');












