<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function(){
    return redirect('admin');
});

Route::get('/admin/medical-providers/medicalSearch','MedicalProviderVoyagerController@medicalSearch')->name('medical.search');
Route::get('/admin/doctors/doctorSearch','DoctorVoyagerController@doctorSearch')->name('doctor.search');
Route::get('/admin/patients/patientSearch','patientVoyagerController@patientSearch')->name('patient.search');
Route::get('/admin/requests/requestSearch','requestVoyagerController@requestSearch')->name('request.search');
Route::get('/admin/userstable/adminSearch','userVoyagerController@adminSearch')->name('admin.search');
Route::get('/admin/governrates/governrateSearch','governerateVoyagerController@governrateSearch')->name('governrate.search');
Route::get('/admin/regions/regionSearch','regionVoyagerController@regionSearch')->name('region.search');
Route::get('/admin/specialties/specialtySearch','specialityVoyagerController@specialtySearch')->name('specialty.search');
Route::get('/admin/services/serviceSearch','serviceVoyagerController@serviceSearch')->name('service.search');
Route::get('/admin/jobtitles/jobtitleSearch','jobtitleVoyagerController@jobtitleSearch')->name('jobtitle.search');
Route::get('/admin/secretaries/secretarySearch','SecretaryVoyagerController@secretarySearch')->name('secretary.search');
Route::get('/admin/subscription-plans/subscribers','SubscriptionPlanVoyagerController@subscribersInfo')->name('subscribers.info');
Route::post('/admin/subscription-plans/editOrderImage','SubscriptionPlanVoyagerController@editOrderImage')->name('edit.order.image');
Route::get('/admin/private-reservations/privateReservationSearch','PrivateReservationVoyagerController@privateReservationSearch')->name('privateReservation.search');
Route::get('/admin/user/resendVerifiedEmail','userVoyagerController@resendVerifiedEmail')->name('user.resend.verified.email');


Route::group(['prefix' => 'admin'], function () {
    Voyager::routes();
    // Your overwrites here
    Route::get('/medical-providers/medicalSearch','MedicalProviderVoyagerController@medicalSearch')->name('medical.search');

    Route::post('login', ['uses' => 'AuthController@postLogin', 'as' => 'postlogin']);

    Route::any('{table}/deactivategovernrates', ['uses' => 'ActivationController@deactivate', 'as' => 'voyager.governrates.deactivate']);
    Route::any('{table}/activategovernrates', ['uses' => 'ActivationController@activate', 'as' => 'voyager.governrates.activate']);

    Route::any('{table}/deactivateregions', ['uses' => 'ActivationController@deactivate', 'as' => 'voyager.regions.deactivate']);
    Route::any('{table}/activateregions', ['uses' => 'ActivationController@activate', 'as' => 'voyager.regions.activate']);

    Route::any('{table}/deactivateservices', ['uses' => 'ActivationController@deactivate', 'as' => 'voyager.services.deactivate']);
    Route::any('{table}/activateservices', ['uses' => 'ActivationController@activate', 'as' => 'voyager.services.activate']);

    Route::any('{table}/deactivatespecialties', ['uses' => 'ActivationController@deactivate', 'as' => 'voyager.specialties.deactivate']);
    Route::any('{table}/activatespecialties', ['uses' => 'ActivationController@activate', 'as' => 'voyager.specialties.activate']);

    Route::any('{table}/deactivaterequests', ['uses' => 'ActivationController@deactivate', 'as' => 'voyager.requests.deactivate']);
    Route::any('{table}/activaterequests', ['uses' => 'ActivationController@activate', 'as' => 'voyager.requests.activate']);

    Route::any('{table}/deactivateadvertise', ['uses' => 'ActivationController@deactivateadvertise', 'as' => 'voyager.subscription-plans.deactivate']);
    Route::any('{table}/activateadvertise', ['uses' => 'ActivationController@activateadvertise', 'as' => 'voyager.subscription-plans.activate']);

    Route::any('{table}/deactivateadmin', ['uses' => 'ActivationController@deactivate', 'as' => 'voyager.userstable.deactivate']);
    Route::any('{table}/activateadmin', ['uses' => 'ActivationController@activate', 'as' => 'voyager.userstable.activate']);

    Route::any('{table}/deactivatepatient', ['uses' => 'ActivationController@deactivatepatient', 'as' => 'voyager.patients.deactivate']);
    Route::any('{table}/activatepatient', ['uses' => 'ActivationController@activatepatient', 'as' => 'voyager.patients.activate']);

    Route::any('{table}/deactivatesecretary', ['uses' => 'ActivationController@deactivatesecretary', 'as' => 'voyager.secretaries.deactivate']);
    Route::any('{table}/activatesecretary', ['uses' => 'ActivationController@activatesecretary', 'as' => 'voyager.secretaries.activate']);

    Route::any('{table}/deactivatemedical', ['uses' => 'ActivationController@deactivatemedical', 'as' => 'voyager.medical-providers.deactivate']);
    Route::any('{table}/activatemedical', ['uses' => 'ActivationController@activatemedical', 'as' => 'voyager.medical-providers.activate']);

    Route::any('{table}/deactivaterequest', ['uses' => 'ActivationController@deactivate', 'as' => 'voyager.requests.deactivate']);
    Route::any('{table}/activaterequest', ['uses' => 'ActivationController@activate', 'as' => 'voyager.requests.activate']);
});


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/resetEmail', 'HomeController@resetEmail')->name('resetEmail');
Route::get('/verifyemail/{token}', 'VerifiedEmailController@verifyEmail')->name('home');

Route::post('/doctorDelete', 'DoctorVoyagerController@deleteDoctor')->name('deleteDoctor');
Route::get('/doctorDelete/{id}','DoctorVoyagerController@delete_single')->name('delete_single_doctor');

Route::get("/patientindex","patientVoyagerController@index")->name("patientindex");
Route::post('/patientsDelete', 'patientVoyagerController@Deletepatient')->name('Deletepatient');
Route::get('/patientDelete/{id}', 'patientVoyagerController@delete_single')->name('delete_single');
Route::post('/medicalsDelete', 'MedicalProviderVoyagerController@Deletemedical')->name('Deletemedical');
Route::get('/medicalDelete/{id}', 'MedicalProviderVoyagerController@delete_single')->name('delete_single_medical');
Route::post('/secretaryDelete', 'SecretaryVoyagerController@Deletesecretary')->name('Deletesecretary');
Route::get('/secretaryDelete/{id}', 'SecretaryVoyagerController@delete_single')->name('delete_single_secretary');
Route::post('/joptitleDelete', 'jobtitleVoyagerController@Deletejobtitles')->name('Deletejop');
Route::get('/joptitleDelete/{id}','jobtitleVoyagerController@delete_single')->name('delete_single_jop');
Route::post('/staticpagesDelete', 'StaticPageVoyagerController@Deletepage')->name('Deletepage');
Route::get('/staticpagesDelete/{id}','StaticPageVoyagerController@delete_single')->name('delete_single_page');
Route::post('/adminDelete', 'userVoyagerController@Deleteadmin')->name('Deleteadmin');
Route::get('/adminDelete/{id}','userVoyagerController@delete_single')->name('delete_single_admin');
Route::post('/requestDelete', 'requestVoyagerController@DeleteRequest')->name('Deleterequest');
Route::get('/requestDelete/{id}','requestVoyagerController@delete_single')->name('delete_single_request');

Route::get('/showRequest','requestVoyagerController@selectDoctor')->name('SelectDoctors');
Route::get('/selectDoctor','requestVoyagerController@selectDoctor')->name('SelectService');

Route::post('/autocomplete/fetch', 'requestVoyagerController@fetch')->name('fetch');
Route::get('/admin/requests/{id}', 'requestVoyagerController@indexsearch')->name('indexsearch');
Route::post('/autocomplete/fetchdate', 'requestVoyagerController@fetchdate')->name('fetchdate');

Route::get('requests/create','requestVoyagerController@filter_search')->name('filter_search');
Route::get('governrates/create','governerateVoyagerController@paginate_region')->name('paginate_regions');
Route::get('secretaries/create','SecretaryVoyagerController@paginate_doctor')->name('paginate_doctors');
Route::get('medical-providers/create','MedicalProviderVoyagerController@filter_search')->name('paginate_medical');
Route::get('medical-providers/searchServices','MedicalProviderVoyagerController@filter_search_services')->name('paginate_services');
Route::get('medical-providers/searchGovernrates','MedicalProviderVoyagerController@filter_search_governrates')->name('paginate_governrates');
Route::get('/medical-providers/deleteService','MedicalProviderVoyagerController@deleteService')->name('delete_service');
Route::get('/medical-providers/deleteSpecialtiy','MedicalProviderVoyagerController@deleteSpecialtiy')->name('delete_specialtiy');
Route::get('doctors/create','DoctorVoyagerController@filter_search')->name('paginate_for_doctors');
Route::get('private-reservations/create','PrivateReservationVoyagerController@filter_search')->name('paginate_private_reservation');
Route::get('/userstable/create','userVoyagerController@filter_search')->name('paginate_roles');
Route::get('/checkifhad','PrivateReservationVoyagerController@hadPrivate')->name('had_private');
Route::get('/admin/requestsdate/{date}', 'requestVoyagerController@indexsearchdate')->name('indexsearchdate');
Route::post('/doctorPrivateReservations', 'PrivateReservationVoyagerController@deletePrivateReservation')->name('deletePrivateReservation');
Route::get('/doctorPrivateReservation/{id}','PrivateReservationVoyagerController@delete_single')->name('delete_single_private_reservation');
Route::post('/medicalproviderSpecialties','PrivateReservationVoyagerController@medicalproviderSpecialties')->name('medicalproviderSpecialties');
Route::post('/doctorGovernrate', 'governerateVoyagerController@deleteGovernrates')->name('deleteGovernrate');
Route::get('/doctorGovernrate/{id}','governerateVoyagerController@delete_single')->name('delete_single_governrate');
Route::get('/joptitleDeactivate/{id}','jobtitleVoyagerController@joptitleDeactivate')->name('deactivate_single_job');
Route::get('/joptitleActivate/{id}','jobtitleVoyagerController@joptitleActivate')->name('activate_single_job');
Route::get('/staticpageDeactivate/{id}','StaticPageVoyagerController@staticPageDeactivate')->name('deactivate_static_page');
Route::get('/staticpageActivate/{id}','StaticPageVoyagerController@staticPageActivate')->name('activate_static_page');
Route::get('/doctorDeactivate/{id}','DoctorVoyagerController@doctorDeactivate')->name('deactivate_doctor');
Route::get('/doctorActivate/{id}','DoctorVoyagerController@doctorActivate')->name('activate_doctor');
Route::get('/privateReservationActivate/{id}','PrivateReservationVoyagerController@privateReservationDeactivate')->name('deactivate_private_reservation');
Route::get('/PrivateReservationDeactivate/{id}','PrivateReservationVoyagerController@privateReservationActivate')->name('activate_private_reservation');
Route::get('/admin/userProfile', 'userVoyagerController@userProfile');
Route::redirect('admin/profile' , '/admin/userProfile');
Route::redirect('/login' , '/admin/login');
Route::redirect('/register' , '/admin/login');
//Route::redirect('/password/reset' , '/admin/login');

