<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMedicalProviderSpecialtyHasServicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('medical_provider_specialty_has_services', function (Blueprint $table) {
          $table->unsignedInteger('medical_provider_has_speciality_id');
          //$table->foreign('medical_provider_id')->references('id')->on('medical_providers');
          $table->unsignedInteger('service_id');
          //$table->foreign('service_id')->references('id')->on('services');
          $table->unsignedInteger('price');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('medical_provider_specialty_has_services');
    }
}
