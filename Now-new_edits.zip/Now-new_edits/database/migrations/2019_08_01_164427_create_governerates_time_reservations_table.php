<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGoverneratesTimeReservationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('governerates_time_reservations', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('medical_provider_id');
            $table->foreign('medical_provider_id')->references('id')->on('medical_providers');
            
            $table->unsignedInteger('governrate_id');
            $table->foreign('governrate_id')->references('id')->on('governrates');
            
            $table->unsignedInteger('subscription_order_id');
            $table->foreign('subscription_order_id')->references('id')->on('subscription_orders');
            

            $table->unsignedInteger('from');
            $table->unsignedInteger('to');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('governerates_time_reservations');
    }
}
