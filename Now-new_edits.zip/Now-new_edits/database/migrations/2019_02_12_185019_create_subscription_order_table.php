<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSubscriptionOrderTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('subscription_orders', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('medical_provider_id');
            $table->foreign('medical_provider_id')->references('id')->on('medical_providers');
            $table->unsignedInteger('subscription_plan_id');
            $table->foreign('subscription_plan_id')->references('id')->on('subscription_plans');
            $table->float('amount');
            $table->json('order_meta')->nullable();
            $table->integer('counter')->default(0);
            $table->string('reference_number');
            $table->enum('status',['Active','Expired'])->default('Active');
            $table->integer('disabled')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('subscription_orders');
    }
}
