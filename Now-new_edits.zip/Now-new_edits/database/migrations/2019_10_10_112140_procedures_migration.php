<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
class ProceduresMigration extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $procedure_search_bulk="
        CREATE DEFINER=`root`@`localhost` PROCEDURE `search_bulk`(
          IN service_id INTEGER,
          IN user_id INTEGER,
          IN doc_name VARCHAR(255) CHARSET utf8,
          IN speciality_id INTEGER,
          IN jobtitle_id VARCHAR(255),
          IN region_id VARCHAR(255),
          IN governrate_id VARCHAR(255),
          IN min_price INTEGER,
          IN max_price INTEGER

        )
        BEGIN


              Select distinct
              doctors.id AS doctor_id,
              medical_providers.id AS provider_id
              From doctors

              LEFT JOIN users AS doctor_user ON doctor_user.id=doctors.user_id
              LEFT JOIN doctor_has_medical_provider ON doctor_has_medical_provider.doctor_id=doctors.id
              LEFT JOIN medical_providers ON medical_providers.id=doctor_has_medical_provider.medical_provider_id
              LEFT JOIN users AS medical_provider_user ON medical_provider_user.id=medical_providers.user_id
              LEFT JOIN governrates ON governrates.id=medical_providers.governrate_id
              LEFT JOIN regions ON regions.id=governrates.region_id
              LEFT JOIN medical_provider_has_specialties ON (medical_provider_has_specialties.medical_provider_id=medical_providers.id )
              LEFT JOIN medical_provider_specialty_has_services ON medical_provider_specialty_has_services.medical_provider_has_speciality_id=medical_provider_has_specialties.id
              LEFT JOIN patients ON patients.user_id=user_id
              LEFT JOIN requests ON (requests.doctor_id=doctors.id AND requests.medical_provider_id=medical_providers.id AND requests.status!=\"Request\" AND requests.status!=\"Approve\" AND requests.patient_id=patients.id)
              LEFT JOIN specialties ON specialties.id=doctors.speciality_id
              LEFT JOIN services ON (services.id=service_id)
              LEFT JOIN jobtitles ON jobtitles.id=doctors.jobtitle
              LEFT JOIN subscription_orders ON subscription_orders.medical_provider_id=medical_providers.id AND subscription_orders.status=\"Active\" AND subscription_orders.subscription_plan_id=1

              WHERE

              (doctor_user.fullname LIKE doc_name OR doctor_user.fullname_en LIKE doc_name)
              AND
              medical_provider_has_specialties.speciality_id=speciality_id
              AND
              specialties.id=speciality_id
              AND
              doctors.jobtitle like jobtitle_id
              AND
              regions.id like region_id
              AND
              governrates.id like governrate_id
              AND
              medical_provider_specialty_has_services.service_id=service_id
              AND
              medical_provider_specialty_has_services.price>=min_price
              AND
              medical_provider_specialty_has_services.price<=max_price
              AND
        doctor_user.verified=1
        AND
        medical_provider_user.verified=1
              AND governrates.deleted_at IS NULL AND governrates.disabled=0
              AND regions.deleted_at IS NULL AND regions.disabled=0
              AND specialties.deleted_at IS NULL AND specialties.disabled=0
              AND services.deleted_at IS NULL AND services.disabled=0
              AND jobtitles.deleted_at IS NULL AND jobtitles.disabled=0
              AND medical_provider_user.deleted_at IS NULL AND medical_provider_user.disabled=0
              AND doctor_user.deleted_at IS NULL AND doctor_user.disabled=0

          ;


        END
        ";

        $procedure_search_detailed="
        CREATE DEFINER=`root`@`localhost` PROCEDURE `search_detailed`(
          IN service_id VARCHAR(255),
          IN user_id INTEGER,
          IN doc_name VARCHAR(255) CHARSET utf8,
          IN medical_name VARCHAR(255) CHARSET utf8,
          IN speciality_id VARCHAR(255),
          IN jobtitle_id VARCHAR(255),
          IN region_id VARCHAR(255),
          IN governrate_id VARCHAR(255),
          IN min_price INTEGER,
          IN max_price INTEGER,
          IN start_offset INTEGER,
          IN results_per_page INTEGER,
          IN lang VARCHAR(5),
          IN base_url VARCHAR(255)
        )
BEGIN


        Select distinct
        doctors.id AS doctor_id,
        medical_providers.id AS provider_id,
        IF(lang='en',doctor_user.fullname_en,doctor_user.fullname) AS doctor_name,
        CONCAT(base_url,'/',doctor_user.avatar) AS doctor_img,
        doctors.speciality_id AS specialty_id,
        IF(lang='en',specialties.name_en,specialties.name_ar) AS doctor_specialty,
        IF(lang='en',jobtitles.name_en,jobtitles.name_ar) AS doctor_jobtitle,
        IF(lang='en',regions.name_en,regions.name_ar) AS provieder_region,
        IF(lang='en',governrates.name_en,governrates.name_ar) AS provider_governerate,
        IF(lang='en',medical_provider_user.fullname_en,medical_provider_user.fullname) AS provider_name,

        (SELECT FORMAT(SUM(reviews.rating)/COUNT(reviews.rating),1) FROM reviews WHERE reviews.doctor_id=doctors.id ) AS doctor_rate,
        (SELECT COUNT(reviews.rating) FROM reviews WHERE reviews.doctor_id=doctors.id ) AS doctor_rate_amount,
        ( CASE WHEN subscription_orders.status='Active' THEN true ELSE false END) AS ad,
        services.id AS service_id,
        IF(lang='en',services.name_en,services.name_ar) AS provider_service,
        medical_provider_specialty_has_services.price AS service_price,
        requests.status AS request_status,
        subscription_orders.amount AS order_amount

        From doctors

        LEFT JOIN users AS doctor_user ON doctor_user.id=doctors.user_id
        LEFT JOIN doctor_has_medical_provider ON doctor_has_medical_provider.doctor_id=doctors.id
        LEFT JOIN medical_providers ON medical_providers.id=doctor_has_medical_provider.medical_provider_id
        LEFT JOIN users AS medical_provider_user ON medical_provider_user.id=medical_providers.user_id
        LEFT JOIN governrates ON governrates.id=medical_providers.governrate_id
        LEFT JOIN regions ON regions.id=governrates.region_id
        LEFT JOIN medical_provider_has_specialties ON (medical_provider_has_specialties.medical_provider_id=medical_providers.id AND doctors.speciality_id = medical_provider_has_specialties.speciality_id)
        LEFT JOIN medical_provider_specialty_has_services ON medical_provider_specialty_has_services.medical_provider_has_speciality_id=medical_provider_has_specialties.id
        LEFT JOIN patients ON patients.user_id=user_id
        LEFT JOIN specialties ON specialties.id=doctors.speciality_id
        LEFT JOIN services ON (services.id = medical_provider_specialty_has_services.service_id)
        LEFT JOIN requests ON (requests.doctor_id=doctors.id AND requests.medical_provider_id=medical_providers.id AND  requests.patient_id=patients.id AND requests.service_id=services.id AND (requests.status=\"Request\" OR requests.status=\"Approve\"))
        LEFT JOIN jobtitles ON jobtitles.id=doctors.jobtitle
        LEFT JOIN subscription_orders ON subscription_orders.medical_provider_id=medical_providers.id AND subscription_orders.status=\"Active\" AND subscription_orders.subscription_plan_id=1

        WHERE

        (doctor_user.fullname LIKE doc_name OR doctor_user.fullname_en LIKE doc_name)
        AND
        (medical_provider_user.fullname LIKE medical_name OR medical_provider_user.fullname_en LIKE medical_name)
        AND
        medical_provider_has_specialties.speciality_id like speciality_id
        AND
        specialties.id like speciality_id
        AND
        doctors.jobtitle like jobtitle_id
        AND
        regions.id like region_id
        AND
        governrates.id like governrate_id
        AND
        medical_provider_specialty_has_services.service_id like service_id
        AND
        medical_provider_specialty_has_services.price>=min_price
        AND
        medical_provider_specialty_has_services.price<=max_price
        AND
        doctor_user.verified=1
        AND
        medical_provider_user.verified=1
        AND governrates.deleted_at IS NULL AND governrates.disabled=0
        AND regions.deleted_at IS NULL AND regions.disabled=0
        AND specialties.deleted_at IS NULL AND specialties.disabled=0
        AND services.deleted_at IS NULL AND services.disabled=0
        AND jobtitles.deleted_at IS NULL AND jobtitles.disabled=0
        AND medical_provider_user.deleted_at IS NULL AND medical_provider_user.disabled=0
        AND doctor_user.deleted_at IS NULL AND doctor_user.disabled=0


        order by  ad DESC,order_amount DESC,provider_name ASC,doctor_name ASC
        LIMIT start_offset,results_per_page;


        END
        ";

        $procedure_total_search_result="
        CREATE DEFINER=`root`@`localhost` PROCEDURE `total_search_result`(
          IN service_id VARCHAR(255),
          IN user_id INTEGER,
          IN doc_name VARCHAR(255) CHARSET utf8,
          IN medical_name VARCHAR(255) CHARSET utf8,
          IN speciality_id VARCHAR(255),
          IN jobtitle_id VARCHAR(255),
          IN region_id VARCHAR(255),
          IN governrate_id VARCHAR(255),
          IN min_price INTEGER,
          IN max_price INTEGER

        )
BEGIN

        Select distinct
        COUNT(doctors.id) AS total
        From doctors

        LEFT JOIN users AS doctor_user ON doctor_user.id=doctors.user_id
        LEFT JOIN doctor_has_medical_provider ON doctor_has_medical_provider.doctor_id=doctors.id
        LEFT JOIN medical_providers ON medical_providers.id=doctor_has_medical_provider.medical_provider_id
        LEFT JOIN users AS medical_provider_user ON medical_provider_user.id=medical_providers.user_id
        LEFT JOIN governrates ON governrates.id=medical_providers.governrate_id
        LEFT JOIN regions ON regions.id=governrates.region_id
        LEFT JOIN medical_provider_has_specialties ON (medical_provider_has_specialties.medical_provider_id=medical_providers.id  AND doctors.speciality_id = medical_provider_has_specialties.speciality_id)
        LEFT JOIN medical_provider_specialty_has_services ON medical_provider_specialty_has_services.medical_provider_has_speciality_id=medical_provider_has_specialties.id
        LEFT JOIN patients ON patients.user_id=user_id
        LEFT JOIN requests ON (requests.doctor_id=doctors.id AND requests.medical_provider_id=medical_providers.id AND  requests.patient_id=patients.id)
        LEFT JOIN specialties ON specialties.id=doctors.speciality_id
        LEFT JOIN services ON (services.id = medical_provider_specialty_has_services.service_id)
        LEFT JOIN jobtitles ON jobtitles.id=doctors.jobtitle
        LEFT JOIN subscription_orders ON subscription_orders.medical_provider_id=medical_providers.id AND subscription_orders.status=\"Active\" AND subscription_orders.subscription_plan_id=1
        WHERE
        (doctor_user.fullname LIKE doc_name OR doctor_user.fullname_en LIKE doc_name)
        AND
        (medical_provider_user.fullname LIKE medical_name OR medical_provider_user.fullname_en LIKE medical_name)
        AND
        medical_provider_has_specialties.speciality_id=speciality_id
        AND
        specialties.id like speciality_id
        AND
        doctors.jobtitle like jobtitle_id
        AND
        regions.id like region_id
        AND
        governrates.id like governrate_id
        AND
        medical_provider_specialty_has_services.service_id like service_id
        AND
        medical_provider_specialty_has_services.price>=min_price
        AND
        medical_provider_specialty_has_services.price<=max_price
        AND
        doctor_user.verified=1
        AND
        medical_provider_user.verified=1
        AND governrates.deleted_at IS NULL AND governrates.disabled=0
        AND regions.deleted_at IS NULL AND regions.disabled=0
        AND specialties.deleted_at IS NULL AND specialties.disabled=0
        AND services.deleted_at IS NULL AND services.disabled=0
        AND jobtitles.deleted_at IS NULL AND jobtitles.disabled=0
        AND medical_provider_user.deleted_at IS NULL AND medical_provider_user.disabled=0
        AND doctor_user.deleted_at IS NULL AND doctor_user.disabled=0 ;


        END
        ";
DB::unprepared("DROP procedure IF EXISTS search_bulk");
DB::unprepared("DROP procedure IF EXISTS search_detailed");
DB::unprepared("DROP procedure IF EXISTS total_search_result");
DB::unprepared($procedure_search_bulk);
DB::unprepared($procedure_search_detailed);
DB::unprepared($procedure_total_search_result);

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
