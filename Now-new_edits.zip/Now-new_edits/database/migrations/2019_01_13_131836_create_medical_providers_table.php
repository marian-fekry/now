<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMedicalProvidersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('medical_providers', function (Blueprint $table) {
          $table->increments('id');
          $table->string('name_en',150)->nullable();
          $table->enum('type', ['medical_provider', 'hospital' , 'shared_clinic' , 'private_clinic'])->default('medical_provider');
          $table->unsignedInteger('user_id');
          $table->foreign('user_id')->references('id')->on('users');
          $table->unsignedInteger('governrate_id')->default(0);
          //$table->foreign('governrate_id')->references('id')->on('governrates');
          $table->text('brief')->nullable();
          $table->text('brief_en')->nullable();
          $table->longText('address')->nullable();
          $table->longText('address_en')->nullable();
          $table->string('latitude',50)->nullable();
          $table->string('longitude',50)->nullable();
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('medical_providers');
    }
}
