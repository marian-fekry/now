<?php

use Illuminate\Database\Seeder;
use App\User;
class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {


        $governerates=[
            "role_id"=>"1",
            "name"=>"Super_Admin",
            "email"=>"admin@now.gcssd.com",
            "password"=>bcrypt("UeLAhK41Ql8J"),
            "avatar"=>"users/default.png",
            "fullname"=>"super admin",
            "type"=>"Admin",
        



        ];

          User::Create($governerate);

    }
}
