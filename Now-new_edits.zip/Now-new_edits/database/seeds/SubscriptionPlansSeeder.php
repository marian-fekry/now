<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class SubscriptionPlansSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('subscription_plans')->insert([
            'name_en' => 'Top Search',
            'name_ar' => 'اول بحث',
            'body_ar' => 'اول بحث',
            'body_en' => 'Top Search',
            'price' => '200',
        ]);

        DB::table('subscription_plans')->insert([
            'name_en' => 'Splash Ads',
            'name_ar' => 'اعلانات فى الصفحة الرئيسية',
            'body_ar' => 'اعلانات فى الصفحة الرئيسية',
            'body_en' => 'Splash Ads',
            'price' => '500',
        ]);
        DB::table('subscription_plans')->insert([
            'name_en' => 'Receive Requests First',
            'name_ar' => 'استقبال الطلبات اولا',
            'body_ar' => 'استقبال الطلبات اولا',
            'body_en' => 'Receive Requests First',
            'price' => '1000',
        ]);
    }
}
