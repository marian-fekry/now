<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {

        // $this->call(UsersTableSeeder::class);
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        $this->call(VoyagerDataRowsTableSeeder::class);
        $this->call(VoyagerDataTypesTableSeeder::class);
        $this->call(VoyagerMenuItemsTableSeeder::class);
        $this->call(VoyagerPermissionsTableSeeder::class);
        $this->call(VoyagerPermissionRoleTableSeeder::class);
        $this->call(VoyagerRolesTableSeeder::class);
        $this->call(VoyagerSettingsTableSeeder::class);
        $this->call(VoyagerTranslationsTableSeeder::class);
        $this->call(VoyagerUserRolesTableSeeder::class);
        $this->call(VoyagerMenusTableSeeder::class);
        $this->call(SubscriptionPlansSeeder::class);
        $this->call(StaticPagesSeeder::class);
        $this->call(AddImagesSeeder::class);
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');

    }
}
