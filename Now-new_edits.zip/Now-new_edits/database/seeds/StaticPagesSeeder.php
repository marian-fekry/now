<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class StaticPagesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('staticpages')->insert([
            'title' => 'about us',
            'title_ar' => 'من نحن',
            'arabic' => 'من نحن',
            'english' => 'about us',
            'slug' => 'aboutus',
        ]);
        DB::table('staticpages')->insert([
            'title' => 'terms',
            'title_ar' => 'الأحكام والشروط',
            'arabic' => 'الأحكام والشروط',
            'english' => 'terms',
            'slug' => 'terms',
        ]);


    }
}
