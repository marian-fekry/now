<?php

use Illuminate\Database\Seeder;

class VoyagerPermissionRoleTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('permission_role')->delete();
        
        \DB::table('permission_role')->insert(array (
            0 => 
            array (
                'permission_id' => 1,
                'role_id' => 1,
            ),
            1 => 
            array (
                'permission_id' => 2,
                'role_id' => 1,
            ),
            2 => 
            array (
                'permission_id' => 3,
                'role_id' => 1,
            ),
            3 => 
            array (
                'permission_id' => 4,
                'role_id' => 1,
            ),
            4 => 
            array (
                'permission_id' => 5,
                'role_id' => 1,
            ),
            5 => 
            array (
                'permission_id' => 6,
                'role_id' => 1,
            ),
            6 => 
            array (
                'permission_id' => 7,
                'role_id' => 1,
            ),
            7 => 
            array (
                'permission_id' => 8,
                'role_id' => 1,
            ),
            8 => 
            array (
                'permission_id' => 9,
                'role_id' => 1,
            ),
            9 => 
            array (
                'permission_id' => 10,
                'role_id' => 1,
            ),
            10 => 
            array (
                'permission_id' => 11,
                'role_id' => 1,
            ),
            11 => 
            array (
                'permission_id' => 12,
                'role_id' => 1,
            ),
            12 => 
            array (
                'permission_id' => 13,
                'role_id' => 1,
            ),
            13 => 
            array (
                'permission_id' => 14,
                'role_id' => 1,
            ),
            14 => 
            array (
                'permission_id' => 15,
                'role_id' => 1,
            ),
            15 => 
            array (
                'permission_id' => 16,
                'role_id' => 1,
            ),
            16 => 
            array (
                'permission_id' => 17,
                'role_id' => 1,
            ),
            17 => 
            array (
                'permission_id' => 18,
                'role_id' => 1,
            ),
            18 => 
            array (
                'permission_id' => 19,
                'role_id' => 1,
            ),
            19 => 
            array (
                'permission_id' => 20,
                'role_id' => 1,
            ),
            20 => 
            array (
                'permission_id' => 21,
                'role_id' => 1,
            ),
            21 => 
            array (
                'permission_id' => 22,
                'role_id' => 1,
            ),
            22 => 
            array (
                'permission_id' => 23,
                'role_id' => 1,
            ),
            23 => 
            array (
                'permission_id' => 24,
                'role_id' => 1,
            ),
            24 => 
            array (
                'permission_id' => 25,
                'role_id' => 1,
            ),
            25 => 
            array (
                'permission_id' => 26,
                'role_id' => 1,
            ),
            26 => 
            array (
                'permission_id' => 26,
                'role_id' => 2,
            ),
            27 => 
            array (
                'permission_id' => 27,
                'role_id' => 1,
            ),
            28 => 
            array (
                'permission_id' => 27,
                'role_id' => 2,
            ),
            29 => 
            array (
                'permission_id' => 28,
                'role_id' => 1,
            ),
            30 => 
            array (
                'permission_id' => 28,
                'role_id' => 2,
            ),
            31 => 
            array (
                'permission_id' => 29,
                'role_id' => 1,
            ),
            32 => 
            array (
                'permission_id' => 29,
                'role_id' => 2,
            ),
            33 => 
            array (
                'permission_id' => 30,
                'role_id' => 1,
            ),
            34 => 
            array (
                'permission_id' => 30,
                'role_id' => 2,
            ),
            35 => 
            array (
                'permission_id' => 31,
                'role_id' => 1,
            ),
            36 => 
            array (
                'permission_id' => 31,
                'role_id' => 2,
            ),
            37 => 
            array (
                'permission_id' => 31,
                'role_id' => 4,
            ),
            38 => 
            array (
                'permission_id' => 31,
                'role_id' => 5,
            ),
            39 => 
            array (
                'permission_id' => 31,
                'role_id' => 6,
            ),
            40 => 
            array (
                'permission_id' => 31,
                'role_id' => 7,
            ),
            41 => 
            array (
                'permission_id' => 31,
                'role_id' => 8,
            ),
            42 => 
            array (
                'permission_id' => 31,
                'role_id' => 11,
            ),
            43 => 
            array (
                'permission_id' => 32,
                'role_id' => 1,
            ),
            44 => 
            array (
                'permission_id' => 32,
                'role_id' => 2,
            ),
            45 => 
            array (
                'permission_id' => 32,
                'role_id' => 4,
            ),
            46 => 
            array (
                'permission_id' => 32,
                'role_id' => 5,
            ),
            47 => 
            array (
                'permission_id' => 32,
                'role_id' => 6,
            ),
            48 => 
            array (
                'permission_id' => 32,
                'role_id' => 7,
            ),
            49 => 
            array (
                'permission_id' => 32,
                'role_id' => 8,
            ),
            50 => 
            array (
                'permission_id' => 32,
                'role_id' => 9,
            ),
            51 => 
            array (
                'permission_id' => 32,
                'role_id' => 10,
            ),
            52 => 
            array (
                'permission_id' => 32,
                'role_id' => 11,
            ),
            53 => 
            array (
                'permission_id' => 33,
                'role_id' => 1,
            ),
            54 => 
            array (
                'permission_id' => 33,
                'role_id' => 2,
            ),
            55 => 
            array (
                'permission_id' => 34,
                'role_id' => 1,
            ),
            56 => 
            array (
                'permission_id' => 34,
                'role_id' => 2,
            ),
            57 => 
            array (
                'permission_id' => 34,
                'role_id' => 6,
            ),
            58 => 
            array (
                'permission_id' => 34,
                'role_id' => 7,
            ),
            59 => 
            array (
                'permission_id' => 34,
                'role_id' => 8,
            ),
            60 => 
            array (
                'permission_id' => 34,
                'role_id' => 11,
            ),
            61 => 
            array (
                'permission_id' => 35,
                'role_id' => 1,
            ),
            62 => 
            array (
                'permission_id' => 35,
                'role_id' => 2,
            ),
            63 => 
            array (
                'permission_id' => 36,
                'role_id' => 1,
            ),
            64 => 
            array (
                'permission_id' => 37,
                'role_id' => 1,
            ),
            65 => 
            array (
                'permission_id' => 38,
                'role_id' => 1,
            ),
            66 => 
            array (
                'permission_id' => 39,
                'role_id' => 1,
            ),
            67 => 
            array (
                'permission_id' => 40,
                'role_id' => 1,
            ),
            68 => 
            array (
                'permission_id' => 41,
                'role_id' => 1,
            ),
            69 => 
            array (
                'permission_id' => 41,
                'role_id' => 2,
            ),
            70 => 
            array (
                'permission_id' => 41,
                'role_id' => 5,
            ),
            71 => 
            array (
                'permission_id' => 42,
                'role_id' => 1,
            ),
            72 => 
            array (
                'permission_id' => 42,
                'role_id' => 2,
            ),
            73 => 
            array (
                'permission_id' => 42,
                'role_id' => 6,
            ),
            74 => 
            array (
                'permission_id' => 42,
                'role_id' => 7,
            ),
            75 => 
            array (
                'permission_id' => 42,
                'role_id' => 8,
            ),
            76 => 
            array (
                'permission_id' => 42,
                'role_id' => 11,
            ),
            77 => 
            array (
                'permission_id' => 43,
                'role_id' => 1,
            ),
            78 => 
            array (
                'permission_id' => 43,
                'role_id' => 2,
            ),
            79 => 
            array (
                'permission_id' => 43,
                'role_id' => 11,
            ),
            80 => 
            array (
                'permission_id' => 44,
                'role_id' => 1,
            ),
            81 => 
            array (
                'permission_id' => 44,
                'role_id' => 2,
            ),
            82 => 
            array (
                'permission_id' => 44,
                'role_id' => 6,
            ),
            83 => 
            array (
                'permission_id' => 44,
                'role_id' => 7,
            ),
            84 => 
            array (
                'permission_id' => 44,
                'role_id' => 8,
            ),
            85 => 
            array (
                'permission_id' => 44,
                'role_id' => 11,
            ),
            86 => 
            array (
                'permission_id' => 45,
                'role_id' => 1,
            ),
            87 => 
            array (
                'permission_id' => 45,
                'role_id' => 2,
            ),
            88 => 
            array (
                'permission_id' => 45,
                'role_id' => 6,
            ),
            89 => 
            array (
                'permission_id' => 45,
                'role_id' => 7,
            ),
            90 => 
            array (
                'permission_id' => 45,
                'role_id' => 8,
            ),
            91 => 
            array (
                'permission_id' => 45,
                'role_id' => 11,
            ),
            92 => 
            array (
                'permission_id' => 46,
                'role_id' => 1,
            ),
            93 => 
            array (
                'permission_id' => 46,
                'role_id' => 4,
            ),
            94 => 
            array (
                'permission_id' => 46,
                'role_id' => 5,
            ),
            95 => 
            array (
                'permission_id' => 46,
                'role_id' => 6,
            ),
            96 => 
            array (
                'permission_id' => 46,
                'role_id' => 7,
            ),
            97 => 
            array (
                'permission_id' => 46,
                'role_id' => 8,
            ),
            98 => 
            array (
                'permission_id' => 46,
                'role_id' => 9,
            ),
            99 => 
            array (
                'permission_id' => 46,
                'role_id' => 10,
            ),
            100 => 
            array (
                'permission_id' => 46,
                'role_id' => 11,
            ),
            101 => 
            array (
                'permission_id' => 47,
                'role_id' => 1,
            ),
            102 => 
            array (
                'permission_id' => 47,
                'role_id' => 4,
            ),
            103 => 
            array (
                'permission_id' => 47,
                'role_id' => 5,
            ),
            104 => 
            array (
                'permission_id' => 47,
                'role_id' => 6,
            ),
            105 => 
            array (
                'permission_id' => 47,
                'role_id' => 7,
            ),
            106 => 
            array (
                'permission_id' => 47,
                'role_id' => 8,
            ),
            107 => 
            array (
                'permission_id' => 47,
                'role_id' => 11,
            ),
            108 => 
            array (
                'permission_id' => 48,
                'role_id' => 1,
            ),
            109 => 
            array (
                'permission_id' => 49,
                'role_id' => 1,
            ),
            110 => 
            array (
                'permission_id' => 50,
                'role_id' => 1,
            ),
            111 => 
            array (
                'permission_id' => 51,
                'role_id' => 1,
            ),
            112 => 
            array (
                'permission_id' => 51,
                'role_id' => 4,
            ),
            113 => 
            array (
                'permission_id' => 51,
                'role_id' => 5,
            ),
            114 => 
            array (
                'permission_id' => 51,
                'role_id' => 6,
            ),
            115 => 
            array (
                'permission_id' => 51,
                'role_id' => 7,
            ),
            116 => 
            array (
                'permission_id' => 51,
                'role_id' => 8,
            ),
            117 => 
            array (
                'permission_id' => 51,
                'role_id' => 9,
            ),
            118 => 
            array (
                'permission_id' => 51,
                'role_id' => 10,
            ),
            119 => 
            array (
                'permission_id' => 51,
                'role_id' => 11,
            ),
            120 => 
            array (
                'permission_id' => 52,
                'role_id' => 1,
            ),
            121 => 
            array (
                'permission_id' => 52,
                'role_id' => 4,
            ),
            122 => 
            array (
                'permission_id' => 52,
                'role_id' => 5,
            ),
            123 => 
            array (
                'permission_id' => 52,
                'role_id' => 6,
            ),
            124 => 
            array (
                'permission_id' => 52,
                'role_id' => 7,
            ),
            125 => 
            array (
                'permission_id' => 52,
                'role_id' => 8,
            ),
            126 => 
            array (
                'permission_id' => 52,
                'role_id' => 11,
            ),
            127 => 
            array (
                'permission_id' => 53,
                'role_id' => 1,
            ),
            128 => 
            array (
                'permission_id' => 54,
                'role_id' => 1,
            ),
            129 => 
            array (
                'permission_id' => 55,
                'role_id' => 1,
            ),
            130 => 
            array (
                'permission_id' => 56,
                'role_id' => 1,
            ),
            131 => 
            array (
                'permission_id' => 56,
                'role_id' => 2,
            ),
            132 => 
            array (
                'permission_id' => 56,
                'role_id' => 4,
            ),
            133 => 
            array (
                'permission_id' => 56,
                'role_id' => 5,
            ),
            134 => 
            array (
                'permission_id' => 56,
                'role_id' => 6,
            ),
            135 => 
            array (
                'permission_id' => 56,
                'role_id' => 7,
            ),
            136 => 
            array (
                'permission_id' => 56,
                'role_id' => 8,
            ),
            137 => 
            array (
                'permission_id' => 56,
                'role_id' => 11,
            ),
            138 => 
            array (
                'permission_id' => 57,
                'role_id' => 1,
            ),
            139 => 
            array (
                'permission_id' => 57,
                'role_id' => 2,
            ),
            140 => 
            array (
                'permission_id' => 57,
                'role_id' => 4,
            ),
            141 => 
            array (
                'permission_id' => 57,
                'role_id' => 5,
            ),
            142 => 
            array (
                'permission_id' => 57,
                'role_id' => 6,
            ),
            143 => 
            array (
                'permission_id' => 57,
                'role_id' => 7,
            ),
            144 => 
            array (
                'permission_id' => 57,
                'role_id' => 8,
            ),
            145 => 
            array (
                'permission_id' => 57,
                'role_id' => 11,
            ),
            146 => 
            array (
                'permission_id' => 58,
                'role_id' => 1,
            ),
            147 => 
            array (
                'permission_id' => 58,
                'role_id' => 2,
            ),
            148 => 
            array (
                'permission_id' => 58,
                'role_id' => 4,
            ),
            149 => 
            array (
                'permission_id' => 59,
                'role_id' => 1,
            ),
            150 => 
            array (
                'permission_id' => 59,
                'role_id' => 2,
            ),
            151 => 
            array (
                'permission_id' => 59,
                'role_id' => 4,
            ),
            152 => 
            array (
                'permission_id' => 60,
                'role_id' => 1,
            ),
            153 => 
            array (
                'permission_id' => 60,
                'role_id' => 2,
            ),
            154 => 
            array (
                'permission_id' => 61,
                'role_id' => 1,
            ),
            155 => 
            array (
                'permission_id' => 61,
                'role_id' => 4,
            ),
            156 => 
            array (
                'permission_id' => 61,
                'role_id' => 5,
            ),
            157 => 
            array (
                'permission_id' => 61,
                'role_id' => 6,
            ),
            158 => 
            array (
                'permission_id' => 61,
                'role_id' => 7,
            ),
            159 => 
            array (
                'permission_id' => 61,
                'role_id' => 8,
            ),
            160 => 
            array (
                'permission_id' => 61,
                'role_id' => 9,
            ),
            161 => 
            array (
                'permission_id' => 61,
                'role_id' => 10,
            ),
            162 => 
            array (
                'permission_id' => 61,
                'role_id' => 11,
            ),
            163 => 
            array (
                'permission_id' => 62,
                'role_id' => 1,
            ),
            164 => 
            array (
                'permission_id' => 62,
                'role_id' => 4,
            ),
            165 => 
            array (
                'permission_id' => 62,
                'role_id' => 5,
            ),
            166 => 
            array (
                'permission_id' => 62,
                'role_id' => 6,
            ),
            167 => 
            array (
                'permission_id' => 62,
                'role_id' => 7,
            ),
            168 => 
            array (
                'permission_id' => 62,
                'role_id' => 8,
            ),
            169 => 
            array (
                'permission_id' => 62,
                'role_id' => 11,
            ),
            170 => 
            array (
                'permission_id' => 63,
                'role_id' => 1,
            ),
            171 => 
            array (
                'permission_id' => 64,
                'role_id' => 1,
            ),
            172 => 
            array (
                'permission_id' => 65,
                'role_id' => 1,
            ),
            173 => 
            array (
                'permission_id' => 66,
                'role_id' => 1,
            ),
            174 => 
            array (
                'permission_id' => 66,
                'role_id' => 4,
            ),
            175 => 
            array (
                'permission_id' => 66,
                'role_id' => 5,
            ),
            176 => 
            array (
                'permission_id' => 66,
                'role_id' => 6,
            ),
            177 => 
            array (
                'permission_id' => 66,
                'role_id' => 7,
            ),
            178 => 
            array (
                'permission_id' => 66,
                'role_id' => 8,
            ),
            179 => 
            array (
                'permission_id' => 66,
                'role_id' => 9,
            ),
            180 => 
            array (
                'permission_id' => 66,
                'role_id' => 10,
            ),
            181 => 
            array (
                'permission_id' => 66,
                'role_id' => 11,
            ),
            182 => 
            array (
                'permission_id' => 67,
                'role_id' => 1,
            ),
            183 => 
            array (
                'permission_id' => 67,
                'role_id' => 4,
            ),
            184 => 
            array (
                'permission_id' => 67,
                'role_id' => 6,
            ),
            185 => 
            array (
                'permission_id' => 67,
                'role_id' => 7,
            ),
            186 => 
            array (
                'permission_id' => 67,
                'role_id' => 8,
            ),
            187 => 
            array (
                'permission_id' => 67,
                'role_id' => 11,
            ),
            188 => 
            array (
                'permission_id' => 68,
                'role_id' => 1,
            ),
            189 => 
            array (
                'permission_id' => 69,
                'role_id' => 1,
            ),
            190 => 
            array (
                'permission_id' => 70,
                'role_id' => 1,
            ),
            191 => 
            array (
                'permission_id' => 71,
                'role_id' => 1,
            ),
            192 => 
            array (
                'permission_id' => 71,
                'role_id' => 5,
            ),
            193 => 
            array (
                'permission_id' => 71,
                'role_id' => 6,
            ),
            194 => 
            array (
                'permission_id' => 71,
                'role_id' => 7,
            ),
            195 => 
            array (
                'permission_id' => 71,
                'role_id' => 8,
            ),
            196 => 
            array (
                'permission_id' => 71,
                'role_id' => 11,
            ),
            197 => 
            array (
                'permission_id' => 72,
                'role_id' => 1,
            ),
            198 => 
            array (
                'permission_id' => 72,
                'role_id' => 6,
            ),
            199 => 
            array (
                'permission_id' => 72,
                'role_id' => 7,
            ),
            200 => 
            array (
                'permission_id' => 72,
                'role_id' => 8,
            ),
            201 => 
            array (
                'permission_id' => 72,
                'role_id' => 11,
            ),
            202 => 
            array (
                'permission_id' => 73,
                'role_id' => 1,
            ),
            203 => 
            array (
                'permission_id' => 94,
                'role_id' => 1,
            ),
            204 => 
            array (
                'permission_id' => 94,
                'role_id' => 2,
            ),
            205 => 
            array (
                'permission_id' => 94,
                'role_id' => 5,
            ),
            206 => 
            array (
                'permission_id' => 94,
                'role_id' => 6,
            ),
            207 => 
            array (
                'permission_id' => 94,
                'role_id' => 7,
            ),
            208 => 
            array (
                'permission_id' => 94,
                'role_id' => 8,
            ),
            209 => 
            array (
                'permission_id' => 94,
                'role_id' => 11,
            ),
            210 => 
            array (
                'permission_id' => 95,
                'role_id' => 1,
            ),
            211 => 
            array (
                'permission_id' => 95,
                'role_id' => 2,
            ),
            212 => 
            array (
                'permission_id' => 95,
                'role_id' => 4,
            ),
            213 => 
            array (
                'permission_id' => 95,
                'role_id' => 5,
            ),
            214 => 
            array (
                'permission_id' => 95,
                'role_id' => 6,
            ),
            215 => 
            array (
                'permission_id' => 95,
                'role_id' => 7,
            ),
            216 => 
            array (
                'permission_id' => 95,
                'role_id' => 8,
            ),
            217 => 
            array (
                'permission_id' => 95,
                'role_id' => 9,
            ),
            218 => 
            array (
                'permission_id' => 95,
                'role_id' => 10,
            ),
            219 => 
            array (
                'permission_id' => 95,
                'role_id' => 11,
            ),
            220 => 
            array (
                'permission_id' => 96,
                'role_id' => 1,
            ),
            221 => 
            array (
                'permission_id' => 96,
                'role_id' => 2,
            ),
            222 => 
            array (
                'permission_id' => 96,
                'role_id' => 6,
            ),
            223 => 
            array (
                'permission_id' => 96,
                'role_id' => 7,
            ),
            224 => 
            array (
                'permission_id' => 96,
                'role_id' => 8,
            ),
            225 => 
            array (
                'permission_id' => 96,
                'role_id' => 9,
            ),
            226 => 
            array (
                'permission_id' => 96,
                'role_id' => 11,
            ),
            227 => 
            array (
                'permission_id' => 97,
                'role_id' => 1,
            ),
            228 => 
            array (
                'permission_id' => 97,
                'role_id' => 2,
            ),
            229 => 
            array (
                'permission_id' => 97,
                'role_id' => 6,
            ),
            230 => 
            array (
                'permission_id' => 97,
                'role_id' => 7,
            ),
            231 => 
            array (
                'permission_id' => 97,
                'role_id' => 8,
            ),
            232 => 
            array (
                'permission_id' => 97,
                'role_id' => 11,
            ),
            233 => 
            array (
                'permission_id' => 98,
                'role_id' => 1,
            ),
            234 => 
            array (
                'permission_id' => 98,
                'role_id' => 2,
            ),
            235 => 
            array (
                'permission_id' => 104,
                'role_id' => 1,
            ),
            236 => 
            array (
                'permission_id' => 104,
                'role_id' => 4,
            ),
            237 => 
            array (
                'permission_id' => 104,
                'role_id' => 5,
            ),
            238 => 
            array (
                'permission_id' => 104,
                'role_id' => 6,
            ),
            239 => 
            array (
                'permission_id' => 104,
                'role_id' => 7,
            ),
            240 => 
            array (
                'permission_id' => 104,
                'role_id' => 8,
            ),
            241 => 
            array (
                'permission_id' => 104,
                'role_id' => 9,
            ),
            242 => 
            array (
                'permission_id' => 104,
                'role_id' => 10,
            ),
            243 => 
            array (
                'permission_id' => 104,
                'role_id' => 11,
            ),
            244 => 
            array (
                'permission_id' => 105,
                'role_id' => 1,
            ),
            245 => 
            array (
                'permission_id' => 105,
                'role_id' => 4,
            ),
            246 => 
            array (
                'permission_id' => 105,
                'role_id' => 5,
            ),
            247 => 
            array (
                'permission_id' => 105,
                'role_id' => 6,
            ),
            248 => 
            array (
                'permission_id' => 105,
                'role_id' => 7,
            ),
            249 => 
            array (
                'permission_id' => 105,
                'role_id' => 8,
            ),
            250 => 
            array (
                'permission_id' => 105,
                'role_id' => 9,
            ),
            251 => 
            array (
                'permission_id' => 105,
                'role_id' => 10,
            ),
            252 => 
            array (
                'permission_id' => 105,
                'role_id' => 11,
            ),
            253 => 
            array (
                'permission_id' => 106,
                'role_id' => 1,
            ),
            254 => 
            array (
                'permission_id' => 106,
                'role_id' => 4,
            ),
            255 => 
            array (
                'permission_id' => 106,
                'role_id' => 5,
            ),
            256 => 
            array (
                'permission_id' => 106,
                'role_id' => 6,
            ),
            257 => 
            array (
                'permission_id' => 106,
                'role_id' => 7,
            ),
            258 => 
            array (
                'permission_id' => 106,
                'role_id' => 8,
            ),
            259 => 
            array (
                'permission_id' => 106,
                'role_id' => 9,
            ),
            260 => 
            array (
                'permission_id' => 106,
                'role_id' => 10,
            ),
            261 => 
            array (
                'permission_id' => 106,
                'role_id' => 11,
            ),
            262 => 
            array (
                'permission_id' => 107,
                'role_id' => 1,
            ),
            263 => 
            array (
                'permission_id' => 107,
                'role_id' => 4,
            ),
            264 => 
            array (
                'permission_id' => 108,
                'role_id' => 1,
            ),
            265 => 
            array (
                'permission_id' => 108,
                'role_id' => 4,
            ),
            266 => 
            array (
                'permission_id' => 109,
                'role_id' => 1,
            ),
            267 => 
            array (
                'permission_id' => 109,
                'role_id' => 4,
            ),
            268 => 
            array (
                'permission_id' => 109,
                'role_id' => 5,
            ),
            269 => 
            array (
                'permission_id' => 109,
                'role_id' => 6,
            ),
            270 => 
            array (
                'permission_id' => 109,
                'role_id' => 7,
            ),
            271 => 
            array (
                'permission_id' => 109,
                'role_id' => 8,
            ),
            272 => 
            array (
                'permission_id' => 109,
                'role_id' => 9,
            ),
            273 => 
            array (
                'permission_id' => 109,
                'role_id' => 10,
            ),
            274 => 
            array (
                'permission_id' => 109,
                'role_id' => 11,
            ),
            275 => 
            array (
                'permission_id' => 110,
                'role_id' => 1,
            ),
            276 => 
            array (
                'permission_id' => 110,
                'role_id' => 4,
            ),
            277 => 
            array (
                'permission_id' => 110,
                'role_id' => 5,
            ),
            278 => 
            array (
                'permission_id' => 110,
                'role_id' => 6,
            ),
            279 => 
            array (
                'permission_id' => 110,
                'role_id' => 7,
            ),
            280 => 
            array (
                'permission_id' => 110,
                'role_id' => 8,
            ),
            281 => 
            array (
                'permission_id' => 110,
                'role_id' => 9,
            ),
            282 => 
            array (
                'permission_id' => 110,
                'role_id' => 10,
            ),
            283 => 
            array (
                'permission_id' => 110,
                'role_id' => 11,
            ),
            284 => 
            array (
                'permission_id' => 111,
                'role_id' => 1,
            ),
            285 => 
            array (
                'permission_id' => 112,
                'role_id' => 1,
            ),
            286 => 
            array (
                'permission_id' => 113,
                'role_id' => 1,
            ),
            287 => 
            array (
                'permission_id' => 114,
                'role_id' => 1,
            ),
            288 => 
            array (
                'permission_id' => 114,
                'role_id' => 2,
            ),
            289 => 
            array (
                'permission_id' => 114,
                'role_id' => 4,
            ),
            290 => 
            array (
                'permission_id' => 114,
                'role_id' => 5,
            ),
            291 => 
            array (
                'permission_id' => 114,
                'role_id' => 6,
            ),
            292 => 
            array (
                'permission_id' => 114,
                'role_id' => 7,
            ),
            293 => 
            array (
                'permission_id' => 114,
                'role_id' => 8,
            ),
            294 => 
            array (
                'permission_id' => 114,
                'role_id' => 11,
            ),
            295 => 
            array (
                'permission_id' => 115,
                'role_id' => 1,
            ),
            296 => 
            array (
                'permission_id' => 115,
                'role_id' => 2,
            ),
            297 => 
            array (
                'permission_id' => 115,
                'role_id' => 4,
            ),
            298 => 
            array (
                'permission_id' => 115,
                'role_id' => 5,
            ),
            299 => 
            array (
                'permission_id' => 115,
                'role_id' => 6,
            ),
            300 => 
            array (
                'permission_id' => 115,
                'role_id' => 7,
            ),
            301 => 
            array (
                'permission_id' => 115,
                'role_id' => 8,
            ),
            302 => 
            array (
                'permission_id' => 115,
                'role_id' => 11,
            ),
            303 => 
            array (
                'permission_id' => 116,
                'role_id' => 1,
            ),
            304 => 
            array (
                'permission_id' => 116,
                'role_id' => 2,
            ),
            305 => 
            array (
                'permission_id' => 116,
                'role_id' => 5,
            ),
            306 => 
            array (
                'permission_id' => 116,
                'role_id' => 6,
            ),
            307 => 
            array (
                'permission_id' => 116,
                'role_id' => 7,
            ),
            308 => 
            array (
                'permission_id' => 116,
                'role_id' => 8,
            ),
            309 => 
            array (
                'permission_id' => 117,
                'role_id' => 1,
            ),
            310 => 
            array (
                'permission_id' => 117,
                'role_id' => 2,
            ),
            311 => 
            array (
                'permission_id' => 117,
                'role_id' => 6,
            ),
            312 => 
            array (
                'permission_id' => 117,
                'role_id' => 7,
            ),
            313 => 
            array (
                'permission_id' => 117,
                'role_id' => 8,
            ),
            314 => 
            array (
                'permission_id' => 117,
                'role_id' => 11,
            ),
            315 => 
            array (
                'permission_id' => 118,
                'role_id' => 1,
            ),
            316 => 
            array (
                'permission_id' => 118,
                'role_id' => 2,
            ),
            317 => 
            array (
                'permission_id' => 124,
                'role_id' => 1,
            ),
            318 => 
            array (
                'permission_id' => 125,
                'role_id' => 1,
            ),
            319 => 
            array (
                'permission_id' => 126,
                'role_id' => 1,
            ),
            320 => 
            array (
                'permission_id' => 127,
                'role_id' => 1,
            ),
            321 => 
            array (
                'permission_id' => 128,
                'role_id' => 1,
            ),
            322 => 
            array (
                'permission_id' => 129,
                'role_id' => 1,
            ),
            323 => 
            array (
                'permission_id' => 129,
                'role_id' => 4,
            ),
            324 => 
            array (
                'permission_id' => 129,
                'role_id' => 5,
            ),
            325 => 
            array (
                'permission_id' => 129,
                'role_id' => 6,
            ),
            326 => 
            array (
                'permission_id' => 129,
                'role_id' => 7,
            ),
            327 => 
            array (
                'permission_id' => 129,
                'role_id' => 8,
            ),
            328 => 
            array (
                'permission_id' => 129,
                'role_id' => 11,
            ),
            329 => 
            array (
                'permission_id' => 130,
                'role_id' => 1,
            ),
            330 => 
            array (
                'permission_id' => 130,
                'role_id' => 5,
            ),
            331 => 
            array (
                'permission_id' => 130,
                'role_id' => 6,
            ),
            332 => 
            array (
                'permission_id' => 130,
                'role_id' => 7,
            ),
            333 => 
            array (
                'permission_id' => 130,
                'role_id' => 8,
            ),
            334 => 
            array (
                'permission_id' => 130,
                'role_id' => 11,
            ),
            335 => 
            array (
                'permission_id' => 131,
                'role_id' => 1,
            ),
            336 => 
            array (
                'permission_id' => 132,
                'role_id' => 1,
            ),
            337 => 
            array (
                'permission_id' => 133,
                'role_id' => 1,
            ),
            338 => 
            array (
                'permission_id' => 134,
                'role_id' => 1,
            ),
            339 => 
            array (
                'permission_id' => 134,
                'role_id' => 6,
            ),
            340 => 
            array (
                'permission_id' => 134,
                'role_id' => 7,
            ),
            341 => 
            array (
                'permission_id' => 134,
                'role_id' => 8,
            ),
            342 => 
            array (
                'permission_id' => 134,
                'role_id' => 11,
            ),
            343 => 
            array (
                'permission_id' => 135,
                'role_id' => 1,
            ),
            344 => 
            array (
                'permission_id' => 135,
                'role_id' => 5,
            ),
            345 => 
            array (
                'permission_id' => 135,
                'role_id' => 6,
            ),
            346 => 
            array (
                'permission_id' => 135,
                'role_id' => 7,
            ),
            347 => 
            array (
                'permission_id' => 135,
                'role_id' => 8,
            ),
            348 => 
            array (
                'permission_id' => 135,
                'role_id' => 11,
            ),
            349 => 
            array (
                'permission_id' => 136,
                'role_id' => 1,
            ),
            350 => 
            array (
                'permission_id' => 136,
                'role_id' => 6,
            ),
            351 => 
            array (
                'permission_id' => 136,
                'role_id' => 7,
            ),
            352 => 
            array (
                'permission_id' => 136,
                'role_id' => 8,
            ),
            353 => 
            array (
                'permission_id' => 136,
                'role_id' => 10,
            ),
            354 => 
            array (
                'permission_id' => 136,
                'role_id' => 11,
            ),
            355 => 
            array (
                'permission_id' => 137,
                'role_id' => 1,
            ),
            356 => 
            array (
                'permission_id' => 137,
                'role_id' => 6,
            ),
            357 => 
            array (
                'permission_id' => 137,
                'role_id' => 7,
            ),
            358 => 
            array (
                'permission_id' => 137,
                'role_id' => 8,
            ),
            359 => 
            array (
                'permission_id' => 137,
                'role_id' => 11,
            ),
            360 => 
            array (
                'permission_id' => 138,
                'role_id' => 1,
            ),
            361 => 
            array (
                'permission_id' => 139,
                'role_id' => 1,
            ),
            362 => 
            array (
                'permission_id' => 140,
                'role_id' => 1,
            ),
            363 => 
            array (
                'permission_id' => 141,
                'role_id' => 1,
            ),
            364 => 
            array (
                'permission_id' => 142,
                'role_id' => 1,
            ),
            365 => 
            array (
                'permission_id' => 143,
                'role_id' => 1,
            ),
        ));
        
        
    }
}
