<?php

use Illuminate\Database\Seeder;

class VoyagerPermissionsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('permissions')->delete();
        
        \DB::table('permissions')->insert(array (
            0 => 
            array (
                'id' => 1,
                'key' => 'browse_categories',
                'table_name' => 'categories',
                'created_at' => '2019-01-14 13:25:28',
                'updated_at' => '2019-01-14 13:25:28',
            ),
            1 => 
            array (
                'id' => 2,
                'key' => 'read_categories',
                'table_name' => 'categories',
                'created_at' => '2019-01-14 13:25:28',
                'updated_at' => '2019-01-14 13:25:28',
            ),
            2 => 
            array (
                'id' => 3,
                'key' => 'edit_categories',
                'table_name' => 'categories',
                'created_at' => '2019-01-14 13:25:28',
                'updated_at' => '2019-01-14 13:25:28',
            ),
            3 => 
            array (
                'id' => 4,
                'key' => 'add_categories',
                'table_name' => 'categories',
                'created_at' => '2019-01-14 13:25:28',
                'updated_at' => '2019-01-14 13:25:28',
            ),
            4 => 
            array (
                'id' => 5,
                'key' => 'delete_categories',
                'table_name' => 'categories',
                'created_at' => '2019-01-14 13:25:28',
                'updated_at' => '2019-01-14 13:25:28',
            ),
            5 => 
            array (
                'id' => 6,
                'key' => 'browse_posts',
                'table_name' => 'posts',
                'created_at' => '2019-01-14 13:28:08',
                'updated_at' => '2019-01-14 13:28:08',
            ),
            6 => 
            array (
                'id' => 7,
                'key' => 'read_posts',
                'table_name' => 'posts',
                'created_at' => '2019-01-14 13:28:08',
                'updated_at' => '2019-01-14 13:28:08',
            ),
            7 => 
            array (
                'id' => 8,
                'key' => 'edit_posts',
                'table_name' => 'posts',
                'created_at' => '2019-01-14 13:28:08',
                'updated_at' => '2019-01-14 13:28:08',
            ),
            8 => 
            array (
                'id' => 9,
                'key' => 'add_posts',
                'table_name' => 'posts',
                'created_at' => '2019-01-14 13:28:09',
                'updated_at' => '2019-01-14 13:28:09',
            ),
            9 => 
            array (
                'id' => 10,
                'key' => 'delete_posts',
                'table_name' => 'posts',
                'created_at' => '2019-01-14 13:28:09',
                'updated_at' => '2019-01-14 13:28:09',
            ),
            10 => 
            array (
                'id' => 11,
                'key' => 'browse_pages',
                'table_name' => 'pages',
                'created_at' => '2019-01-14 13:28:10',
                'updated_at' => '2019-01-14 13:28:10',
            ),
            11 => 
            array (
                'id' => 12,
                'key' => 'read_pages',
                'table_name' => 'pages',
                'created_at' => '2019-01-14 13:28:10',
                'updated_at' => '2019-01-14 13:28:10',
            ),
            12 => 
            array (
                'id' => 13,
                'key' => 'edit_pages',
                'table_name' => 'pages',
                'created_at' => '2019-01-14 13:28:10',
                'updated_at' => '2019-01-14 13:28:10',
            ),
            13 => 
            array (
                'id' => 14,
                'key' => 'add_pages',
                'table_name' => 'pages',
                'created_at' => '2019-01-14 13:28:10',
                'updated_at' => '2019-01-14 13:28:10',
            ),
            14 => 
            array (
                'id' => 15,
                'key' => 'delete_pages',
                'table_name' => 'pages',
                'created_at' => '2019-01-14 13:28:10',
                'updated_at' => '2019-01-14 13:28:10',
            ),
            15 => 
            array (
                'id' => 16,
                'key' => 'browse_admin',
                'table_name' => NULL,
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            16 => 
            array (
                'id' => 17,
                'key' => 'browse_bread',
                'table_name' => NULL,
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            17 => 
            array (
                'id' => 18,
                'key' => 'browse_database',
                'table_name' => NULL,
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            18 => 
            array (
                'id' => 19,
                'key' => 'browse_media',
                'table_name' => NULL,
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            19 => 
            array (
                'id' => 20,
                'key' => 'browse_compass',
                'table_name' => NULL,
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            20 => 
            array (
                'id' => 21,
                'key' => 'browse_menus',
                'table_name' => 'menus',
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            21 => 
            array (
                'id' => 22,
                'key' => 'read_menus',
                'table_name' => 'menus',
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            22 => 
            array (
                'id' => 23,
                'key' => 'edit_menus',
                'table_name' => 'menus',
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            23 => 
            array (
                'id' => 24,
                'key' => 'add_menus',
                'table_name' => 'menus',
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            24 => 
            array (
                'id' => 25,
                'key' => 'delete_menus',
                'table_name' => 'menus',
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            25 => 
            array (
                'id' => 26,
                'key' => 'browse_roles',
                'table_name' => 'roles',
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            26 => 
            array (
                'id' => 27,
                'key' => 'read_roles',
                'table_name' => 'roles',
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            27 => 
            array (
                'id' => 28,
                'key' => 'edit_roles',
                'table_name' => 'roles',
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            28 => 
            array (
                'id' => 29,
                'key' => 'add_roles',
                'table_name' => 'roles',
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            29 => 
            array (
                'id' => 30,
                'key' => 'delete_roles',
                'table_name' => 'roles',
                'created_at' => '2019-01-14 13:31:15',
                'updated_at' => '2019-01-14 13:31:15',
            ),
            30 => 
            array (
                'id' => 31,
                'key' => 'browse_users',
                'table_name' => 'users',
                'created_at' => '2019-01-14 13:31:16',
                'updated_at' => '2019-01-14 13:31:16',
            ),
            31 => 
            array (
                'id' => 32,
                'key' => 'read_users',
                'table_name' => 'users',
                'created_at' => '2019-01-14 13:31:16',
                'updated_at' => '2019-01-14 13:31:16',
            ),
            32 => 
            array (
                'id' => 33,
                'key' => 'edit_users',
                'table_name' => 'users',
                'created_at' => '2019-01-14 13:31:16',
                'updated_at' => '2019-01-14 13:31:16',
            ),
            33 => 
            array (
                'id' => 34,
                'key' => 'add_users',
                'table_name' => 'users',
                'created_at' => '2019-01-14 13:31:16',
                'updated_at' => '2019-01-14 13:31:16',
            ),
            34 => 
            array (
                'id' => 35,
                'key' => 'delete_users',
                'table_name' => 'users',
                'created_at' => '2019-01-14 13:31:16',
                'updated_at' => '2019-01-14 13:31:16',
            ),
            35 => 
            array (
                'id' => 36,
                'key' => 'browse_settings',
                'table_name' => 'settings',
                'created_at' => '2019-01-14 13:31:16',
                'updated_at' => '2019-01-14 13:31:16',
            ),
            36 => 
            array (
                'id' => 37,
                'key' => 'read_settings',
                'table_name' => 'settings',
                'created_at' => '2019-01-14 13:31:16',
                'updated_at' => '2019-01-14 13:31:16',
            ),
            37 => 
            array (
                'id' => 38,
                'key' => 'edit_settings',
                'table_name' => 'settings',
                'created_at' => '2019-01-14 13:31:16',
                'updated_at' => '2019-01-14 13:31:16',
            ),
            38 => 
            array (
                'id' => 39,
                'key' => 'add_settings',
                'table_name' => 'settings',
                'created_at' => '2019-01-14 13:31:16',
                'updated_at' => '2019-01-14 13:31:16',
            ),
            39 => 
            array (
                'id' => 40,
                'key' => 'delete_settings',
                'table_name' => 'settings',
                'created_at' => '2019-01-14 13:31:16',
                'updated_at' => '2019-01-14 13:31:16',
            ),
            40 => 
            array (
                'id' => 41,
                'key' => 'browse_medical_providers',
                'table_name' => 'medical_providers',
                'created_at' => '2019-01-14 13:39:54',
                'updated_at' => '2019-01-14 13:39:54',
            ),
            41 => 
            array (
                'id' => 42,
                'key' => 'read_medical_providers',
                'table_name' => 'medical_providers',
                'created_at' => '2019-01-14 13:39:54',
                'updated_at' => '2019-01-14 13:39:54',
            ),
            42 => 
            array (
                'id' => 43,
                'key' => 'edit_medical_providers',
                'table_name' => 'medical_providers',
                'created_at' => '2019-01-14 13:39:54',
                'updated_at' => '2019-01-14 13:39:54',
            ),
            43 => 
            array (
                'id' => 44,
                'key' => 'add_medical_providers',
                'table_name' => 'medical_providers',
                'created_at' => '2019-01-14 13:39:54',
                'updated_at' => '2019-01-14 13:39:54',
            ),
            44 => 
            array (
                'id' => 45,
                'key' => 'delete_medical_providers',
                'table_name' => 'medical_providers',
                'created_at' => '2019-01-14 13:39:54',
                'updated_at' => '2019-01-14 13:39:54',
            ),
            45 => 
            array (
                'id' => 46,
                'key' => 'browse_governrates',
                'table_name' => 'governrates',
                'created_at' => '2019-01-14 13:52:01',
                'updated_at' => '2019-01-14 13:52:01',
            ),
            46 => 
            array (
                'id' => 47,
                'key' => 'read_governrates',
                'table_name' => 'governrates',
                'created_at' => '2019-01-14 13:52:01',
                'updated_at' => '2019-01-14 13:52:01',
            ),
            47 => 
            array (
                'id' => 48,
                'key' => 'edit_governrates',
                'table_name' => 'governrates',
                'created_at' => '2019-01-14 13:52:01',
                'updated_at' => '2019-01-14 13:52:01',
            ),
            48 => 
            array (
                'id' => 49,
                'key' => 'add_governrates',
                'table_name' => 'governrates',
                'created_at' => '2019-01-14 13:52:01',
                'updated_at' => '2019-01-14 13:52:01',
            ),
            49 => 
            array (
                'id' => 50,
                'key' => 'delete_governrates',
                'table_name' => 'governrates',
                'created_at' => '2019-01-14 13:52:01',
                'updated_at' => '2019-01-14 13:52:01',
            ),
            50 => 
            array (
                'id' => 51,
                'key' => 'browse_regions',
                'table_name' => 'regions',
                'created_at' => '2019-01-14 13:52:55',
                'updated_at' => '2019-01-14 13:52:55',
            ),
            51 => 
            array (
                'id' => 52,
                'key' => 'read_regions',
                'table_name' => 'regions',
                'created_at' => '2019-01-14 13:52:55',
                'updated_at' => '2019-01-14 13:52:55',
            ),
            52 => 
            array (
                'id' => 53,
                'key' => 'edit_regions',
                'table_name' => 'regions',
                'created_at' => '2019-01-14 13:52:55',
                'updated_at' => '2019-01-14 13:52:55',
            ),
            53 => 
            array (
                'id' => 54,
                'key' => 'add_regions',
                'table_name' => 'regions',
                'created_at' => '2019-01-14 13:52:55',
                'updated_at' => '2019-01-14 13:52:55',
            ),
            54 => 
            array (
                'id' => 55,
                'key' => 'delete_regions',
                'table_name' => 'regions',
                'created_at' => '2019-01-14 13:52:55',
                'updated_at' => '2019-01-14 13:52:55',
            ),
            55 => 
            array (
                'id' => 56,
                'key' => 'browse_patients',
                'table_name' => 'patients',
                'created_at' => '2019-01-15 10:55:06',
                'updated_at' => '2019-01-15 10:55:06',
            ),
            56 => 
            array (
                'id' => 57,
                'key' => 'read_patients',
                'table_name' => 'patients',
                'created_at' => '2019-01-15 10:55:06',
                'updated_at' => '2019-01-15 10:55:06',
            ),
            57 => 
            array (
                'id' => 58,
                'key' => 'edit_patients',
                'table_name' => 'patients',
                'created_at' => '2019-01-15 10:55:06',
                'updated_at' => '2019-01-15 10:55:06',
            ),
            58 => 
            array (
                'id' => 59,
                'key' => 'add_patients',
                'table_name' => 'patients',
                'created_at' => '2019-01-15 10:55:06',
                'updated_at' => '2019-01-15 10:55:06',
            ),
            59 => 
            array (
                'id' => 60,
                'key' => 'delete_patients',
                'table_name' => 'patients',
                'created_at' => '2019-01-15 10:55:06',
                'updated_at' => '2019-01-15 10:55:06',
            ),
            60 => 
            array (
                'id' => 61,
                'key' => 'browse_specialties',
                'table_name' => 'specialties',
                'created_at' => '2019-01-15 14:57:35',
                'updated_at' => '2019-01-15 14:57:35',
            ),
            61 => 
            array (
                'id' => 62,
                'key' => 'read_specialties',
                'table_name' => 'specialties',
                'created_at' => '2019-01-15 14:57:35',
                'updated_at' => '2019-01-15 14:57:35',
            ),
            62 => 
            array (
                'id' => 63,
                'key' => 'edit_specialties',
                'table_name' => 'specialties',
                'created_at' => '2019-01-15 14:57:35',
                'updated_at' => '2019-01-15 14:57:35',
            ),
            63 => 
            array (
                'id' => 64,
                'key' => 'add_specialties',
                'table_name' => 'specialties',
                'created_at' => '2019-01-15 14:57:35',
                'updated_at' => '2019-01-15 14:57:35',
            ),
            64 => 
            array (
                'id' => 65,
                'key' => 'delete_specialties',
                'table_name' => 'specialties',
                'created_at' => '2019-01-15 14:57:35',
                'updated_at' => '2019-01-15 14:57:35',
            ),
            65 => 
            array (
                'id' => 66,
                'key' => 'browse_services',
                'table_name' => 'services',
                'created_at' => '2019-01-15 16:00:02',
                'updated_at' => '2019-01-15 16:00:02',
            ),
            66 => 
            array (
                'id' => 67,
                'key' => 'read_services',
                'table_name' => 'services',
                'created_at' => '2019-01-15 16:00:02',
                'updated_at' => '2019-01-15 16:00:02',
            ),
            67 => 
            array (
                'id' => 68,
                'key' => 'edit_services',
                'table_name' => 'services',
                'created_at' => '2019-01-15 16:00:02',
                'updated_at' => '2019-01-15 16:00:02',
            ),
            68 => 
            array (
                'id' => 69,
                'key' => 'add_services',
                'table_name' => 'services',
                'created_at' => '2019-01-15 16:00:02',
                'updated_at' => '2019-01-15 16:00:02',
            ),
            69 => 
            array (
                'id' => 70,
                'key' => 'delete_services',
                'table_name' => 'services',
                'created_at' => '2019-01-15 16:00:02',
                'updated_at' => '2019-01-15 16:00:02',
            ),
            70 => 
            array (
                'id' => 71,
                'key' => 'assign_service',
                'table_name' => NULL,
                'created_at' => NULL,
                'updated_at' => NULL,
            ),
            71 => 
            array (
                'id' => 72,
                'key' => 'assign_specialty',
                'table_name' => NULL,
                'created_at' => NULL,
                'updated_at' => NULL,
            ),
            72 => 
            array (
                'id' => 73,
                'key' => 'browse_hooks',
                'table_name' => NULL,
                'created_at' => '2019-01-30 09:57:33',
                'updated_at' => '2019-01-30 09:57:33',
            ),
            73 => 
            array (
                'id' => 94,
                'key' => 'browse_secretaries',
                'table_name' => 'secretaries',
                'created_at' => '2019-01-31 14:46:31',
                'updated_at' => '2019-01-31 14:46:31',
            ),
            74 => 
            array (
                'id' => 95,
                'key' => 'read_secretaries',
                'table_name' => 'secretaries',
                'created_at' => '2019-01-31 14:46:31',
                'updated_at' => '2019-01-31 14:46:31',
            ),
            75 => 
            array (
                'id' => 96,
                'key' => 'edit_secretaries',
                'table_name' => 'secretaries',
                'created_at' => '2019-01-31 14:46:31',
                'updated_at' => '2019-01-31 14:46:31',
            ),
            76 => 
            array (
                'id' => 97,
                'key' => 'add_secretaries',
                'table_name' => 'secretaries',
                'created_at' => '2019-01-31 14:46:31',
                'updated_at' => '2019-01-31 14:46:31',
            ),
            77 => 
            array (
                'id' => 98,
                'key' => 'delete_secretaries',
                'table_name' => 'secretaries',
                'created_at' => '2019-01-31 14:46:31',
                'updated_at' => '2019-01-31 14:46:31',
            ),
            78 => 
            array (
                'id' => 104,
                'key' => 'browse_requests',
                'table_name' => 'requests',
                'created_at' => '2019-02-04 13:06:05',
                'updated_at' => '2019-02-04 13:06:05',
            ),
            79 => 
            array (
                'id' => 105,
                'key' => 'read_requests',
                'table_name' => 'requests',
                'created_at' => '2019-02-04 13:06:05',
                'updated_at' => '2019-02-04 13:06:05',
            ),
            80 => 
            array (
                'id' => 106,
                'key' => 'edit_requests',
                'table_name' => 'requests',
                'created_at' => '2019-02-04 13:06:05',
                'updated_at' => '2019-02-04 13:06:05',
            ),
            81 => 
            array (
                'id' => 107,
                'key' => 'add_requests',
                'table_name' => 'requests',
                'created_at' => '2019-02-04 13:06:05',
                'updated_at' => '2019-02-04 13:06:05',
            ),
            82 => 
            array (
                'id' => 108,
                'key' => 'delete_requests',
                'table_name' => 'requests',
                'created_at' => '2019-02-04 13:06:05',
                'updated_at' => '2019-02-04 13:06:05',
            ),
            83 => 
            array (
                'id' => 109,
                'key' => 'browse_staticpages',
                'table_name' => 'staticpages',
                'created_at' => '2019-02-05 19:28:38',
                'updated_at' => '2019-02-05 19:28:38',
            ),
            84 => 
            array (
                'id' => 110,
                'key' => 'read_staticpages',
                'table_name' => 'staticpages',
                'created_at' => '2019-02-05 19:28:38',
                'updated_at' => '2019-02-05 19:28:38',
            ),
            85 => 
            array (
                'id' => 111,
                'key' => 'edit_staticpages',
                'table_name' => 'staticpages',
                'created_at' => '2019-02-05 19:28:38',
                'updated_at' => '2019-02-05 19:28:38',
            ),
            86 => 
            array (
                'id' => 112,
                'key' => 'add_staticpages',
                'table_name' => 'staticpages',
                'created_at' => '2019-02-05 19:28:38',
                'updated_at' => '2019-02-05 19:28:38',
            ),
            87 => 
            array (
                'id' => 113,
                'key' => 'delete_staticpages',
                'table_name' => 'staticpages',
                'created_at' => '2019-02-05 19:28:38',
                'updated_at' => '2019-02-05 19:28:38',
            ),
            88 => 
            array (
                'id' => 114,
                'key' => 'browse_doctors',
                'table_name' => 'doctors',
                'created_at' => '2019-02-11 13:29:55',
                'updated_at' => '2019-02-11 13:29:55',
            ),
            89 => 
            array (
                'id' => 115,
                'key' => 'read_doctors',
                'table_name' => 'doctors',
                'created_at' => '2019-02-11 13:29:55',
                'updated_at' => '2019-02-11 13:29:55',
            ),
            90 => 
            array (
                'id' => 116,
                'key' => 'edit_doctors',
                'table_name' => 'doctors',
                'created_at' => '2019-02-11 13:29:55',
                'updated_at' => '2019-02-11 13:29:55',
            ),
            91 => 
            array (
                'id' => 117,
                'key' => 'add_doctors',
                'table_name' => 'doctors',
                'created_at' => '2019-02-11 13:29:55',
                'updated_at' => '2019-02-11 13:29:55',
            ),
            92 => 
            array (
                'id' => 118,
                'key' => 'delete_doctors',
                'table_name' => 'doctors',
                'created_at' => '2019-02-11 13:29:55',
                'updated_at' => '2019-02-11 13:29:55',
            ),
            93 => 
            array (
                'id' => 124,
                'key' => 'browse_subscription_packages',
                'table_name' => 'subscription_packages',
                'created_at' => '2019-02-12 19:26:24',
                'updated_at' => '2019-02-12 19:26:24',
            ),
            94 => 
            array (
                'id' => 125,
                'key' => 'read_subscription_packages',
                'table_name' => 'subscription_packages',
                'created_at' => '2019-02-12 19:26:24',
                'updated_at' => '2019-02-12 19:26:24',
            ),
            95 => 
            array (
                'id' => 126,
                'key' => 'edit_subscription_packages',
                'table_name' => 'subscription_packages',
                'created_at' => '2019-02-12 19:26:24',
                'updated_at' => '2019-02-12 19:26:24',
            ),
            96 => 
            array (
                'id' => 127,
                'key' => 'add_subscription_packages',
                'table_name' => 'subscription_packages',
                'created_at' => '2019-02-12 19:26:24',
                'updated_at' => '2019-02-12 19:26:24',
            ),
            97 => 
            array (
                'id' => 128,
                'key' => 'delete_subscription_packages',
                'table_name' => 'subscription_packages',
                'created_at' => '2019-02-12 19:26:24',
                'updated_at' => '2019-02-12 19:26:24',
            ),
            98 => 
            array (
                'id' => 129,
                'key' => 'browse_jobtitles',
                'table_name' => 'jobtitles',
                'created_at' => '2019-02-13 11:46:25',
                'updated_at' => '2019-02-13 11:46:25',
            ),
            99 => 
            array (
                'id' => 130,
                'key' => 'read_jobtitles',
                'table_name' => 'jobtitles',
                'created_at' => '2019-02-13 11:46:25',
                'updated_at' => '2019-02-13 11:46:25',
            ),
            100 => 
            array (
                'id' => 131,
                'key' => 'edit_jobtitles',
                'table_name' => 'jobtitles',
                'created_at' => '2019-02-13 11:46:25',
                'updated_at' => '2019-02-13 11:46:25',
            ),
            101 => 
            array (
                'id' => 132,
                'key' => 'add_jobtitles',
                'table_name' => 'jobtitles',
                'created_at' => '2019-02-13 11:46:25',
                'updated_at' => '2019-02-13 11:46:25',
            ),
            102 => 
            array (
                'id' => 133,
                'key' => 'delete_jobtitles',
                'table_name' => 'jobtitles',
                'created_at' => '2019-02-13 11:46:25',
                'updated_at' => '2019-02-13 11:46:25',
            ),
            103 => 
            array (
                'id' => 134,
                'key' => 'browse_private_reservations',
                'table_name' => 'private_reservations',
                'created_at' => '2019-02-13 17:35:21',
                'updated_at' => '2019-02-13 17:35:21',
            ),
            104 => 
            array (
                'id' => 135,
                'key' => 'read_private_reservations',
                'table_name' => 'private_reservations',
                'created_at' => '2019-02-13 17:35:22',
                'updated_at' => '2019-02-13 17:35:22',
            ),
            105 => 
            array (
                'id' => 136,
                'key' => 'edit_private_reservations',
                'table_name' => 'private_reservations',
                'created_at' => '2019-02-13 17:35:22',
                'updated_at' => '2019-02-13 17:35:22',
            ),
            106 => 
            array (
                'id' => 137,
                'key' => 'add_private_reservations',
                'table_name' => 'private_reservations',
                'created_at' => '2019-02-13 17:35:22',
                'updated_at' => '2019-02-13 17:35:22',
            ),
            107 => 
            array (
                'id' => 138,
                'key' => 'delete_private_reservations',
                'table_name' => 'private_reservations',
                'created_at' => '2019-02-13 17:35:22',
                'updated_at' => '2019-02-13 17:35:22',
            ),
            108 => 
            array (
                'id' => 139,
                'key' => 'browse_subscription_plans',
                'table_name' => 'subscription_plans',
                'created_at' => '2019-02-17 20:04:28',
                'updated_at' => '2019-02-17 20:04:28',
            ),
            109 => 
            array (
                'id' => 140,
                'key' => 'read_subscription_plans',
                'table_name' => 'subscription_plans',
                'created_at' => '2019-02-17 20:04:28',
                'updated_at' => '2019-02-17 20:04:28',
            ),
            110 => 
            array (
                'id' => 141,
                'key' => 'edit_subscription_plans',
                'table_name' => 'subscription_plans',
                'created_at' => '2019-02-17 20:04:28',
                'updated_at' => '2019-02-17 20:04:28',
            ),
            111 => 
            array (
                'id' => 142,
                'key' => 'add_subscription_plans',
                'table_name' => 'subscription_plans',
                'created_at' => '2019-02-17 20:04:28',
                'updated_at' => '2019-02-17 20:04:28',
            ),
            112 => 
            array (
                'id' => 143,
                'key' => 'delete_subscription_plans',
                'table_name' => 'subscription_plans',
                'created_at' => '2019-02-17 20:04:28',
                'updated_at' => '2019-02-17 20:04:28',
            ),
        ));
        
        
    }
}