<?php

use Illuminate\Database\Seeder;
use App\Service;
use App\Specialty;
use App\Region;
use App\Governrate;
use App\Patient;
use App\User;
use App\MedicalProvider;
use App\Doctor;
use App\PrivateReservation;
use App\Secretary;
use App\Jobtitle;
class DevelopmentDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

              // add services
              $services=[
                  ["name_ar"=>"كشف","name_en"=>"examination"],["name_ar"=>"أشعة","name_en"=>"Radiology"],["name_ar"=>"تحليل","name_en"=>"Analysis"],["name_ar"=>"طوارىء","name_en"=>"Emergency"]
              ];
              foreach($services AS $service){
                  Service::Create($service);
              }

              // add specialties
              $specialties=[
                  ["name_ar"=>"أمراض القلب","name_en"=>"cardiology"],["name_ar"=>"طوارىء","name_en"=>"Emergency medicine"],["name_ar"=>"جراحات تجميل","name_en"=>"plastic surgery"],["name_ar"=>"عظام","name_en"=>"Orthopedics"]
              ];
              foreach($specialties AS $specialty){
                  Specialty::Create($specialty);
              }
              // add regions
              $regions=[
                  ["name_ar"=>"القصيم","name_en"=>"Qassim"],
                  ["name_ar"=>"الرياض","name_en"=>"Riyadh"],
                  ["name_ar"=>"تبوك","name_en"=>"Tabuk"],
                  ["name_ar"=>"المدينة","name_en"=>"Madinah"],
                  ["name_ar"=>"مكة","name_en"=>"Makkah"],
                  ["name_ar"=>"الحدود الشمالية","name_en"=>"Northern Borders"],
                  ["name_ar"=>"الجوف","name_en"=>"Jawf"],
                  ["name_ar"=>"حائل","name_en"=>"Ha'il"],
                  ["name_ar"=>"الباحة","name_en"=>"Bahah"],
                  ["name_ar"=>"جازان","name_en"=>"Jizan"],
                  ["name_ar"=>"العسير","name_en"=>"'Asir"],
                  ["name_ar"=>"المنطقة الشرقية","name_en"=>"Eastern Province"],
                  ["name_ar"=>"نجران","name_en"=>"Najran"]
              ];
              foreach($regions AS $region){
                  Region::Create($region);
              }
              // add governerates

              $governerates=[
                  ["region_id"=>"1","name_ar"=>"الرس","name_en"=>"Al Rass"],
                  ["region_id"=>"2","name_ar"=>"الدرعية","name_en"=>"Al Diriyah"],
                  ["region_id"=>"3","name_ar"=>"تيماء","name_en"=>"Tayma"],
                  ["region_id"=>"4","name_ar"=>"ينبع","name_en"=>"Yandu"],
                  ["region_id"=>"5","name_ar"=>"جدة","name_en"=>"jeddah"],
                  ["region_id"=>"6","name_ar"=>"طريف","name_en"=>"Turaif"],
                  ["region_id"=>"7","name_ar"=>"القريات","name_en"=>"Qurayyat"],


                  ["region_id"=>"8","name_ar"=>"بريدة","name_en"=>"Buraydah"],
                  ["region_id"=>"9","name_ar"=>"السليل","name_en"=>"Al Sulayyil"],
                  ["region_id"=>"10","name_ar"=>"أملج","name_en"=>"Umluj"],
                  ["region_id"=>"11","name_ar"=>"بدر","name_en"=>"Badr"],
                  ["region_id"=>"12","name_ar"=>"الطائف","name_en"=>"Al Ta'if"],
                  ["region_id"=>"13","name_ar"=>"رفحاء","name_en"=>"Rafha"],
                  ["region_id"=>"12","name_ar"=>"سكاكا","name_en"=>"Sakakah"],



              ];
              foreach($governerates AS $governerate){
                  Governrate::Create($governerate);
              }
              //add jobs
              $jobs=[
                  ["name_en"=>"Medical Assistant","name_ar"=>"مساعدة طبية"],
                  ["name_en"=>"Home Health Aide","name_ar"=>"مساعد الصحة المنزلية"],
                  ["name_en"=>"Nursing Assistant","name_ar"=>"مساعد تمريض"],
                  ["name_en"=>"Physician","name_ar"=>"الطبيب المعالج"],
                  ["name_en"=>"Therapist","name_ar"=>"المعالج"],
                  ["name_en"=>"Registered Nurse","name_ar"=>"ممرضة مسجلة"],
              ];
              foreach($jobs AS $job){
                  Jobtitle::Create($job);
              }











/*

              //add patients
              for($i=1;$i <= 100 ; $i++ )
              {
                  $user=['name'=>"patient".$i,'email'=>"patient".$i."@patient.com","fullname"=>"patient".$i." patient","password"=>bcrypt("1"),"type"=>"patient","mobile"=>"011".mt_rand(10000000,99999999),"gender"=>"male","birthdate"=>(mt_rand(2000,2020)."-0" . mt_rand(1,9) . "-0" . mt_rand(1,9))];
                  $userrow=User::create($user);
               
               
                  $patient=['user_id'=>$userrow->id];
                  Patient::create($patient);
                  if($userrow->id != 7 && $userrow->id != 3 && $userrow->id != 4 ){
                      DB::table('user_roles')->insert([
                          [
                              'user_id'    => $userrow->id,
                              'role_id'         => 4,
                          ],
                      ]);
                  }
              }


              //add private medical provider
                for($i=100;$i <= 100 ; $i++ ){
                  $user = ['name' => "private_clinic" . $i, 'email' => "clinic" . $i . "@medical.com", "fullname" => "medical" . $i . " provider", "password" => bcrypt("1"), "type" => "medical_provider"];
                  $userrow = User::create($user);
                  $medical = ['type' => 'private_clinic', 'user_id' => $userrow->id, 'governrate_id' => mt_rand(1, 14), 'brief' => 'medical of type clinic' . $i, 'address' => 'medical address' . $i];
                  MedicalProvider::create($medical);
                  if ($userrow->id != 2 && $userrow->id != 3  && $userrow->id != 12 && $userrow->id != 13 && $userrow->id != 14 && $userrow->id != 17) {
                      DB::table('user_roles')->insert([
                          [
                              'user_id' => $userrow->id,
                              'role_id' => 11,
                          ],
                      ]);
                  }
              }
              //add shared medical provider
                for($i=1;$i <= 100 ; $i++ )
              {
                  $user = ['name' => "shared_clinic" . $i, 'email' => "shared" . $i . "@medical.com", "fullname" => "medical" . $i . " provider", "password" => bcrypt("1"), "type" => "medicalprovider"];
                  $userrow = User::create($user);
                  $medical = ['type' => 'shared_clinic', 'user_id' => $userrow->id, 'governrate_id' => mt_rand(1, 14), 'brief' => 'medical of type shared clinic' . $i, 'address' => 'medical address' . $i];
                  MedicalProvider::create($medical);
                  if ($userrow->id != 2 && $userrow->id != 3 && $userrow->id != 12 && $userrow->id != 13 && $userrow->id != 14 && $userrow->id != 17) {
                      DB::table('user_roles')->insert([
                          [
                              'user_id' => $userrow->id,
                              'role_id' => 11,
                          ],
                      ]);
                  }
              }
              //add hospital medical provider
                for($i=1;$i <= 100 ; $i++ )
              {
                  $user = ['name' => "hospital" . $i, 'email' => "hospital" . $i . "@medical.com", "fullname" => "medical" . $i . " provider", "password" => bcrypt("1"), "type" => "medicalprovider"];
                  $userrow = User::create($user);
                  $medical = ['type' => 'hospital', 'user_id' => $userrow->id, 'governrate_id' => mt_rand(1, 14), 'brief' => 'medical of type hospital' . $i, 'address' => 'medical address' . $i];
                  MedicalProvider::create($medical);
                  if ($userrow->id != 2 && $userrow->id != 3 && $userrow->id != 12 && $userrow->id != 13 && $userrow->id != 14 && $userrow->id != 17) {
                      DB::table('user_roles')->insert([
                          [
                              'user_id' => $userrow->id,
                              'role_id' => 11,
                          ],
                      ]);
                  }
              }

              //add doctors and secretary;
              for($i=1;$i <= 100 ; $i++ )
              {
                  $user = ['name' => "doctor" . $i, 'email' => "doctor" . $i . "@doctor.com", "fullname" => "doctor" . $i, "password" => bcrypt("1")];
                  $userrow = User::create($user);
                  $doctor = ['user_id' => $userrow->id, 'name_en'=> "doctor" . $i ,'jobtitle' => mt_rand(1, 4), 'speciality_id' => mt_rand(1, 4)];
                  $doctorrow=Doctor::create($doctor);
                  $secretaryuser = ['name' => "secretary" . $i, 'email' => "secretary" . $i . "@secretary.com", "fullname" => "secretary" . $i, "password" => bcrypt("1")];
                  $userrow2=User::create($secretaryuser);
                  $secretary=['user_id'=>$userrow2->id,'doctor_id'=>$doctorrow->id];
                  Secretary::create($secretary);
                  if ($userrow->id != 18) {
                      DB::table('user_roles')->insert([
                          [
                              'user_id' => $userrow->id,
                              'role_id' => 5,
                          ],
                      ]);
                  }

                }
                  for($i=1;$i<=100;$i++)
                  {
                      DB::table('doctor_has_medical_provider')->insert([
                          [
                              'doctor_id' => mt_rand(1, 100),
                              'medical_provider_id' => mt_rand(1, 100),
                          ],
                      ]);
                  }


            for($i=1;$i <= 100 ; $i++ )
          {
              $request = ['patient_id' =>  mt_rand(1, 100) , 'doctor_id' => mt_rand(1, 100), "medical_provider_id" => mt_rand(1, 100), "status" =>"Confirm", "date"=>'2019-'.mt_rand(01, 12).'-'.mt_rand(01, 30),"time"=>''.mt_rand(00,23 ).':'.mt_rand(01, 12).':00'];
              $requestrow = \App\Request::create($request);

          }
          */
        //add private reservation
        /*
        for($i=1;$i <= 100 ; $i++ )
        {
            $user = ['name' => "private Reservation" . $i, 'email' => "privatereservation" . $i . "@privatereservation.com", "fullname" => "privatereservation" . $i, "password" => bcrypt("1")];
            $userrow = User::create($user);
            $privatereservation=['user_id'=>$userrow->id];
            PrivateReservation::create($privatereservation);
            DB::table('user_roles')->insert([
                [
                    'user_id' => $userrow->id,
                    'role_id' => 10,
                ],
            ]);
        }
        */
    }
}
