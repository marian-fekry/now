<?php

use Illuminate\Database\Seeder;

class VoyagerRolesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('roles')->delete();
        
        \DB::table('roles')->insert(array (
            0 => 
            array (
                'id' => 1,
                'name' => 'admin',
                'display_name' => 'Administrator',
                'created_at' => '2019-01-14 13:26:29',
                'updated_at' => '2019-01-14 13:26:29',
            ),
            1 => 
            array (
                'id' => 2,
                'name' => 'User Management',
                'display_name' => 'User Management',
                'created_at' => '2019-01-14 13:26:29',
                'updated_at' => '2019-03-07 07:15:56',
            ),
            2 => 
            array (
                'id' => 4,
                'name' => 'ROLE_PATIENT',
                'display_name' => 'ROLE_PATIENT',
                'created_at' => '2019-01-15 14:31:05',
                'updated_at' => '2019-01-15 14:31:05',
            ),
            3 => 
            array (
                'id' => 5,
                'name' => 'ROLE_DOCTOR',
                'display_name' => 'ROLE_DOCTOR',
                'created_at' => '2019-01-15 14:33:00',
                'updated_at' => '2019-01-15 14:33:00',
            ),
            4 => 
            array (
                'id' => 6,
                'name' => 'ROLE_HOSPITAL',
                'display_name' => 'ROLE_HOSPITAL',
                'created_at' => '2019-01-15 14:34:32',
                'updated_at' => '2019-01-15 14:34:32',
            ),
            5 => 
            array (
                'id' => 7,
                'name' => 'ROLE_PRIVATE_CLINIC',
                'display_name' => 'ROLE_PRIVATE_CLINIC',
                'created_at' => '2019-01-15 16:40:04',
                'updated_at' => '2019-01-15 16:40:04',
            ),
            6 => 
            array (
                'id' => 8,
                'name' => 'ROLE_SHARED_CLINIC',
                'display_name' => 'ROLE_SHARED_CLINIC',
                'created_at' => '2019-01-15 16:40:45',
                'updated_at' => '2019-01-15 16:40:45',
            ),
            7 => 
            array (
                'id' => 9,
                'name' => 'ROLE_SECRETARY',
                'display_name' => 'ROLE_SECRETARY',
                'created_at' => '2019-01-15 16:41:28',
                'updated_at' => '2019-01-15 16:41:28',
            ),
            8 => 
            array (
                'id' => 10,
                'name' => 'ROLE_PRIVATE_RESERVATION',
                'display_name' => 'ROLE_PRIVATE_RESERVATION',
                'created_at' => '2019-01-15 16:42:17',
                'updated_at' => '2019-01-15 16:42:17',
            ),
            9 => 
            array (
                'id' => 11,
                'name' => 'ROLE_MEDICAL_PROVIDER',
                'display_name' => 'ROLE_MEDICAL_PROVIDER',
                'created_at' => '2019-01-15 16:43:04',
                'updated_at' => '2019-01-15 16:43:04',
            ),
            10 => 
            array (
                'id' => 12,
                'name' => 'user',
                'display_name' => 'Normal User',
                'created_at' => '2019-04-18 08:40:34',
                'updated_at' => '2019-04-18 08:40:34',
            ),
        ));
        
        
    }
}
