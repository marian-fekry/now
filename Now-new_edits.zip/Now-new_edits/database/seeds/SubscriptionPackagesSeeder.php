<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class SubscriptionPackagesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('subscription_packages')->insert([
            'name_en' => 'Top Search',
            'name_ar' => 'اول بحث',
            'body_ar' => 'اول بحث',
            'body_en' => 'Top Search',
        ]);

        DB::table('subscription_packages')->insert([
            'name_en' => 'Splash Ads',
            'name_ar' => 'اول بحث',
            'body_ar' => 'اول بحث',
            'body_en' => 'Splash Ads',
        ]);
        DB::table('subscription_packages')->insert([
            'name_en' => 'Receive Requests First',
            'name_ar' => 'اول بحث',
            'body_ar' => 'اول بحث',
            'body_en' => 'Splash Ads',
        ]);
    }
}
