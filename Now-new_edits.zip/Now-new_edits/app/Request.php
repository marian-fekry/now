<?php

namespace App;

use App\Http\Controllers\OutPut;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\MedicalProvider;
use App\Doctor;
use App\Review;
use App\Patient;
use App\Notification;
use App\PrivateReservation ;
use DB;
use phpDocumentor\Reflection\Types\Null_;
use App\Jobs\SendQueue;
use Carbon\Carbon;
use App\BulkRequestQueueTasks;
class Request extends Model
{
    use SoftDeletes;
    protected $dates=['deleted_at'];

    protected $hidden = [
        'created_at','updated_at','disabled'
    ];
    //user relation
    public function patient(){
        return $this->belongsTo('App\Patient');
    }
    // doctor relation
    public function doctor(){
        return $this->belongsTo('App\Doctor');
    }
    public function medical_provider(){
        return $this->belongsTo('App\MedicalProvider');
    }
    public function service(){
        return $this->belongsTo('App\Service');
    }
    public function review(){
        return $this->hasOne('App\Review' , 'appointment_id' , 'id');
    }
    public function appointments(){
        return $this->hasOne('App\Appointment' , 'request_id' , 'id');
    }
    public function addrequest($patient_id,$doctor_id,$medical_provider_id,$service_id,$date,$time,$group='',$requestStatus='Request',$delay=0,$userId='' ){
        if($userId=='') {
            $userId=Auth::user()->id;
        }
        $request=new Request;
        $request->patient_id=$patient_id;
        $request->doctor_id=$doctor_id;
        $request->medical_provider_id=$medical_provider_id;
        $request->service_id=$service_id;
        $request->status=$requestStatus;
        $request->date=$date;
        $request->time=$time;
        $request->bulk_request_group=$group;
        if($request->save()){
            // send queue notification
            $requestIdLabel='requestIdLabel'.$request->id;
            if($requestStatus!='Canceled'){
                SendQueue::dispatch(0,'new_request',$userId,$request->id,'','','updateNewRequest',$patient_id,$userId,'new_request','updateNewRequest',$requestIdLabel)->delay(now()->addMinutes($delay));
            }

            //\App\notifications::sendNotification(0,'new_request',$userId,$request->id,'','','updateNewRequest',$patient_id,$userId,'new_request','updateNewRequest');
            \App\notifications::sendDataMessage(0,'new_request',$userId,$request->id,'','','updateNewRequest',$patient_id,$userId,'new_request','updateNewRequest');
            return true;
        }else{
            return false;
        }
    }
    public function addbulkRequestQueue($patient_id,$doctor_id,$medical_provider_id,$service_id,$date,$time,$group,$sendDateTime ){
        $userId=Auth::user()->id;
        $request=new BulkRequestQueueTasks;
        $request->user_id=$userId;
        $request->patient_id=$patient_id;
        $request->doctor_id=$doctor_id;
        $request->medical_provider_id=$medical_provider_id;
        $request->service_id=$service_id;
        $request->date=$date;
        $request->time=$time;
        $request->bulk_request_group=$group;
        $request->send_date_time=$sendDateTime;
        if($request->save()){
            return true;
        }else{
            return false;
        }
    }
    public function editrequest($requestId,$date,$time){
        $userId=Auth::user()->id;
        $request=Request::find($requestId);
        $request->date=$date;
        $request->time=$time;
        if($request->save()){
          // send push notification
          $patient=Patient::find($request->patient_id);
            SendQueue::dispatch($patient->user_id,'reschedule_request',$userId,$request->id,$date,$time,'updateCurrentRequest',$patient->user_id,$userId,'reschedule_request','updateCurrentRequest');
         // \App\notifications::sendNotification($patient->user_id,'reschedule_request',Auth::user()->id,$request->id,$date,$time,'updateCurrentRequest');
          \App\notifications::sendDataMessage($patient->user_id,'reschedule_request',Auth::user()->id,$request->id,$date,$time,'updateCurrentRequest');

              return true;
        }else{
            return false;
        }
    }
    public function reschedulerequest($requestId,$date,$time){
        $userId=Auth::user()->id;
        $request=Request::find($requestId);
        $request->date=$date;
        $request->time=$time;
        $request->status='Approve';
        if($request->save()){
          // send push notification
          $patient=Patient::find($request->patient_id);
            SendQueue::dispatch($patient->user_id,'reschedule_request',$userId,$request->id,$date,$time,'updateCurrentRequest',$patient->user_id,$userId,'reschedule_request','updateCurrentRequest','Y','updateNewRequest');
         // \App\notifications::sendNotification($patient->user_id,'reschedule_request',Auth::user()->id,$request->id,$date,$time,'updateCurrentRequest');

         \App\notifications::sendDataMessage($patient->user_id,'reschedule_request',Auth::user()->id,$request->id,$date,$time,'updateCurrentRequest');
          \App\notifications::sendDataMessage($patient->user_id,'reschedule_request',Auth::user()->id,$request->id,$date,$time,'updateNewRequest');


              return true;
        }else{
            return false;
        }
    }
    public function approverequest($requestId,$user){
        $userId=Auth::user()->id;
        $request=Request::find($requestId);
        $requestDate = $request->date." ".$request->time;
        if(Carbon::now() > $requestDate){
            $request->status='Expired';
            $request->save();
            return false;
        }

        $request->status='Approve';
        if ($user->hasRole('ROLE_DOCTOR')||$user->hasRole('ROLE_SECRETARY')
                 ||$user->hasRole('ROLE_PRIVATE_RESERVATION')||$user->hasRole('ROLE_HOSPITAL')
                 ||$user->hasRole('ROLE_PRIVATE_CLINIC')||$user->hasRole('ROLE_SHARED_CLINIC')
                 ||$user->hasRole('ROLE_MEDICAL_PROVIDER')){
                    if($request->save()){

                        $patient=Patient::find($request->patient_id);
                        SendQueue::dispatch($patient->user_id,'approve_request',$userId,$request->id,'','','updateNewRequest',$patient->user_id,$userId,'approve_request','updateNewRequest');
                    //\App\notifications::sendNotification($patient->user_id,'approve_request',$userId,$request->id,'','','updateNewRequest',$patient->user_id,$userId,'approve_request','updateNewRequest');
                    \App\notifications::sendDataMessage($patient->user_id,'approve_request',$userId,$request->id,'','','updateNewRequest',$patient->user_id,$userId,'approve_request','updateNewRequest');

                        return true;
                    }else{
                        return false;
                    }
                 }else{
                     return false;
                 }

    }
    public function confirmrequest($requestId,$user){
        $userId=Auth::user()->id;
        $request=Request::find($requestId);
        $requestDate = $request->date." ".$request->time;
        if(Carbon::now() > $requestDate){
            $request->status='Expired';
            $request->save();
           return false;
        }
        $request->status='Confirm';

        if($user->hasRole('ROLE_PATIENT')){
            if($request->save()){
                if(!empty($request->bulk_request_group)){
                    $groupRequests = Request::where('bulk_request_group' , $request->bulk_request_group)->where('id','!=' ,$requestId )->get();
                    foreach ($groupRequests as $groupRequest) {
                         Request::where('id', $groupRequest->id)->update(['status' => "Canceled"]);
                         // Doctor Event
                        event(new \App\Events\UserEvent($groupRequest->doctor->user_id));
                        // Medical Event
                        if($groupRequest->doctor->user_id != $groupRequest->medical_provider->user_id){
                            event(new \App\Events\UserEvent($groupRequest->medical_provider->user_id));
                        }
                        // Secretary Event
                        if(!is_null($groupRequest->doctor->secretary)){
                            event(new \App\Events\UserEvent($groupRequest->medical_provider->user_id));
                        }
                        // Private Reservations Event
                        $privateReservation = MedicalProviderHasSpecialties::where('speciality_id' , $groupRequest->doctor->speciality_id)->where('medical_provider_id' ,$groupRequest->medical_provider_id)->first();
                        if(!is_null($privateReservation->departement_secretary_id)){
                            event(new \App\Events\UserEvent($privateReservation->privateReservation->user_id));
                        }


                    }
                    BulkRequestQueueTasks::where('bulk_request_group' , $request->bulk_request_group)->delete();
                }
                // add request to appointment table
                $appointment=new \App\Appointment;
                $appointment->request_id=$request->id;
                $appointment->save();

                $patient=Patient::find($request->patient_id);
                SendQueue::dispatch(0,'confirm_request',$userId,$request->id,'','','updateCurrentRequest',$patient->user_id,$userId,'confirm_request','updateCurrentRequest','Y','updateNewRequest');

                //\App\notifications::sendNotification(0,'confirm_request',Auth::user()->id,$request->id,'','','updateCurrentRequest');
                \App\notifications::sendDataMessage($patient->user_id,'confirm_request',Auth::user()->id,$request->id,'','','updateCurrentRequest');
                \App\notifications::sendDataMessage($patient->user_id,'confirm_request',Auth::user()->id,$request->id,'','','updateNewRequest');

                 return true;
             }else{
                 return false;
             }
        }else{
            return false;
        }

    }
    public function disable($id){
        $request=Request::find($id);
        if ($request->status=='disabled') {
            return true;
        }
        $request->disabled=1;
        if($request->save()){
          $patient=Patient::find($request->patient_id);

          \App\notifications::sendDataMessage($patient->user_id,'cancel_request',Auth::user()->id,$request->id,'','','updateCurrentRequest');
          \App\notifications::sendDataMessage($patient->user_id,'cancel_request',Auth::user()->id,$request->id,'','','updateNewRequest');

            return true;
        }else{
            return false;
        }

        return;
    }
    public function ExpiredRequest($id){
        $request=Request::find($id);
        $request->status="Expired";
        if($request->save()){
            return true;
        }else{
            return false;
        }

        return;
    }
    public function cancelRequest($id){
        $userId=Auth::user()->id;
        $request=Request::find($id);

        $request->status="Canceled";
        if($request->save()){
            $patient=Patient::find($request->patient_id);

            // when patient cancels the request
            if(Auth::user()->id==$patient->user_id){
                SendQueue::dispatch(0,'patient_cancel_request',$userId,$request->id,'','','updateNewRequest',$patient->user_id,$userId,'cancel_request','updateCurrentRequest','Y','updateNewRequest');
                //\App\notifications::sendNotification(0,'patient_cancel_request',Auth::user()->id,$request->id,'','','');
            }else{
                SendQueue::dispatch($patient->user_id,'mp_cancel_request',$userId,$request->id,'','','updateNewRequest',$patient->user_id,$userId,'cancel_request','updateCurrentRequest','Y','updateNewRequest');
                //\App\notifications::sendNotification($patient->user_id,'mp_cancel_request',Auth::user()->id,$request->id,'','','');
            }
            \App\notifications::sendDataMessage($patient->user_id,'cancel_request',Auth::user()->id,$request->id,'','','updateCurrentRequest');
            \App\notifications::sendDataMessage($patient->user_id,'cancel_request',Auth::user()->id,$request->id,'','','updateNewRequest');
            if($request->bulk_request_group!=''){
                $bulkRequestQueueFirst = \App\BulkRequestQueueTasks::where('bulk_request_group',$request->bulk_request_group )
                    ->orderby('send_date_time','asc')->first();
                if($bulkRequestQueueFirst){
                    $date = Carbon::parse($bulkRequestQueueFirst->send_date_time);
                    $now = Carbon::now();
                    $differenceTime = $date->diffinminutes($now);
                    $bulkRequestQueue = \App\BulkRequestQueueTasks::where('bulk_request_group',$request->bulk_request_group)->where('send_date_time',$bulkRequestQueueFirst->send_date_time)->get();
                    foreach ($bulkRequestQueue as $bulkRequest){
                        $req=new Request;
                        $req->addrequest($bulkRequest->patient_id,$bulkRequest->doctor_id,$bulkRequest->medical_provider_id , $bulkRequest->date ,$bulkRequest->time ,$bulkRequest->bulk_request_group,'Request',0,$bulkRequest->user_id);
                        DB::table('bulk_request_queue_tasks')->where('id',  $bulkRequest->id)->delete();
                    }
                    $bulkRequestRemaining = \App\BulkRequestQueueTasks::where('bulk_request_group',$request->bulk_request_group )->get();
                    foreach ($bulkRequestRemaining as $remaining){
                     $bulkRequestQueue =  \App\BulkRequestQueueTasks::find($remaining->id);
                     $date = Carbon::parse($remaining->send_date_time);
                     $newRequestDateTime= $date->subMinutes($differenceTime);
                     $bulkRequestQueue->send_date_time=$newRequestDateTime;
                     $bulkRequestQueue->save();
                    }

                }
            }
            return true;
        }else{
            return false;
        }

        return;
    }
//shared Clinic and hospital
    public function get_requests_medicalProvider()
    {
        $user=Auth::id();
        $medical=MedicalProvider::where("user_id","=",$user)->get();
        if($medical) {
            $allrequsts = Request::where(function($q) {
                $q->where('status','=','Request')
                    ->orWhere(function($q) {
                        $q->where('status','=','Approve');
                    });
            })->where('medical_provider_id', '=', $medical[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)
                ->wherehas('medical_provider' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('doctor' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('patient' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->orderBy('status', 'desc')->orderBy('date', 'asc')->orderBy('time', 'asc')->paginate(30);
            $data = [];
            if($allrequsts) {
                //$allrequsts = $allrequsts->toArray();
                //$patient_name=$doctor_name=$speciality_name="";
                foreach ($allrequsts as $request)
                {

                    if(Auth::user()->token()->user_lang=='ar') {
                        $medical_provider_name = $request->medical_provider->user->fullname;
                        $doctor_name = $request->doctor->user->fullname;
                        $doctor_job_title = $request->doctor->jobTitle->name_ar;
                        $speciality_name = $request->doctor->speciality->name_ar ;
                        $service_name = $request->service->name_ar ?? '';

                    }
                    else {
                        $medical_provider_name = $request->medical_provider->user->fullname_en;
                        $doctor_name = $request->doctor->user->fullname_en;
                        $doctor_job_title = $request->doctor->jobTitle->name_en;
                        $speciality_name = $request->doctor->speciality->name_en ;
                        $service_name = $request->service->name_en ?? '';
                    }
                    if($request->review) {
                        $rating = $request->review->rating;
                        $rating_comment = $request->review->comment;
                    }
                    else{
                        $rating = -1;
                        $rating_comment = '';
                    }
                    //$allrequsts[$key]['data']= Array("patient_name"=>$patient_name,"doctor_name"=>$doctor_name,"speciality_name"=>$speciality_name);

                    array_push($data , [
                      'request_id'=>$request->id ,
                      'medical_provider_id' => $request->medical_provider->id,
                      'medical_provider_name'=>$medical_provider_name ,
                      'doctor_name'=>$doctor_name ,
                      'doctor_job_title'=>$doctor_job_title  ,
                      'patient_name'=>$request->patient->user->fullname ,
                      'user_avatar'=> url('/').'/storage/'.$request->patient->user->avatar  ,
                      'service_name'=>$service_name ,
                      'speciality_name'=>$speciality_name  ,
                      'request_date'=>$request->date ,
                      'request_time'=>$request->time ,
                      'rating' =>$rating ,
                      'request_status'=>$request->status  ]  );


                }
                //array_push($data , ['current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count()]);
                $response = ['data'=>$data , 'current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count(),'last_page'=>$allrequsts->lastPage()] ;

            }
            return $response ;
        }
    }
    public function get_current_requests_medicalProvider()
    {
        $user=Auth::id();
        $medical=MedicalProvider::where("user_id","=",$user)->get();
        if($medical)
        {
            $allrequsts=Request::where('status','=',"Confirm")->where('medical_provider_id','=',$medical[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)->where(function($q) {
                $q->where('date','>',date('Y-m-d'))
                    ->orWhere(function($q) {
                        $q->where('date','=',date('Y-m-d'))
                            ->Where('time','>',date('H:i:s'));
                    });
            })->wherehas('appointments')
                ->wherehas('medical_provider' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('doctor' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('patient' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->orderBy('date', 'asc')->orderBy('time', 'asc')->paginate(30);
            $data = [];
            if($allrequsts) {
                //$allrequsts=$allrequsts->toArray();
                //$patient_name=$doctor_name=$speciality_name="";
                foreach ($allrequsts as $request)
                {

                    if(Auth::user()->token()->user_lang=='ar') {
                        $medical_provider_name = $request->medical_provider->user->fullname;
                        $doctor_name = $request->doctor->user->fullname;
                        $doctor_job_title = $request->doctor->jobTitle->name_ar;
                        $speciality_name = $request->doctor->speciality->name_ar ;
                        $service_name = $request->service->name_ar ?? '' ;

                    }
                    else {
                        $medical_provider_name = $request->medical_provider->user->fullname_en;
                        $doctor_name = $request->doctor->user->fullname_en;
                        $doctor_job_title = $request->doctor->jobTitle->name_en;
                        $speciality_name = $request->doctor->speciality->name_en ;
                        $service_name = $request->service->name_en ?? '';
                    }
                    if($request->review) {
                        $rating = $request->review->rating;
                        $rating_comment = $request->review->comment;
                    }
                    else{
                        $rating = -1;
                        $rating_comment = '';
                    }
                    //$allrequsts[$key]['data']= Array("patient_name"=>$patient_name,"doctor_name"=>$doctor_name,"speciality_name"=>$speciality_name);
                    array_push($data , [
                        'request_id'=>$request->id,
                        'medical_provider_id' => $request->medical_provider->id,
                        'medical_provider_name'=>$medical_provider_name ,
                        'doctor_name'=>$doctor_name ,
                        'doctor_job_title'=>$doctor_job_title ,
                        'patient_name'=>$request->patient->user->fullname ,
                        'user_avatar'=> url('/').'/storage/'.$request->patient->user->avatar  ,
                        'service_name'=>$service_name ,
                        'speciality_name'=>$speciality_name  ,
                        'request_date'=>$request->date ,
                        'request_time'=>$request->time ,
                        'rating' =>$rating  ,
                        'request_status'=>$request->status ]  );
                }
                //array_push($data , ['current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count()]);
                $response = ['data'=>$data , 'current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count(),'last_page'=>$allrequsts->lastPage()] ;
            }

            return $response ;
        }
    }
    public function get_old_requests_medicalProvider()
    {
        $user=Auth::id();
        $medical=MedicalProvider::where("user_id","=",$user)->get();
        if($medical)
        {
            $allrequsts=Request::where('status','=',"Confirm")->where('medical_provider_id','=',$medical[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)->where(function($q) {
                $q->where('date','<',date('Y-m-d'))
                    ->orWhere(function($q) {
                        $q->where('date', '=', date('Y-m-d'))
                            ->Where('time', '<', date('H:i:s'));
                    });
            })->wherehas('appointments')->orderBy('date', 'desc')->orderBy('time', 'desc')->paginate(30);
            $data = [];
            if($allrequsts) {
                //$allrequsts=$allrequsts->toArray();
                //$patient_name=$doctor_name=$speciality_name="";
                foreach ($allrequsts as $request)
                {
                    if(Auth::user()->token()->user_lang=='ar') {
                        $medical_provider_name = $request->medical_provider->userRequest->fullname;
                        $doctor_name = $request->doctor->userRequest->fullname;
                        $doctor_job_title = $request->doctor->jobTitle->name_ar;
                        $speciality_name = $request->doctor->speciality->name_ar ;
                        $service_name = $request->service->name_ar ?? '';

                    }
                    else {
                        $medical_provider_name = $request->medical_provider->userRequest->fullname_en;
                        $doctor_name = $request->doctor->userRequest->fullname_en;
                        $doctor_job_title = $request->doctor->jobTitle->name_en;
                        $speciality_name = $request->doctor->speciality->name_en ;
                        $service_name = $request->service->name_en ?? '';
                    }
                    if($request->review) {
                        $rating = $request->review->rating;
                        $rating_comment = $request->review->comment;
                    }
                    else{
                        $rating = -1;
                        $rating_comment = '';
                    }
                    //$allrequsts[$key]['data']= Array("patient_name"=>$patient_name,"doctor_name"=>$doctor_name,"speciality_name"=>$speciality_name);
                    array_push($data , [
                        'appointment_id'=>$request->appointments->id,
                        'request_id'=>$request->id ,
                        'medical_provider_id' => $request->medical_provider->id,
                        'medical_provider_name'=>$medical_provider_name ,
                        'doctor_name'=>$doctor_name ,
                        'doctor_job_title'=>$doctor_job_title ,
                        'medical_provider_name'=>$medical_provider_name ,
                        'patient_name'=>$request->patient->userRequest->fullname ,
                        'user_avatar'=> url('/').'/storage/'.$request->patient->userRequest->avatar ,
                        'service_name'=>$service_name  ,
                        'speciality_name'=>$speciality_name  ,
                        'request_date'=>$request->date ,
                        'request_time'=>$request->time ,
                        'rating' =>$rating ,
                        'request_status'=>$request->status
                    ]  );

                }
                //array_push($data , ['current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count()]);
                $response = ['data'=>$data , 'current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count(),'last_page'=>$allrequsts->lastPage()] ;

            }
            }
        return $response ;
    }
//end shared clinic and hospital

//private Clinic
    public function get_requests_medicalProvider_private()
    {
        $user=Auth::id();
        $medical=MedicalProvider::where("user_id","=",$user)->get();
        if($medical)
        {
            $allrequsts= Request::where('status','=',"Request")->where('medical_provider_id','=',$medical[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)->orderBy('created_at', 'desc')->paginate(30);
            return $allrequsts;
        }
    }
    public function get_current_requests_medicalProvider_private()
    {
        $user=Auth::id();
        $medical=MedicalProvider::where("user_id","=",$user)->get();
        if($medical)
        {
            $allrequsts=Request::where('status','=',"Confirm")->where('medical_provider_id','=',$medical[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)->where(function($q) {
                $q->where('date','>',date('Y-m-d'))
                    ->orWhere(function($q) {
                        $q->where('date','=',date('Y-m-d'))
                            ->Where('time','>',date('H:i:s'));
                    });
            })->orderBy('created_at', 'desc')->paginate(30);
            $data = [];
            if($allrequsts) {
                $allrequsts=$allrequsts->toArray();
                $patient_name=$doctor_name=$speciality_name="";
                foreach ($allrequsts['data'] as $key=>$request)
                {
                    $patient=Patient::find($request['patient_id']);
                    if($patient)
                    {
                        $patient_from_user=User::find($patient->user_id);
                        if($patient_from_user)
                        {
                            $patient_name=$patient_from_user->name;
                        }
                    }
                    $doctor=Doctor::find($request['doctor_id']);
                    if($doctor)
                    {
                        $doctor_form_user=User::find($doctor->user_id);
                        if($doctor_form_user)
                        {
                            $doctor_name=$doctor_form_user->name;
                        }
                        $speciality=Specialty::find($doctor->speciality_id);
                        if($speciality)
                        {
                            $speciality_name=$speciality->name;
                        }
                    }
                    $allrequsts[$key]['data']= Array("patient_name"=>$patient_name,"doctor_name"=>$doctor_name,"speciality_name"=>$speciality_name);
                }
                return $allrequsts;
            }
        }
    }
    public function get_old_requests_medicalProvider_private()
    {
        $user=Auth::id();
        $medical=MedicalProvider::where("user_id","=",$user)->get();
        if($medical)
        {
            $allrequsts=Request::where('status','=',"Confirm")->where('medical_provider_id','=',$medical[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)->where(function($q) {
                $q->where('date','<',date('Y-m-d'))
                    ->orWhere(function($q) {
                        $q->where('date', '=', date('Y-m-d'))
                            ->Where('time', '<', date('H:i:s'));
                    });
            })->orderBy('created_at', 'desc')->paginate(30);
            $data = [];
            if($allrequsts) {
                $allrequsts=$allrequsts->toArray();
                $patient_name=$doctor_name=$speciality_name="";
                foreach ($allrequsts['data'] as $key=>$request)
                {
                    $patient=Patient::find($request['patient_id']);
                    if($patient)
                    {
                        $patient_from_user=User::find($patient->user_id);
                        if($patient_from_user)
                        {
                            $patient_name=$patient_from_user->name;
                        }
                    }
                    $doctor=Doctor::find($request['doctor_id']);
                    if($doctor)
                    {
                        $doctor_form_user=User::find($doctor->user_id);
                        if($doctor_form_user)
                        {
                            $doctor_name=$doctor_form_user->name;
                        }
                        $speciality=Specialty::find($doctor->speciality_id);
                        if($speciality)
                        {
                            $speciality_name=$speciality->name;
                        }
                    }
                    $allrequsts[$key]['data']= Array("patient_name"=>$patient_name,"doctor_name"=>$doctor_name,"speciality_name"=>$speciality_name);
                }
                return $allrequsts;
            }
        }
    }
//end private clinic

//patient
    public function get_requests_patient()
    {
        $user_id=Auth::id();
        $patient=Patient::where("user_id","=",$user_id)->get();
        $data = [] ;

        $allrequsts=Request::where(function($q) {
                $q->where('status','=','Request')
                    ->orWhere(function($q) {
                        $q->where('status','=','Approve');
                    });
        })->where("patient_id","=",$patient[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)
          ->wherehas('doctor' ,function($query)
        {
            $query->wherehas('user' ,function($query)
            {
                $query->where('deleted_at', Null)->where("disabled","=",0);
            });

        })
         ->wherehas('medical_provider' ,function($query)
            {
                $query->wherehas('user' ,function($query)
                {
                    $query->where('deleted_at', Null)->where("disabled","=",0);
                });

            })
            ->wherehas('patient' ,function($query)
            {
                $query->wherehas('user' ,function($query)
                {
                    $query->where('deleted_at', Null)->where("disabled","=",0);
                });

            })
        ->orderBy('status','asc')->orderBy('date','asc')->orderBy('time','asc')->paginate(30);
        if($allrequsts) {
                foreach ($allrequsts as $request)
                {

                    if(Auth::user()->token()->user_lang=='ar') {
                        $medical_provider_name = $request->medical_provider->user->fullname;
                        $doctor_name = $request->doctor->user->fullname;
                        $doctor_job_title = $request->doctor->jobTitle->name_ar;
                        $speciality_name = $request->doctor->speciality->name_ar ;
                        $service_name = $request->service->name_ar  ??  '';

                    }
                    else {
                        $medical_provider_name = $request->medical_provider->user->fullname_en;
                        $doctor_name = $request->doctor->user->fullname_en;
                        $doctor_job_title = $request->doctor->jobTitle->name_en;
                        $speciality_name = $request->doctor->speciality->name_en ;
                        $service_name = $request->service->name_en ??  '';
                    }
                    if($request->review) {
                        $rating = $request->review->rating;
                        $rating_comment = $request->review->comment;
                    }
                    else{
                        $rating = -1;
                        $rating_comment = '';
                    }
                    //$allrequsts[$key]['data']= Array("patient_name"=>$patient_name,"doctor_name"=>$doctor_name,"speciality_name"=>$speciality_name);
                    array_push($data , [
                        'request_id'=>$request->id ,
                        'medical_provider_id' => $request->medical_provider->id,
                        'medical_provider_name'=>$medical_provider_name ,
                        'latitude'=>$request->medical_provider->latitude,
                        'longitude'=>$request->medical_provider->longitude,
                        'doctor_name'=>$doctor_name ,
                        'doctor_job_title'=>$doctor_job_title ,
                        'patient_name'=>$request->patient->user->fullname ,
                        'user_avatar'=> url('/').'/storage/'.$request->medical_provider->user->avatar ,
                        "speciality_name"=>$speciality_name  ,
                        "service_name"=>$service_name ,
                        'request_date'=>$request->date ,
                        'request_time'=>$request->time ,
                        'rating' =>$rating ,
                        'request_status'=>$request->status]  );
                }
                //array_push($data , ['current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count()]);
            $response = ['data'=>$data , 'current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count(),'last_page'=>$allrequsts->lastPage()] ;
        }
        return $response;
    }
    public function get_current_requests_patient()
    {
        $user_id=Auth::id();
        $patient=Patient::where("user_id","=",$user_id)->get();
        $allrequsts=Request::where('status','=',"Confirm")->where('patient_id','=',$patient[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)->where(function($q) {
            $q->where('date','>',date('Y-m-d'))
                ->orWhere(function($q) {
                    $q->where('date', '=', date('Y-m-d'))
                        ->Where('time', '>', date('H:i:s'));
                });
        })->wherehas('appointments')
            ->wherehas('doctor' ,function($query)
            {
                $query->wherehas('user' ,function($query)
                {
                    $query->where('deleted_at', Null);
                });

            })
            ->wherehas('medical_provider' ,function($query)
            {
                $query->wherehas('user' ,function($query)
                {
                    $query->where('deleted_at', Null);
                });

            })
            ->wherehas('patient' ,function($query)
            {
                $query->wherehas('user' ,function($query)
                {
                    $query->where('deleted_at', Null);
                });

            })
         ->orderBy('date', 'asc')->orderBy('time', 'asc')->paginate(30);
        $data = [];
        if($allrequsts) {

            foreach ($allrequsts as $request)
            {

                if(Auth::user()->token()->user_lang=='ar') {
                    $medical_provider_name = $request->medical_provider->user->fullname;
                    $doctor_name = $request->doctor->user->fullname;
                    $doctor_job_title = $request->doctor->jobTitle->name_ar;
                    $speciality_name = $request->doctor->speciality->name_ar ;
                    $service_name = $request->service->name_ar  ?? '';

                }
                else {
                    $medical_provider_name = $request->medical_provider->user->fullname_en;
                    $doctor_name = $request->doctor->user->fullname_en;
                    $doctor_job_title = $request->doctor->jobTitle->name_en;
                    $speciality_name = $request->doctor->speciality->name_en ;
                    $service_name = $request->service->name_en  ?? '';
                }
                if($request->review) {
                    $rating = $request->review->rating;
                    $rating_comment = $request->review->comment;
                }
                else{
                    $rating = -1;
                    $rating_comment = '';
                }
                //$allrequsts[$key]['data']= Array("patient_name"=>$patient_name,"doctor_name"=>$doctor_name,"speciality_name"=>$speciality_name);
                array_push($data , ['request_id'=>$request->id ,
                    'medical_provider_id' => $request->medical_provider->id,
                    'medical_provider_name'=>$medical_provider_name ,
                    'latitude'=>$request->medical_provider->latitude,
                        'longitude'=>$request->medical_provider->longitude,
                    'doctor_name'=>$doctor_name ,
                    'doctor_job_title'=>$doctor_job_title ,
                    'patient_name'=>$request->patient->user->fullname ,
                    'user_avatar'=> url('/').'/storage/'.$request->medical_provider->user->avatar,
                    "speciality_name"=>$speciality_name  ,
                    "service_name"=>$service_name ,
                    'request_date'=>$request->date ,
                    'request_time'=>$request->time ,
                    'rating' =>$rating  ,
                    'request_status'=>$request->status]  );
            }
            //array_push($data , ['current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count()]);
            $response = ['data'=>$data , 'current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count(),'last_page'=>$allrequsts->lastPage()] ;

        }
        return $response;
    }
    public function get_old_requests_patient()
    {
        $user_id=Auth::id();
        $patient=Patient::where("user_id","=",$user_id)->get();
        $allrequsts=Request::where('status','=',"Confirm")->where('patient_id','=',$patient[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)
        ->where(function($q) {
            $q->where('date','<',date('Y-m-d'))
                ->orWhere(function($q) {
                    $q->where('date', '=', date('Y-m-d'))
                        ->Where('time', '<', date('H:i:s'));
                });
        })->wherehas('appointments')->with('appointments')->orderBy('date', 'desc')->orderBy('time', 'desc')->paginate(30);
        $data = [];
        if($allrequsts)
        {

            //$allrequsts=$allrequsts->toArray();
            //$patient_name=$doctor_name=$speciality_name="";
            foreach ($allrequsts as $request)
            {
                // this data base call is not written in the best way, change it later
                $reviewData=array("rating"=>-1);
                if(isset($request->appointments->id)){
                    $reviewData=Review::where('appointment_id','=',$request->appointments->id)->where("disabled","=",0)
                    ->first();
                }


                if(Auth::user()->token()->user_lang=='ar') {
                  $medical_provider_name = $request->medical_provider->userRequest->fullname;
                    $doctor_name = $request->doctor->userRequest->fullname;
                    $doctor_job_title = $request->doctor->jobTitle->name_ar;
                    $speciality_name = $request->doctor->speciality->name_ar ;
                    $service_name = $request->service->name_ar ?? '' ;
                }
                else {
                    $medical_provider_name = $request->medical_provider->userRequest->fullname_en;
                    $doctor_name = $request->doctor->userRequest->fullname_en;
                    $doctor_job_title = $request->doctor->jobTitle->name_en;
                    $speciality_name = $request->doctor->speciality->name_en ;
                    $service_name = $request->service->name_en ?? '';
                }

                //$allrequsts[$key]['data']= Array("patient_name"=>$patient_name,"doctor_name"=>$doctor_name,"speciality_name"=>$speciality_name);
                array_push($data , [
                    'appointment_id'=>$request->appointments->id ,
                    'request_id'=>$request->id ,
                    'medical_provider_id' => $request->medical_provider->id,
                    'medical_provider_name'=>$medical_provider_name ,
                    'doctor_name'=>$doctor_name ,
                    'doctor_job_title'=>$doctor_job_title ,
                    'patient_name'=>$request->patient->userRequest->fullname ,
                    'user_avatar'=> url('/').'/storage/'.$request->medical_provider->userRequest->avatar,
                    "speciality_name"=>$speciality_name  ,
                    "service_name"=>$service_name,
                    'request_date'=>$request->date ,
                    'request_time'=>$request->time ,
                    'rating' =>($reviewData)?$reviewData->rating:-1  ,
                    'request_status'=>$request->status]  );
            }
            //array_push($data , ['current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count()]);
            $response = ['data'=>$data , 'current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count(),'last_page'=>$allrequsts->lastPage()] ;
        }
        return $response;
    }
//end patient

    public function  getDoctorsRequests($requestType , $isSecretary=false)
    {

        $user_id=Auth::id();
        if($isSecretary==true) {
            $secretary=Secretary::where("user_id","=",$user_id)->get();
            $doctor=Doctor::where("id","=",$secretary['0']->doctor_id)->get();
        }
        else {
            $doctor=Doctor::where("user_id","=",$user_id)->get();
        }

        $data = [] ;
        if($requestType=="new") {
            $allrequsts=Request::where(function($q) {
                $q->where('status','=','Request')
                    ->orWhere(function($q) {
                        $q->where('status','=','Approve');
                    });
            })->where("doctor_id","=",$doctor[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)
                ->wherehas('doctor' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('medical_provider' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('patient' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->orderBy('status', 'desc')->orderBy('date', 'asc')->orderBy('time', 'asc')->paginate(30);
        }
        else if($requestType=="current") {
            $allrequsts=Request::where('status','=',"Confirm")->where('doctor_id','=',$doctor[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)->where(function($q) {
                $q->where('date','>',date('Y-m-d'))
                    ->orWhere(function($q) {
                        $q->where('date', '=', date('Y-m-d'))
                            ->Where('time', '>', date('H:i:s'));
                    });
            })->wherehas('appointments')
                ->wherehas('doctor' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('medical_provider' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('patient' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->orderBy('date', 'asc')->orderBy('time', 'asc')->paginate(30);
        }
        else {//old
            $allrequsts=Request::where('status','=',"Confirm")->where('doctor_id','=',$doctor[0]->id)->where("disabled","=",0)->where("deleted_at","=",null)->where(function($q) {
                $q->where('date','<',date('Y-m-d'))
                    ->orWhere(function($q) {
                        $q->where('date','=',date('Y-m-d'))
                            ->Where('time','<',date('H:i:s'));
                    });

            })->wherehas('appointments')->orderBy('date', 'desc')->orderBy('time', 'desc')->paginate(30);
        }
        if($doctor)
        {
            if($allrequsts) {
                foreach ($allrequsts as $request)
                {
                    if(Auth::user()->token()->user_lang=='ar') {
                        if($requestType=="old"){
                            $medical_provider_name = $request->medical_provider->userRequest->fullname;
                            $doctor_name = $request->doctor->userRequest->fullname;
                        }
                        else{
                            $medical_provider_name = $request->medical_provider->user->fullname;
                            $doctor_name = $request->doctor->user->fullname;
                        }
                        $doctor_job_title = $request->doctor->jobTitle->name_ar;
                        $speciality_name = $request->doctor->speciality->name_ar ;
                        $service_name = $request->service->name_ar ?? '';
                    }
                    else {
                        if($requestType=="old"){
                            $medical_provider_name = $request->medical_provider->userRequest->fullname_en;
                            $doctor_name = $request->doctor->userRequest->fullname_en;
                        }
                        else {
                            $medical_provider_name = $request->medical_provider->user->fullname_en;
                            $doctor_name = $request->doctor->user->fullname_en;
                        }
                        $doctor_job_title = $request->doctor->jobTitle->name_en;
                        $speciality_name = $request->doctor->speciality->name_en ;
                        $service_name = $request->service->name_en ?? '' ;
                    }
                    if($request->review) {
                       $rating = $request->review->rating;
                        $rating_comment = $request->review->comment;
                    }
                    else{
                        $rating = -1;
                        $rating_comment = '';
                    }
                    if($requestType=="old") {
                        array_push($data , [
                            'appointment_id'=>$request->appointments->id  ,
                            'medical_provider_id' => $request->medical_provider->id,
                            'request_id'=>$request->id ,
                            'medical_provider_name'=>$medical_provider_name ,
                            'doctor_name'=>$doctor_name ,
                            'doctor_job_title'=>$doctor_job_title ,
                            'patient_name'=>$request->patient->userRequest->fullname ,
                            'user_avatar'=> url('/').'/storage/'.$request->patient->userRequest->avatar,
                            "service_name"=>$service_name,
                            "speciality_name"=>$speciality_name  ,
                            'request_date'=>$request->date ,
                            'request_time'=>$request->time ,
                            'rating' =>$rating ,
                            'request_status'=>$request->status]  );
                    }
                    else {
                        array_push($data , [
                            'request_id'=>$request->id ,
                            'medical_provider_id' => $request->medical_provider->id,
                            'medical_provider_name'=>$medical_provider_name ,
                            'doctor_name'=>$doctor_name ,
                            'doctor_job_title'=>$doctor_job_title ,
                            'patient_name'=>$request->patient->user->fullname ,
                            'user_avatar'=> url('/').'/storage/'.$request->patient->user->avatar,
                            "service_name"=>$service_name,
                            "speciality_name"=>$speciality_name  ,
                            'request_date'=>$request->date ,
                            'request_time'=>$request->time ,
                            'rating' =>$rating ,
                            'request_status'=>$request->status]  );
                    }
                }
                //array_push($data , ['current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count()]);
                $response = ['data'=>$data , 'current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count(),'last_page'=>$allrequsts->lastPage()] ;

            }
        }
        return $response ;
    }

    public function getPrivateReservationRequests($requestType)
    {
        $data = [];
        $user_id=Auth::id();
        $privateReservation =PrivateReservation::where("user_id","=",$user_id)->first();
        $medicalProvider = DB::table('medical_provider_has_specialties')->where('departement_secretary_id', $privateReservation->id)->first();
        $doctorsData = DB::table('doctors')
            ->join('doctor_has_medical_provider', 'doctor_has_medical_provider.doctor_id', '=','doctors.id')
            ->where( 'doctor_has_medical_provider.medical_provider_id', '=', $medicalProvider->medical_provider_id)
            ->where( 'doctors.speciality_id', '=', $medicalProvider->speciality_id)
            ->select('doctors.id')
            ->get();
        $doctors=array();

        foreach ($doctorsData as $doctor )
            {
                array_push($doctors , $doctor->id);
            }
        if($requestType=="new") {
            $allrequsts=Request::where(function($q) {
                $q->where('status','=','Request')
                    ->orWhere(function($q) {
                        $q->where('status','=','Approve');
                    });
            })->whereIn("doctor_id",$doctors)->where("medical_provider_id" , "=" ,$medicalProvider->medical_provider_id)->where("disabled","=",0)->where("deleted_at","=",null)
                ->wherehas('doctor' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('medical_provider' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('patient' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->paginate(30);
        }
        else if($requestType=="current") {
            $allrequsts=Request::where('status','=',"Confirm")->whereIn('doctor_id',$doctors)->where("medical_provider_id" , "=" ,$medicalProvider->medical_provider_id)->where("disabled","=",0)->where("deleted_at","=",null)->where(function($q) {
                $q->where('date','>',date('Y-m-d'))
                    ->orWhere(function($q) {
                        $q->where('date', '=', date('Y-m-d'))
                            ->Where('time', '>', date('H:i:s'));
                    });
            })->wherehas('appointments')
                ->wherehas('doctor' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('medical_provider' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->wherehas('patient' ,function($query)
                {
                    $query->wherehas('user' ,function($query)
                    {
                        $query->where('deleted_at', Null)->where("disabled","=",0);
                    });

                })
                ->orderBy('created_at', 'desc')->paginate(30);
        }
        else {//old
            $allrequsts=Request::where('status','=',"Confirm")->whereIn('doctor_id',$doctors)->where("medical_provider_id" , "=" ,$medicalProvider->medical_provider_id)->where("disabled","=",0)->where("deleted_at","=",null)->where(function($q) {
                $q->where('date','<',date('Y-m-d'))
                    ->orWhere(function($q) {
                        $q->where('date','=',date('Y-m-d'))
                            ->Where('time','<',date('H:i:s'));
                    });
            })->wherehas('appointments')->orderBy('created_at', 'desc')->paginate(30);
        }
        if($allrequsts) {
            foreach ($allrequsts as $request)
            {
                if(Auth::user()->token()->user_lang=='ar') {
                    if ($requestType == "old") {
                        $medical_provider_name = $request->medical_provider->userRequest->fullname;
                        $doctor_name = $request->doctor->userRequest->fullname;
                    }
                    else {
                        $medical_provider_name = $request->medical_provider->user->fullname;
                        $doctor_name = $request->doctor->user->fullname;
                    }
                    $doctor_job_title = $request->doctor->jobTitle->name_ar;
                    $speciality_name = $request->doctor->speciality->name_ar ;
                    $service_name = $request->service->name_ar ?? '' ;
                }
                else {
                    if ($requestType == "old") {
                        $medical_provider_name = $request->medical_provider->userRequest->fullname_en;
                        $doctor_name = $request->doctor->userRequest->fullname_en;
                    }
                    else {
                        $medical_provider_name = $request->medical_provider->user->fullname_en;
                        $doctor_name = $request->doctor->user->fullname_en;
                    }
                    $doctor_job_title = $request->doctor->jobTitle->name_en;
                    $speciality_name = $request->doctor->speciality->name_en ;
                    $service_name = $request->service->name_en ?? '' ;
                }
                if($request->review) {
                    $rating = $request->review->rating;
                    $rating_comment = $request->review->comment;
                }
                else{
                    $rating = -1;
                    $rating_comment = '';
                }
                if($requestType=="old")
                {
                    array_push($data , [
                        'appointment_id'=>$request->appointments->id  ,
                        'request_id'=>$request->id ,
                        'medical_provider_id' => $request->medical_provider->id,
                        'medical_provider_name'=>$medical_provider_name ,
                        'doctor_name'=>$doctor_name ,
                        'doctor_job_title'=>$doctor_job_title ,
                        'patient_name'=>$request->patient->userRequest->fullname ,
                        'user_avatar'=> url('/').'/storage/'.$request->patient->userRequest->avatar,
                        "service_name"=>$service_name,
                        "speciality_name"=>$speciality_name  ,
                        'request_date'=>$request->date ,
                        'request_time'=>$request->time ,'rating' =>$rating ,
                        'request_status'=>$request->status]  );
                }
                else{
                    array_push($data , [
                        'request_id'=>$request->id ,
                        'medical_provider_id' => $request->medical_provider->id,
                        'medical_provider_name'=>$medical_provider_name ,
                        'doctor_name'=>$doctor_name ,
                        'doctor_job_title'=>$doctor_job_title ,
                        'patient_name'=>$request->patient->user->fullname ,
                        'user_avatar'=> url('/').'/storage/'.$request->patient->user->avatar,
                        "service_name"=>$service_name,
                        "speciality_name"=>$speciality_name  ,
                        'request_date'=>$request->date ,
                        'request_time'=>$request->time ,'rating' =>$rating ,
                        'request_status'=>$request->status]  );
                }

            }
            //array_push($data , ['current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count()]);
            $response = ['data'=>$data , 'current_page'=>$allrequsts->currentPage() ,'total' =>$allrequsts->total() , 'count' =>$allrequsts->count(),'last_page'=>$allrequsts->lastPage()] ;
        }
        return $response ;

    }

    public function medicalProviderInfo ($requestId )
    {
        $specialties = MedicalProviderHasSpecialties::where('medical_provider_id', $requestId->medical_provider->id )->get();
        $servicesArray = [] ;
        foreach ($specialties as $specialtiy) {
            $medical = new MedicalProvider();
            $servicesArray = $medical->medicalProviderSpecialties($requestId->medical_provider->id ,$specialtiy->speciality_id );
        }
        $address='';
        if(Auth::user()->token()->user_lang=='ar') {
            $medicalBreif = $requestId->medical_provider->brief ;
            $address=$requestId->medical_provider->address ;
            $region = isset($requestId->medical_provider->governrate->region->name_ar)?$requestId->medical_provider->governrate->region->name_ar:"";
            $governrate = isset($requestId->medical_provider->governrate->name_ar)?$requestId->medical_provider->governrate->name_ar:"";;
            $providerName = $requestId->medical_provider->userRequest->fullname;
            $doctorName = $requestId->doctor->userRequest->fullname;
            $doctorJobtitle = $requestId->doctor->jobTitle->name_ar;
            $specialityName = $requestId->doctor->speciality->name_ar;
        } else {
            $medicalBreif = $requestId->medical_provider->brief_en ;
            $address=$requestId->medical_provider->address_en ;
            $region = isset($requestId->medical_provider->governrate->region->name_en)?$requestId->medical_provider->governrate->region->name_en:"";
            $governrate = isset($requestId->medical_provider->governrate->name_en)?$requestId->medical_provider->governrate->name_en:"";
            $providerName = $requestId->medical_provider->user->fullname_en;
            $doctorName = $requestId->doctor->user->fullname;
            $doctorJobtitle = $requestId->doctor->jobTitle->name_en;
            $specialityName = $requestId->doctor->speciality->name_en;
        }
        $doctorRateAmount =  $requestId->doctor->reviews->count('rating') ;
        if($doctorRateAmount> 0 ) {
            $doctorRate =  $requestId->doctor->reviews->sum('rating') /  $requestId->doctor->reviews->count('rating') ;
        }
        else {
            $doctorRate = 0 ;
        }
        $respone =  [
            'services'=>$servicesArray,
            'breif'=>$medicalBreif ,
            'address'=>$address,
            'medical_provider_img'=>url('storage/'. $requestId->medical_provider->user->avatar),
            'provieder_region'=> $region,
            'provider_governerate'=> $governrate,
            'provider_name'=> $providerName,
            'provider_latitude'=>$requestId->medical_provider->latitude,
            'provider_longitude'=>$requestId->medical_provider->longitude,
            'doctor_name'=> $doctorName,
            'doctor_jobtitle'=> $doctorJobtitle,
            'doctor_img'=>url('storage/'. $requestId->doctor->user->avatar),
            'doctor_rate'=>$doctorRate ,
            'doctor_rate_amount'=>$doctorRateAmount,
            'speciality_name'=>$specialityName,
            'request_status'=> $requestId->status ,
        ];
        return $respone;
    }

    public function get_request_data_for_patient($requestId,$UserId){

        $user=User::find($UserId);
        $patient=Patient::where("user_id","=",$UserId)->get();
        $data = [] ;

        $request=Request::find($requestId);

            if($user->lang=='ar') {
                $medical_provider_name = $request->medical_provider->user->fullname;
                $doctor_name = $request->doctor->user->fullname;
                $doctor_job_title = $request->doctor->jobTitle->name_ar;
                $speciality_name = $request->doctor->speciality->name_ar ;
                $service_name = $request->service->name_ar  ?? '';

            }
            else {
                $medical_provider_name = $request->medical_provider->user->fullname_en;
                $doctor_name = $request->doctor->user->fullname_en;
                $doctor_job_title = $request->doctor->jobTitle->name_en;
                $speciality_name = $request->doctor->speciality->name_en ;
                $service_name = $request->service->name_en ?? '';
            }
            if($request->review) {
                $rating = $request->review->rating;
                $rating_comment = $request->review->comment;
            }
            else{
                $rating = -1;
                $rating_comment = '';
            }
            if($request->status=='Confirm'){
                $appointmentId = $request->appointments->id ;
            }
            else{
                $appointmentId = '' ;
            }

            $response = [
                'appointment_id'=>$appointmentId ,
                'request_id'=>$request->id ,
                'medical_provider_id' => $request->medical_provider->id,
                'medical_provider_name'=>$medical_provider_name ,
                'latitude'=>$request->medical_provider->latitude,
                'longitude'=>$request->medical_provider->longitude,
                'doctor_name'=>$doctor_name ,
                'doctor_job_title'=>$doctor_job_title ,
                'patient_name'=>$request->patient->user->fullname ,
                'user_avatar'=> url('/').'/storage/'.$request->medical_provider->user->avatar,
                "service_name"=>$service_name ,
                "speciality_name"=>$speciality_name  ,
                'request_date'=>$request->date ,
                'request_time'=>$request->time ,
                'rating' =>$rating ,
                'request_status'=>$request->status]  ;


        return $response;
    }
    public function get_request_data_for_provider($requestId,$UserId){
        $user=User::find($UserId);
        $medical=MedicalProvider::where("user_id","=",$UserId)->get();
            $request=Request::where('id',$requestId)->firstOrFail();
            if($request) {

                    if($user->lang=='ar') {
                        $medical_provider_name = $request->medical_provider->userRequest->fullname;
                        $doctor_name = $request->doctor->userRequest->fullname;
                        $doctor_job_title = $request->doctor->jobTitle->name_ar;
                        $speciality_name = $request->doctor->speciality->name_ar ;
                        $service_name = $request->service->name_ar ?? '';
                    }
                    else {
                        $medical_provider_name = $request->medical_provider->userRequest->fullname_en;
                        $doctor_name = $request->doctor->userRequest->fullname_en;
                        $doctor_job_title = $request->doctor->jobTitle->name_en;
                        $speciality_name = $request->doctor->speciality->name_en ;
                        $service_name = $request->service->name_en ?? '';
                    }
                    if($request->review) {
                        $rating = $request->review->rating;
                        $rating_comment = $request->review->comment;
                    }
                    else{
                        $rating = -1;
                        $rating_comment = '';
                    }
                $response = [
                        'request_id'=>$request->id ,
                        'medical_provider_id' => $request->medical_provider->id,
                        'medical_provider_name'=>$medical_provider_name ,
                        'doctor_name'=>$doctor_name ,
                        'doctor_job_title'=>$doctor_job_title ,
                        'patient_name'=>$request->patient->userRequest->fullname ,
                        'user_avatar'=> url('/').'/storage/'.$request->patient->userRequest->avatar,
                        "speciality_name"=>$speciality_name  ,
                         "service_name"=>$service_name ,
                        'request_date'=>$request->date ,
                        'request_time'=>$request->time ,
                        'rating' =>$rating ,
                        'request_status'=>$request->status
                    ]  ;
        }
        return $response ;
    }

    public function get_request_data_for_doctor($requestId , $UserId , $isSecretary=false){
        $user=User::find($UserId);
        if($isSecretary==true) {
            $secretary=Secretary::where("user_id","=",$UserId)->get();
            $doctor=Doctor::where("id","=",$secretary['0']->doctor_id)->get();
        }
        else {
            $doctor=Doctor::where("user_id","=",$UserId)->get();
        }
        $request=Request::where('id',$requestId)->firstOrFail();
        if($doctor) {
            if ($request) {
                if ($user->lang == 'ar') {
                    if ($request->status == "Confirm") {
                        $medical_provider_name = $request->medical_provider->userRequest->fullname;
                        $doctor_name = $request->doctor->userRequest->fullname;
                    } else {
                        $medical_provider_name = $request->medical_provider->user->fullname;
                        $doctor_name = $request->doctor->user->fullname;
                    }
                    $doctor_job_title = $request->doctor->jobTitle->name_ar;
                    $speciality_name = $request->doctor->speciality->name_ar;
                    $service_name = $request->service->name_ar ?? '';
                } else {
                    if ($request->status == "Confirm") {
                        $medical_provider_name = $request->medical_provider->userRequest->fullname_en;
                        $doctor_name = $request->doctor->userRequest->fullname_en;
                    } else {
                        $medical_provider_name = $request->medical_provider->user->fullname_en;
                        $doctor_name = $request->doctor->user->fullname_en;
                    }
                    $doctor_job_title = $request->doctor->jobTitle->name_en;
                    $speciality_name = $request->doctor->speciality->name_en;
                    $service_name = $request->service->name_en ?? '';
                }
                if ($request->review) {
                    $rating = $request->review->rating;
                    $rating_comment = $request->review->comment;
                } else {
                    $rating = -1;
                    $rating_comment = '';
                }
                $response = [
                    'medical_provider_id' => $request->medical_provider->id,
                    'request_id' => $request->id,
                    'medical_provider_name' => $medical_provider_name,
                    'doctor_name' => $doctor_name,
                    'doctor_job_title' => $doctor_job_title,
                    'patient_name' => $request->patient->userRequest->fullname,
                    'user_avatar'=> url('/').'/storage/'.$request->patient->userRequest->avatar,
                    "speciality_name" => $speciality_name,
                    "service_name" => $service_name,
                    'request_date' => $request->date,
                    'request_time' => $request->time,
                    'rating' => $rating,
                    'request_status' => $request->status];
            }
        }

        return $response ;
    }
    public function get_request_data_for_private_reservation($requestId , $UserId ){
        $user=User::find($UserId);
        $privateReservation =PrivateReservation::where("user_id","=",$UserId)->first();
        $request=Request::where('id',$requestId)->firstOrFail();
        if($request) {
                if($user->lang=='ar') {
                    if ($request->status == "Confirm") {
                        $medical_provider_name = $request->medical_provider->userRequest->fullname;
                        $doctor_name = $request->doctor->userRequest->fullname;
                    }
                    else {
                        $medical_provider_name = $request->medical_provider->user->fullname;
                        $doctor_name = $request->doctor->user->fullname;
                    }
                    $doctor_job_title = $request->doctor->jobTitle->name_ar;
                    $speciality_name = $request->doctor->speciality->name_ar ;
                    $service_name = $request->service->name_ar ?? '';
                }
                else {
                    if ($request->status == "Confirm") {
                        $medical_provider_name = $request->medical_provider->userRequest->fullname_en;
                        $doctor_name = $request->doctor->userRequest->fullname_en;
                    }
                    else {
                        $medical_provider_name = $request->medical_provider->user->fullname_en;
                        $doctor_name = $request->doctor->user->fullname_en;
                    }
                    $doctor_job_title = $request->doctor->jobTitle->name_en;
                    $speciality_name = $request->doctor->speciality->name_en ;
                    $service_name = $request->service->name_en ?? '';
                }
                if($request->review) {
                    $rating = $request->review->rating;
                    $rating_comment = $request->review->comment;
                }
                else{
                    $rating = -1;
                    $rating_comment = '';
                }
            $response = [
                'request_id'=>$request->id ,
                'medical_provider_id' => $request->medical_provider->id,
                'medical_provider_name'=>$medical_provider_name ,
                'doctor_name'=>$doctor_name ,
                'doctor_job_title'=>$doctor_job_title ,
                'patient_name'=>$request->patient->userRequest->fullname ,
                'user_avatar'=> url('/').'/storage/'.$request->patient->userRequest->avatar,
                'service_name'=>$service_name,
                "speciality_name"=>$speciality_name  ,
                'request_date'=>$request->date ,
                'request_time'=>$request->time ,'rating' =>$rating ,
                'request_status'=>$request->status]  ;
        }
        return $response ;

    }

    public function currentRequestCount($colName , $userId ){
        $currentRequestCount = \App\Request::where($colName,$userId)->where('status', 'Confirm')->where(function($q) {
            $q->where('date','>',date('Y-m-d'))
                ->orWhere(function($q) {
                    $q->where('date', '=', date('Y-m-d'))
                        ->Where('time', '>', date('H:i:s'));
                });
        })->where("disabled","=",0)->where("deleted_at","=",null)->count();
        return $currentRequestCount ;
    }

    public function oldRequestCount($colName , $userId ){
        $oldRequestCount = \App\Request::where($colName,$userId)->where('status', 'Confirm')->where(function($q) {
            $q->where('date','<',date('Y-m-d'))
                ->orWhere(function($q) {
                    $q->where('date', '=', date('Y-m-d'))
                        ->Where('time', '<', date('H:i:s'));
                });
        })->where("disabled","=",0)->where("deleted_at","=",null)->count();
        return $oldRequestCount ;
    }
    public function pendingRequestCount($colName , $userId , $status){
        $pendingRequestCount = \App\Request::where($colName,$userId)->where('status', $status)->where("disabled","=",0)->where("deleted_at","=",null)->count();
        return $pendingRequestCount ;
    }
    public function pendingRequests($colName , $userId , $user,$status){
        $pendingRequests = \App\Request::where($colName,$userId)->where('status', $status)->where("disabled","=",0)->where("deleted_at","=",null)->paginate(30);
        $responseArray = array();

        foreach ($pendingRequests as $request){
            if($user->lang=='ar') {
                $medical_provider_name = $request->medical_provider->user->fullname;
                $doctor_name = $request->doctor->user->fullname;
                $doctor_job_title = $request->doctor->jobTitle->name_ar;
                $speciality_name = $request->doctor->speciality->name_ar ;
            }else{
                $medical_provider_name = $request->medical_provider->user->fullname_en;
                $doctor_name = $request->doctor->user->fullname_en;
                $doctor_job_title = $request->doctor->jobTitle->name_en;
                $speciality_name = $request->doctor->speciality->name_en ;
                if($colName=='patient_id'){
                    $user_avatar= url('/').'/storage/'.$request->medical_provider->user->avatar;
                }else{
                    $user_avatar= url('/').'/storage/'.$request->patient->userRequest->avatar;
                }
            }
            array_push($responseArray , [
                'request_id'=>$request->id ,
                'medical_provider_id' => $request->medical_provider->id,
                'medical_provider_name'=>$medical_provider_name ,
                'doctor_name'=>$doctor_name ,
                'doctor_job_title'=>$doctor_job_title ,
                'patient_name'=>$request->patient->userRequest->fullname ,
                'user_avatar'=>$user_avatar ,
                "speciality_name"=>$speciality_name  ,
                'request_date'=>$request->date ,
                'request_time'=>$request->time ,
                'request_status'=>$request->status]);
        }
        $response =   ['data'=>$responseArray , 'current_page'=>$pendingRequests->currentPage() ,'total' =>$pendingRequests->total() , 'count' =>$pendingRequests->count(),'last_page'=>$pendingRequests->lastPage()];
   return $response ;
    }
}
