<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
class SubscriptionOrder extends Model
{
   protected $hidden = [
       'created_at','updated_at'
   ];    //subscription_plans relation
   public function subscriptionPlans(){
       return $this->belongsTo('App\SubscriptionPlan' , 'subscription_plan_id');
   }
   //medical_provider relation
   public function medicalProvider(){
       return $this->belongsTo('App\MedicalProvider' , 'medical_provider_id');
   }
   public function requestOrder(){
       return $this->hasOne('App\GoverneratesTimeReservations','subscription_order_id');
   }
   public function getHighestBid(){
       $Order=\App\SubscriptionOrder::where('status','Active')->where('subscription_plan_id',1)->orderBy('amount','desc')->first();
       $subscriptionPlan=\App\SubscriptionPlan::find(1);
       $highestBid=$subscriptionPlan->price;
       if(null!==$Order){
           $highestBid=$Order->amount;
       }
       return $highestBid;
   }
   public function add($medicalProviderId,$subscription_plan_id , $amount , $orderMeta,$ReferenceNumber)
   {
       $subscriptionOrder=new SubscriptionOrder;
       $subscriptionOrder->medical_provider_id=$medicalProviderId;
       $subscriptionOrder->subscription_plan_id=$subscription_plan_id;
       $subscriptionOrder->amount=$amount;
       $subscriptionOrder->order_meta=$orderMeta;
       $subscriptionOrder->reference_number=$ReferenceNumber;
       if($subscriptionOrder->save()) {
         return $subscriptionOrder;
       }
       else {
           return false;
       }
   }
   public function loginAds()
   {
       $ad = SubscriptionOrder::where('status','Active')->where('disabled',0)->where('subscription_plan_id',2)->where('order_meta','not like', '%[]%')->orderBy('counter','asc')->first();
       $data=array();
       if(null!==$ad){
           $meta= json_decode($ad->order_meta,TRUE);
           if(sizeof($meta)>0&&isset($meta['image']) && isset($meta['url'])){
            $image= url('storage/users/advertise-images/'.$meta['image']);
            $url=$meta['url'];
            $data = ['image'=>$image ,'url'=>$url];
            $ad->counter= $ad->counter + 1;
            $ad->save();
           }

       }        return $data;
   }
}
