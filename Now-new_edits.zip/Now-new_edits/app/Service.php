<?php

namespace App;
use Exception;
use Illuminate\Database\Eloquent\Model;
use App\User;
use App\MedicalProviderHasSpecialties;
use App\MedicalProviderHasServices;
use Illuminate\Support\Facades\Auth;
use DB;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Pagination\Paginator;

class Service extends Model
{
  use SoftDeletes;
  protected $dates=['deleted_at'];

  protected $hidden = [
      'created_at','updated_at','disabled'
  ];


  public function medical_providers(){
    return $this->belongsToMany('App\MedicalProvider','medical_provider_has_services')->withPivot('price');
  }
    protected static function boot() {
        parent::boot();
        static::deleting(function($specialty) {
            $servicesMedical = DB::table('medical_provider_specialty_has_services')->where('service_id',$specialty->id)->get();
            if (count($servicesMedical) > 0) {
                throw new Exception(__('messages.this_service_have_medical') , '23000');
            }
        });
    }
  public function addServiceToSpecialty($serviceId,$specialtyId,$medicalProviderId,$price=0)
  {

     $medicalProviderHasSpecialties= MedicalProviderHasSpecialties::where('medical_provider_id',$medicalProviderId)->where('speciality_id',$specialtyId)->first();
     if(null!=$medicalProviderHasSpecialties)
     {
       DB::table('medical_provider_specialty_has_services')->insert(
         ['price'=>$price,'medical_provider_has_speciality_id'=>$medicalProviderHasSpecialties->id,'service_id'=>$serviceId]
       );
       return true;
     }
     else
     {
       return false;
     }
  }
  public function deleteServiceFromSpecialty($serviceId,$specialtyId,$medicalProviderId)
  {
     $medicalProviderHasSpecialties= MedicalProviderHasSpecialties::where('medical_provider_id',$medicalProviderId)->where('speciality_id',$specialtyId)->first();
     if(!empty($medicalProviderHasSpecialties))
     {

       DB::table('medical_provider_specialty_has_services')->where(
         'medical_provider_has_speciality_id',$medicalProviderHasSpecialties->id)
         ->where('service_id',$serviceId)->delete();
       return true;
     }
     else
     {
       return false;
     }
  }
  public function editServiceInSpecialty($serviceId,$specialtyId,$medicalProviderId,$price=0)
  {
     $medicalProviderHasSpecialties= MedicalProviderHasSpecialties::where('medical_provider_id',$medicalProviderId)->where('speciality_id',$specialtyId)->first();
     if(!empty($medicalProviderHasSpecialties))
     {

       DB::table('medical_provider_specialty_has_services')->where(
         'medical_provider_has_speciality_id',$medicalProviderHasSpecialties->id)
         ->where('service_id',$serviceId)->update(['price'=>$price]);
       return true;
     }
     else
     {
       return false;
     }
  }
  public function deleteAllServicesFromSpecialty($specialtyId,$medicalProviderId)
  {

     $medicalProviderHasSpecialties= MedicalProviderHasSpecialties::where('medical_provider_id',$medicalProviderId)->where('speciality_id',$specialtyId)->first();
     if(!empty($medicalProviderHasSpecialties))
     {
       DB::table('medical_provider_specialty_has_services')->where(
         'medical_provider_has_speciality_id',$medicalProviderHasSpecialties->id)
         ->delete();
       return true;
     }
     else
     {
       return false;
     }
  }
  public function services()
  {
      if(Auth::user()->token()->user_lang=='ar') {
          $lan = "name_ar As name";
          $orderCol= "name_ar";
      }
      else {
          $lan = "name_en As name";
          $orderCol= "name_en";
      }
      $services=Service::where("disabled","=",0)->where("deleted_at","=",null)->select(['id' , $lan])->orderBy($orderCol, 'asc')->paginate(30);
      return $services;
  }
  public function disable($id){
    $service=Service::find($id);
    $service->disabled=1;
    if($service->save()){
      return true;
    }else{
      return false;
    }

    return;
  }

    public function listServices ()
    {
        $listServices = Service::get();
        return $listServices;
    }
}
