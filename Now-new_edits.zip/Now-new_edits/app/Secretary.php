<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Mail;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
class Secretary extends Model
{
  use SoftDeletes;
  protected $dates=['deleted_at'];

  protected $hidden = [
      'created_at','updated_at'
  ];

  public function doctor(){
    return $this->belongsTo('App\Doctor');
  }
  public function user(){
    return $this->belongsTo('App\User');
  }



  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  public function addToDoctor($name,$email,$doctorId){
    //check if this mail found previously or not
    $secretaryUser=User::where('email',$email)->first();
    if(!$secretaryUser){

      $user=new User;
      $user->name=$name;
      $user->fullname=$name;
      $user->email=$email;
      $user->role_id=2;
      $user->token= Str::random(32);
      $password=bin2hex(openssl_random_pseudo_bytes(4));
      $user->password=bcrypt($password);
      if($user->save()){
        DB::insert('insert into user_roles(user_id,role_id) values (?,?)',[$user->id,9]);
        $secretary=new Secretary;
        $secretary->user_id=$user->id;
        $secretary->doctor_id=$doctorId;
        if($secretary->save()){
          // send email to secretary
          Mail::to($user)->send(new \App\Mail\NewSecretary($email,$password,$name ,$user->token));
          return true;
        }else{
          return false;
        }
      }else{
        return false;
      }
    }else{
      if($secretaryUser->isSecretary()){
        $secretaryData=Secretary::where('user_id',$secretaryUser->id)->first();
          if($secretaryData->doctor_id!==''&&$secretaryData->doctor_id!==null){
            return 'already_linked_to_doctor';
          }else{
            $secretaryData->doctor_id=$doctorId;
            if($secretaryData->save()){
              // send email to secretary
              Mail::to($secretaryUser)->send(new \App\Mail\MoveSecretary($secretaryData->user->name, $secretaryData->doctor->user->fullname_en ,$secretaryUser->token));
              return true;
            }else{
              return false;
            }
          }
      }else{
        return 'email_is_not_secretary';
      }
    }
    return ;
  }
  public function removeFromDoctor($secretaryId){
    //check if this mail found previously or not
    $secretary=Secretary::where('id',$secretaryId)->first();
    $secretary->doctor_id=0;
    $secretary->save();
    return true;
  }


  public function editSecretary($name='',$email='',$secretaryId){
    //check if this mail found previously or not
    $secretary=Secretary::where('id',$secretaryId)->first();
    if($secretary->doctor_id!==''&&$secretary->doctor_id!==null){
      return 'already_linked_to_doctor';
    }
    $user=User::where('id',$secretary->user_id)->first(); // check made in users table so mails not repeated between different types of users
    if($user){
      if($user->isSecretary()){
        if(!empty($name)){
          $user->name=$name;
          $user->fullname=$name;
        }
        if(!empty($email)){
            $user->email=$email;
        }
        $user->save(); //save data of the users table
        return true;
      }else{
        return 'email_is_not_secretary';
      }
  }else{
    return false;
  }
}
}
