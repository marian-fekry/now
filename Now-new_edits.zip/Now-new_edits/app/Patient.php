<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User as userRequest;
class Patient extends Model
{
  protected $fillable = [
  ];

  /**
   * The attributes that should be hidden for arrays.
   *
   * @var array
   */
  protected $hidden = [
      'created_at','updated_at'
  ];

  public function user(){
    return $this->belongsTo('App\User');
  }
    //user relation for request to use withTrashed
    public function userRequest(){
        return $this->belongsTo('App\User' ,  'user_id')->withTrashed();
    }

  public function createPatient($userId){
    $patient=new Patient;
    $patient->user_id=$userId;

    if($patient->save()){
      return true;
    }else{
      return false;
    }
    return;
  }
  public function editPatient($patientData,$patientId){
    $patient= User::find($patientId);
    if(isset($patientData['email'])){$patient->email=$patientData['email'];}
    if(isset($patientData['name'])){$patient->name=$patientData['name'];}
    if(isset($patientData['name'])){$patient->fullname=$patientData['name'];}
    if(isset($patientData['mobile'])){$patient->mobile=$patientData['mobile'];}
    if(isset($patientData['birthdate'])){$patient->birthdate=$patientData['birthdate'];}
    if(isset($patientData['gender'])){$patient->gender=$patientData['gender'];}

    if($patient->save()){
      return true;
    }else{
      return false;
    }

    return;
  }
}
