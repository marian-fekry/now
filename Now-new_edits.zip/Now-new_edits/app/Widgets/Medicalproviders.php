<?php
namespace App\Widgets;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use TCG\Voyager\Facades\Voyager;
use Arrilot\Widgets\AbstractWidget;

class Medicalproviders extends AbstractWidget
{

    protected $config = [];

    public function run()
    {
        $medicals=\App\MedicalProvider::all();
        $user=[];
        $i=0;
        foreach($medicals as $medical)
        {
            $record=\App\User::withTrashed()->find($medical->user_id);
            if($record->deleted_at == null && $record->disabled ==0)
            {
                $user[$i]=$record;
            }
            $i++;
        }
        $count = count($user);
        $string = 'Medical Providers ';

        return view('voyager::dimmer', array_merge($this->config, [
            'icon'   => 'voyager-bag',
            'title'  => "{$count} {$string}",
            'text'   => "You have {$count} {$string}.Click on button below to view all.",
            'button' => [
                'text' => 'Medical Provider',
                'link' => route('voyager.medical-providers.index'),
            ],
            'image' => 'images/medical.jpg',
        ]));
    }

    public function shouldBeDisplayed()
    {
        return auth()->user()->hasRole('admin');
    }
}
