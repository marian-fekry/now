<?php
namespace App\Widgets;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use TCG\Voyager\Facades\Voyager;
use Arrilot\Widgets\AbstractWidget;

class Secretaries extends AbstractWidget
{

    protected $config = [];

    public function run()
    {
        $secretaries=\App\Secretary::all();
        $user=[];
        $i=0;
        foreach($secretaries as $secretary)
        {
            $record=\App\User::withTrashed()->find($secretary->user_id);
            if($record->deleted_at == null && $record->disabled ==0)
            {
                $user[$i]=$record;
            }
            $i++;
        }
        $count = count($user);
        $string = 'Secretaries';

        return view('voyager::dimmer', array_merge($this->config, [
            'icon'   => 'voyager-bag',
            'title'  => "{$count} {$string}",
            'text'   => "You have {$count} {$string} . Click on button below to view all {$string}.",
            'button' => [
                'text' => 'Secretaries',
                'link' => route('voyager.secretaries.index'),
            ],
            'image' => 'images/secretaries.jpg',
        ]));
    }

    public function shouldBeDisplayed()
    {
        return auth()->user()->hasRole('admin');
    }
}
