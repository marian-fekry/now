<?php
namespace App\Widgets;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use TCG\Voyager\Facades\Voyager;
use Arrilot\Widgets\AbstractWidget;

class Doctors extends AbstractWidget
{

    protected $config = [];

    public function run()
    {
        $doctors=\App\Doctor::all();
        $user=[];
        $i=0;
        foreach($doctors as $doctor)
        {
            $record=\App\User::withTrashed()->find($doctor->user_id);
            if($record->deleted_at == null && $record->disabled ==0)
            {
                $user[$i]=$record;
            }
            $i++;
        }
        $count = count($user);
        $string = 'Doctors';

        return view('voyager::dimmer', array_merge($this->config, [
            'icon'   => 'voyager-bag',
            'title'  => "{$count} {$string}",
            'text'   => "You have {$count} {$string}. Click on button below to view all {$string}.",
            'button' => [
                'text' => 'Doctors',
                'link' => route('voyager.doctors.index'),
            ],
            'image' => 'images/doctors.jpg',
        ]));
    }

    public function shouldBeDisplayed()
    {
        return auth()->user()->hasRole('admin');
    }
}
