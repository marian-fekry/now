<?php
namespace App\Widgets;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use TCG\Voyager\Facades\Voyager;
use Arrilot\Widgets\AbstractWidget;
use App\Request;
class requests extends AbstractWidget
{

    protected $config = [];

    public function run()
    {
        $requests=Request::withTrashed()->get();
        $allrequest=[];
        $i=0;
        foreach($requests as $request)
        {
            if($request->deleted_at == null && $request->disabled ==0)
            {
                $allrequest[$i]=$request;
            }
            $i++;
        }
        $count = count($allrequest);
        $string = 'Requests ';

        return view('voyager::dimmer', array_merge($this->config, [
            'icon'   => 'voyager-bag',
            'title'  => "{$count} {$string}",
            'text'   => "You have {$count} {$string} . Click on button below to view all {$string}.",
            'button' => [
                'text' => 'Requests',
                'link' => route('voyager.requests.index'),
            ],
            'image' => 'images/request.jpg',
        ]));
    }

    public function shouldBeDisplayed()
    {
        return auth()->user()->hasRole('admin');
    }
}
