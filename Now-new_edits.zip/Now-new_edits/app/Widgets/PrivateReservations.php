<?php
namespace App\Widgets;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use TCG\Voyager\Facades\Voyager;
use Arrilot\Widgets\AbstractWidget;

class PrivateReservations extends AbstractWidget
{

    protected $config = [];

    public function run()
    {
        $privateReservations=\App\PrivateReservation::all();
        $user=[];
        $i=0;
        foreach($privateReservations as $privateReservation)
        {
            $record=\App\User::withTrashed()->find($privateReservation->user_id);
            if($record->deleted_at == null && $record->disabled ==0)
            {
                $user[$i]=$record;
            }
            $i++;
        }
        $count = count($user);
        $string = 'Private Reservation';

        return view('voyager::dimmer', array_merge($this->config, [
            'icon'   => 'voyager-bag',
            'title'  => "{$count} {$string}",
            'text'   => "You have {$count} {$string}. Click on button below to view all {$string}.",
            'button' => [
                'text' => 'Private Reservation',
                'link' => route('voyager.private-reservations.index'),
            ],
            'image' => 'images/private-reservations.jpg',
        ]));
    }

    public function shouldBeDisplayed()
    {
        return auth()->user()->hasRole('admin');
    }
}
