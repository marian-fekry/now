<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Validator;
use Auth;
use App\Http\Controllers\OutPut;
use App\User;
class MedicalProviderHasSpecialties extends Model
{
  protected $fillable = [
      'medical_provider_id' ,'speciality_id' , 'departement_secretary_id'
  ];


   //medical_provider relation
    public function medical_providers(){
        return $this->belongsTo('App\MedicalProvider' , 'medical_provider_id');
    }

  public function specialty(){
      return $this->belongsTo('App\Specialty' , 'speciality_id');
  }
  public function privateReservation(){
      return $this->belongsTo('App\PrivateReservation' , 'departement_secretary_id');
  }
    public function services(){
        return $this->belongsToMany('App\Service','medical_provider_specialty_has_services'  , 'medical_provider_has_speciality_id' , 'service_id')->withPivot('price');
    }

}
