<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use \App\User;
class UserEvent implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;
    public $user_id;
    public $type;
    public $PayLoad;
    public $name;
    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($user_id,$type="updateNewRequest",$name="new_request",$PayLoad=array())
    {
        $this->user_id=$user_id;
        $this->type=$type;
        $this->name=$name;
        $this->PayLoad=$PayLoad;

    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        //$url= url('/')."6001/apps/".env('appId', '')."/channels/private-user.".$this->user_id."/?auth_key=".env('key', '')."";
        //$url= "http://127.0.0.1:6001/apps/".env('appId', '')."/channels?auth_key=".env('key', '')."";
        $url= "http://now.gcssd.com:6001/apps/79fb1c7f94c4c111/channels/private-user.".$this->user_id."/?auth_key=b79b00014ab5b4d61ea56fc7a49e7dd7";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL,$url);
        $result=curl_exec($ch);
        curl_close($ch);
        $resultJson = json_decode($result, true);
            if ($resultJson['subscription_count'] > 0) {
                return new PrivateChannel('user.' . $this->user_id);
            }
    }
    public function broadcastAs()
    {
        return "UserEvent";
    }
    public function broadcastWith()
    {
        if($this->type=="updateOldRequest"){
            $number=(isset($this->PayLoad['notifications_number']))?$this->PayLoad['notifications_number']:0;
            return ['id'=>'user.'.$this->user_id.'_'.rand(),'type'=>$this->type,'name'=>$this->name,'PayLoad'=>$this->PayLoad];
        }else if($this->type=="updateCurrentRequest"){
            $number=(isset($this->PayLoad['notifications_number']))?$this->PayLoad['notifications_number']:0;
            return ['id'=>'user.'.$this->user_id.'_'.rand(),'type'=>$this->type,'name'=>$this->name,'PayLoad'=>$this->PayLoad];
        }else if($this->type=="updateNewRequest"){
            return ['id'=>'user.'.$this->user_id.'_'.rand(),'type'=>$this->type,'name'=>$this->name,'PayLoad'=>$this->PayLoad];
        }else if($this->type=="hasNewNotifications"){
            $number=(isset($this->PayLoad['notifications_number']))?$this->PayLoad['notifications_number']:0;
            return ['id'=>'user.'.$this->user_id.'_'.rand(),'type'=>$this->type,'name'=>$this->name,'number'=>$number];
        }

    }
}
