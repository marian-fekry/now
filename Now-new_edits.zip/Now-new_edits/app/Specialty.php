<?php

namespace App;
use App\User;
use App\MedicalProvider;
use App\MedicalProviderHasSpecialties;
use App\Service;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Pagination\Paginator;
use DB;
class Specialty extends Model
{
  use SoftDeletes;
  protected $dates=['deleted_at'];

  protected $hidden = [
      'created_at','updated_at','disabled'
  ];
  public function medical_providers(){
    return $this->belongsToMany('App\MedicalProvider','medical_provider_has_specialties' ,'medical_provider_id', 'speciality_id');
  }
    public function doctors()
    {
        return $this->hasMany('App\Doctor' , 'speciality_id');
    }
    public function services(){
        return $this->belongsToMany('App\Service','medical_provider_specialty_has_services' ,'medical_provider_has_speciality_id', 'service_id')->withPivot('price');
    }
    protected static function boot() {
        parent::boot();
        static::deleting(function($specialty) {
            $specialtiesMedical = DB::table('medical_provider_has_specialties')->where('speciality_id',$specialty->id)->get();
            if (count($specialtiesMedical) > 0) {
                throw new Exception(__('messages.this_specialty_have_medical') , '23000');
            }
            if ($specialty->doctors()->count() > 0) {
                throw new Exception(__('messages.this_specialty_have_doctors') , '23000');
            }
        });
    }


  public function addSpecialtyToProvider($specialtyId,$medicalProviderId)
  {
    $data=\App\MedicalProviderHasSpecialties::where('medical_provider_id',$medicalProviderId)->where('speciality_id',$specialtyId)->first();

    if(null==$data){
      $medicalProviderHasSpecialties=new MedicalProviderHasSpecialties;

      $medicalProviderHasSpecialties->medical_provider_id=$medicalProviderId;
      $medicalProviderHasSpecialties->speciality_id=$specialtyId;
       $medicalProviderHasSpecialties->timestamps = false;
      if($medicalProviderHasSpecialties->save()){
        return true;
      }else{
        return false;
      }
    }
    return;
  }
  public function deleteSpecialtyFromProvider($specialtyId,$medicalProviderId)
  {
    $medicalProviderHasSpecialties= MedicalProviderHasSpecialties::where('medical_provider_id',$medicalProviderId)->where('speciality_id',$specialtyId)->first();
    if(!empty($medicalProviderHasSpecialties))
    {
      // delete services first
      $service=new Service;
      $service->deleteAllServicesFromSpecialty($specialtyId,$medicalProviderId);

      // delete specialty
      $medicalProviderHasSpecialties->delete();
    }
    return true;
  }
  public function specialities()
  {
      if(Auth::user()->token()->user_lang=='ar') {
          $lan = "name_ar As name";
          $orderCol= "name_ar";
      }
      else {
          $lan = "name_en As name";
          $orderCol= "name_en";
      }
      $specialiy=Specialty::where("disabled","=",0)->where("deleted_at","=",null)->select(['id' , $lan])->orderBy($orderCol, 'asc')->paginate(30);
	    return $specialiy;
  }
  public function disable($id){
    $specialty=Specialty::find($id);
    $specialty->disabled=1;
    if($specialty->save()){
      return true;
    }else{
      return false;
    }

    return;
  }
  public function listSpecialties ()
  {
      $listSpecialties = Specialty::get();
      return $listSpecialties;
  }
}
