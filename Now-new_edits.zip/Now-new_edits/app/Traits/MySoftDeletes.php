<?php
namespace App\Traits;

use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;
trait MySoftDeletes
{
use SoftDeletes;

protected function runSoftDelete()
{
    $query = $this->newModelQuery()->where($this->getKeyName(), $this->getKey());

    $time = $this->freshTimestamp();

    $columns = [$this->getDeletedAtColumn() => $this->fromDateTime($time)];

    $this->{$this->getDeletedAtColumn()} = $time;

    if ($this->timestamps && ! is_null($this->getUpdatedAtColumn())) {
        $this->{$this->getUpdatedAtColumn()} = $time;

        $columns[$this->getUpdatedAtColumn()] = $this->fromDateTime($time);
    }

    $query->update($columns);
    $oldEmail=DB::table('users')->where('id',$this->getKey())->first(['email']);
    $newEmail=$oldEmail->email.$this->getKey();
    DB::table('users')->where('id', $this->getKey())->update(['email' => $newEmail]);
}
}
?>