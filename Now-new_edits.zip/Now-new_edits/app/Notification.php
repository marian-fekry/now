<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Database\Eloquent\SoftDeletes;
use Auth;
class Notification extends Model
{
  use SoftDeletes;
  protected $dates=['deleted_at'];
  protected $hidden = [
      'created_at','updated_at','disabled'
  ];
    public function request(){
        return $this->belongsTo('App\Request');
    }
    public function senderUser(){
        return $this->belongsTo('App\User', 'sender_id');
    }
    public function receiverUser(){
        return $this->belongsTo('App\User', 'receiver_id');
    }

    public function getnotifications($user){
      $notificationsArray=array();

      if($user->hasRole('ROLE_PATIENT')) {
          //$userId=$user->patient->id;

          $notifications=Notification::where([['receiver_id',$user->id],['disabled','0']])->with('request')->with('senderUser')->orderby('created_at','DESC')->paginate(30);
          foreach ($notifications as $notification)
          {
              if(Auth::user()->token()->user_lang=='ar') {
                  $doctorName = $notification->request->doctor->userRequest->fullname;
                  $medicalName = $notification->request->medical_provider->userRequest->fullname;
              }
              else {
                  $doctorName = $notification->request->doctor->userRequest->fullname_en;
                  $medicalName = $notification->request->medical_provider->userRequest->fullname_en;
              }
              array_push($notificationsArray , ['doctor_name'=>$doctorName ,'medical_name'=>$medicalName, 'status'=>$notification->status , 'date'=>$notification->request->date , 'time'=>$notification->request->time]);
          }
      }
      else
      {

        $notifications=array();
          if($user->hasRole('ROLE_SECRETARY')){
              // get doctor's notifications
              //1- get doctor's //
              $doctorUser=new User;
              $doctorId=$doctorUser->getDoctorUserIdFromSecretary($user->id);
              $notifications=Notification::where([['receiver_id',$doctorId],['disabled','0']])->with('request')->with('senderUser')->orderby('created_at','DESC')->paginate(30);

          }else if($user->hasRole('ROLE_HOSPITAL') ||$user->hasRole('ROLE_PRIVATE_CLINIC')||$user->hasRole('ROLE_SHARED_CLINIC')||$user->hasRole('ROLE_MEDICAL_PROVIDER')) {
              $doctorUser=new User;
              //$doctorsIds=$doctorUser->getDoctorsUserIdInProvider($user->id);
              $userId=$user->medicalprovider->id;
              //$notifications=Notification::whereIn('receiver_id',$doctorsIds)->where('disabled','0')->with('request')->with('senderUser')->orderby('created_at','DESC')->paginate(30);
              $notifications=Notification::with('request')->whereHas('request',function($q) use($userId) {
                $q->where('medical_provider_id',$userId);
              })->with('senderUser')->orderby('created_at','DESC')->paginate(30);
          }else if ($user->hasRole('ROLE_PRIVATE_RESERVATION')){

              $doctorUser=new User;
              $doctorsIds=$doctorUser->getDoctorsUserIdInPrivateReservation($user->id);
              $PRData=DB::table('medical_provider_has_specialties')->where('departement_secretary_id',  $user->privatereservation->id)->first();
              $PRMPID=$PRData->medical_provider_id;
              $notifications=Notification::with('request')->whereHas('request',function($q) use($PRMPID) {
                $q->where('medical_provider_id',$PRMPID);
              })->whereIn('receiver_id',$doctorsIds)->where('disabled','0')->with('senderUser')->orderby('created_at','DESC')->paginate(30);

          }else{//('ROLE_DOCTOR')
              $userId=$user->id;
              $notifications=Notification::where([['receiver_id',$userId],['disabled','0']])->with('request')->with('senderUser')->orderby('created_at','DESC')->paginate(30);
          }
          foreach ($notifications as $notification)
          {
            $patientName = $notification->request->patient->userRequest->fullname;
              if(Auth::user()->token()->user_lang=='ar') {
                  $doctorName = $notification->request->doctor->userRequest->fullname;
                  $senderName = $notification->senderUser->fullname;
                  $medicalName = $notification->request->medical_provider->user->fullname;
              }
              else {
                  $doctorName = $notification->request->doctor->userRequest->fullname_en;
                  if($notification->senderUser->isPatient()||$notification->senderUser->isSecretary()||$notification->senderUser->isPrivateReservation()){
                    $senderName = $notification->senderUser->fullname;
                  }else{
                    $senderName = $notification->senderUser->fullname_en;
                  }

                  $medicalName = $notification->request->medical_provider->userRequest->fullname_en;

              }
              array_push($notificationsArray , ['sender_name'=>$senderName ,'doctor_name'=>$doctorName ,'medical_name'=>$medicalName, 'patient_name'=>$patientName,'status'=>$notification->status , 'date'=>$notification->request->date , 'time'=>$notification->request->time]);
          }
      }

        $respone =  ['data'=>$notificationsArray , 'current_page'=>$notifications->currentPage() ,'total' =>$notifications->total() , 'count' =>$notifications->count() , 'last_page'=>$notifications->lastPage()];

        return $respone;
    }

    public function setnotification($senderId,$receiverId,$requestId,$status){
      $notification=new Notification;
      $notification->sender_id=$senderId;
      $notification->receiver_id=$receiverId;
      $notification->request_id=$requestId;
      $notification->status=$status;
      if($notification->save()){
        return true;
      }else{
        return false;
      }

      return;
    }
    public function markAsRead($userId){
      $user= User::find($userId);
      $user->notifications=0;
      if($user->save()){
        return true;
      }else{
        return false;
      }
      return;
    }

    public function addNotifiaction($userId){

      if(DB::table('users')->whereId($userId)->increment('notifications')){
        $user=\App\User::find($userId);
        \App\notifications::sendUserDataMessage($userId,'has_new_notifications', ["notifications_number"=>$user->notifications],"hasNewNotifications");
        return true;
      }else{
        return false;
      }
      return;
    }

    public function disable($id){
      $notification=Notification::find($id);
      $notification->disabled=1;
      if($notification->save()){
        return true;
      }else{
        return false;
      }

      return;
    }
}
