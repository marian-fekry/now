<?php

namespace App\Actions;

class DeactivateAction extends \TCG\Voyager\Actions\AbstractAction
{
    public function getTitle()
    {
        return 'Deactivate';//__('voyager::generic.delete');
    }

    public function getIcon()
    {
        return 'voyager-leaf';
    }

    public function getPolicy()
    {
        return 'delete';
    }

    public function getAttributes()
    {
        return [
            'class'   => 'deactivate btn btn-sm  pull-right ',
            'data-id' => $this->data->{$this->data->getKeyName()},
            'id'      => 'deactivate-'.$this->data->{$this->data->getKeyName()},
        ];
    }

    public function getDefaultRoute()
    {

          return route('voyager.'.$this->dataType->slug.'.deactivate', $this->data->{$this->data->getKeyName()});

    }
}
