<?php

namespace App\Actions;

class ActivateAction extends \TCG\Voyager\Actions\AbstractAction
{
    public function getTitle()
    {
        return 'Activate';//__('voyager::generic.delete');
    }

    public function getIcon()
    {
        return 'voyager-leaf';
    }

    public function getPolicy()
    {
        return 'delete';
    }

    public function getAttributes()
    {
        return [
            'class'   => 'activate btn btn-sm  pull-right ',
            'data-id' => $this->data->{$this->data->getKeyName()},
            'id'      => 'activate-'.$this->data->{$this->data->getKeyName()},
        ];
    }

    public function getDefaultRoute()
    {

      return route('voyager.'.$this->dataType->slug.'.activate', $this->data->{$this->data->getKeyName()});

    }
}
