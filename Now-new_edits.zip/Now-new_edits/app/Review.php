<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Review extends Model
{
  use SoftDeletes;
  protected $dates=['deleted_at'];

  protected $hidden = [
      'created_at','updated_at','disabled'
  ];

  public function addDoctorReview($userId,$doctorId,$rate,$appointmentId,$comment=''){
    $review=new Review;
    // to prevent inserting unwanted values for rate
    $rate=($rate>5)?5:$rate;
    $rate=($rate<0)?0:$rate;
    $review->rating=$rate;
    $review->comment=$comment;
    $review->doctor_id=$doctorId;
    $review->patient_id=$userId;
    $review->appointment_id=$appointmentId;
    if($review->save()){
      return true;
    }else{
      return false;
    }

    return;
  }
  public function disable($id){
    $review=Review::find($id);
    $review->disabled=1;
    if($review->save()){
      return true;
    }else{
      return false;
    }

    return;
  }
}
