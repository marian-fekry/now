<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\SoftDeletes;
use Exception ;
class Region extends Model
{
  use SoftDeletes;
  protected $dates=['deleted_at'];

    protected $fillable = [
        'name_ar', 'name_en'
    ];
    protected $hidden = [
        'created_at', 'updated_at','disabled'
    ];
    public function governrates()
    {
        return $this->hasMany('App\Governrate');
    }

    protected static function boot() {
        parent::boot();
        static::deleting(function($region) {
            if ($region->governrates()->count() > 0)
            {
                throw new Exception(__('messages.this_region_have_governrates') , '23000');
            }
        });
    }
    public function index($lang)
    {
        $user=Auth::user();
        if(isset($user)) {
           if (Auth::user()->token()->user_lang == 'ar') {
               $lan = "name_ar As name";
               $orderCol= "name_ar";
           } else {
               $lan = "name_en As name";
               $orderCol= "name_en";
           }
       }
        else
        {
            if ($lang == 'ar') {
                $lan = "name_ar As name";
                $orderCol= "name_ar";
            } else {
                $lan = "name_en As name";
                $orderCol= "name_en";
            }
        }
        $regions = Region::where('deleted_at' , '=' , Null)->where('disabled' , '=' , 0)->select(['id' ,$lan])->orderBy($orderCol, 'asc')->paginate(30);
        return $regions;
    }
    public function disable($id){
      $region=Region::find($id);
      $region->disabled=1;
      if($region->save()){
        return true;
      }else{
        return false;
      }

      return;
    }
}
