<?php

namespace App;

use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\SoftDeletes;
//use Illuminate\Database\Eloquent\SoftDeletes;


class Governrate extends Model
{
  use SoftDeletes;
  protected $dates=['deleted_at'];

//  use SoftDeletes;
    //protected $dates=['deleted_at'];

    protected $fillable = [
        'name_ar', 'name_en'
    ];
    protected $hidden = [
        'created_at', 'updated_at','disabled'
    ];
    public function medicalProviders()
    {
        return $this->hasMany('App\MedicalProvider');
    }

    protected static function boot() {
        parent::boot();
        static::deleting(function($governrate) {
            if ($governrate->medicalProviders()->count() > 0)
            {
                throw new Exception(__('messages.this_governrate_have_medical') , '23000');
            }
        });
    }
    public function region(){
        return $this->belongsTo('App\Region' , 'region_id' , 'id' );
    }
    public function index($id=0 ,$lang)
    {
        $user=Auth::user();
        if(isset($user)){
            if(Auth::user()->token()->user_lang=='ar') {
                $lan = "name_ar As name";
                $orderCol= "name_ar";
            } else {
                $lan = "name_en As name";
                $orderCol= "name_en";
            }
        }
        else
        {
            if($lang=='ar') {
                $lan = "name_ar As name";
                $orderCol= "name_ar";
            } else {
                $lan = "name_en As name";
                $orderCol= "name_en";
            }
        }

        if($id==0){
          $governrates = Governrate::where('deleted_at' , '=' , Null)->where('disabled' , '=' , 0)->whereHas('region',function($query){
              $query->where('disabled',0)->where('deleted_at' , '=' , Null);
          })->orderBy($orderCol, 'asc')->select(['id' ,$lan])->paginate(30);
        }else{
          $governrates = Governrate::where('region_id',$id)->where('deleted_at' , '=' , Null)->where('disabled' , '=' , 0)->select(['id' ,$lan])->paginate(30);
        }


        return $governrates;
    }
    public function disable($id){
      $governrate=Governrate::find($id);
      $governrate->disabled=1;
      if($governrate->save()){
        return true;
      }else{
        return false;
      }

      return;
    }
}
