<?php

namespace App;

use Exception;
use Illuminate\Database\Eloquent\Model;
use Validator;
use Auth;
use App\Http\Controllers\OutPut;
use App\User;
use DB;
class MedicalProvider extends Model
{
  protected $fillable = [
      'name_en' ,'type' , 'brief' , 'brief_en' ,'address' , 'address_en'
  ];

  /**
   * The attributes that should be hidden for arrays.
   *
   * :var array
   */
  protected $hidden = [
      'created_at','updated_at'
  ];


    // governrate relation
    public function governrate(){
        return $this->belongsTo('App\Governrate' , 'governrate_id');
    }
  //user relation
  public function user(){
    return $this->belongsTo('App\User');
  }
    //user relation for request to use withTrashed
    public function userRequest(){
        return $this->belongsTo('App\User' ,  'user_id')->withTrashed();
    }
  // doctor relation
  public function doctor(){
    return $this->belongsToMany('App\Doctor','doctor_has_medical_provider');
  }
  public function specialty(){
    return $this->belongsToMany('App\Specialty','medical_provider_has_specialties' , 'medical_provider_id', 'speciality_id') ;
  }
  public function service(){

    return $this->belongsToMany('App\MedicalProviderHasSpecialties','medical_provider_specialty_has_services' , 'medical_provider_has_speciality_id')->withPivot('price');
  }
    public function doctors(){
        return $this->belongsToMany('App\Doctor','doctor_has_medical_provider','medical_provider_id','doctor_id');
    }

    public function doctorUser() {
        return $this->belongsToMany('App\Doctor','doctor_has_medical_provider','medical_provider_id','doctor_id')
            ->with('user')
            ->join('users', 'doctors.user_id', '=', 'users.id')
            ->where('users.disabled' ,'0')
            ->orderBy('users.fullname_en', 'asc');
    }
    public function privateReservationSpecialty(){
        return $this->belongsToMany('App\Specialty','medical_provider_has_specialties' , 'speciality_id' , 'speciality_id');
    }

    public function subscriptionOrder(){
        return $this->hasOne('App\SubscriptionOrder','medical_provider_id');
    }

    protected static function boot() {
        parent::boot();
        static::deleting(function($medicalProvider) {
            if ($medicalProvider->doctors()->count() > 0)
            {
                throw new Exception(__('messages.this_governrate_have_medical') , '23000');
            }
        });
    }



    public function createProvider($userId){
    $medicalprovider=new MedicalProvider;
    $medicalprovider->user_id=$userId;

    if($medicalprovider->save()){
      return true;
    }else{
      return false;
    }

    return;
  }

  public function editProvider($name='',$name_en='' ,$email='',$brief='',$location='',$governerte='',$degree='' ,$type='' ,$specialty=array() ,$userId){

    $user=User::find($userId);
    if(!empty($name)){
        $user->fullname=$name;
        $user->name=$name;
    }
      if(!empty($name_en)){
          $user->fullname_en=$name_en;
      }
    if(!empty($email)){
        $user->email=$email;
    }
      $user->save();
      $medicalprovider = MedicalProvider::where('user_id',$userId)->first();
      if(!empty($brief)){
          if(Auth::user()->token()->user_lang=='ar') {
              $medicalprovider->brief=$brief;
          }
          else {
              $medicalprovider->brief_en=$brief;
          }

      }
      if(!empty($name_en)){
          $medicalprovider->name_en=$name_en;
      }

      if(!empty($type)){
          $medicalprovider->type=$type;
          $providerRole='11';
          if($type=='private_clinic'){
            $providerRole='7';
          }else if($type=='shared_clinic'){
            $providerRole='8';
          }else if($type=='hospital'){
            $providerRole='6';
          }
          DB::table('user_roles')->updateOrInsert(['user_id'=>$user->id],['role_id'=>$providerRole]);
      }
      if(!empty($location)){
          if(Auth::user()->token()->user_lang=='ar') {
              $medicalprovider->address=$location;
          }
          else {
              $medicalprovider->address_en=$location;
          }
      }

      if(!empty($governerte)){
          $medicalprovider->governrate_id=$governerte;
      }

      $medicalprovider->save();


      $doctor = Doctor::where('user_id',$userId)->with('medical_providers')->first();
      if(!is_null($doctor))
      {
         if(!empty($degree)) {
             $doctor->jobtitle = $degree ;
         }
          if(sizeof($specialty)>0 and isset($specialty['0']['speciality_id'] )) {
              $doctor->speciality_id = $specialty['0']['speciality_id'] ;
          }
          $doctor->save();
          $doctor->medical_providers()->sync($medicalprovider->id);
      }
      else {
        if($type=='private_clinic'){
          $doctorNew = new Doctor;
          $doctorNew->user_id = $userId ;
          if(!empty($degree)) {
              $doctorNew->jobtitle = $degree ;
          }
          if(sizeof($specialty)>0 && isset($specialty['0']['speciality_id'] )) {
              $doctorNew->speciality_id = $specialty['0']['speciality_id'] ;
          }
          $doctorNew->save();
          $doctor = Doctor::where('user_id',$userId)->with('medical_providers')->first();
            $doctor->medical_providers()->sync($medicalprovider->id);
        }


      }

     if($user->save()) {
         return true ;
     }else{
         return false;

     }
      return;
  }


    public function liteDoctorsSearch($doctor_name , $speciality_id , $region_id , $governrate_id ,$degree_id , $service_id ,$minPrice , $maxPrice , $userId  ){
        $searchResults=DB::select("CALL  search_bulk (?,?,?,?,?,?,?,?,?);",
            [$service_id,$userId,$doctor_name==''?'%%':"$doctor_name",$speciality_id,$degree_id==0?'%%':"$degree_id",$region_id==0?'%%':"$region_id",$governrate_id==0?'%%':"$governrate_id",$minPrice,$maxPrice]);


            $medicalProvidersArray=[];
        foreach($searchResults as $searchResult){
            array_push($medicalProvidersArray, ['provider_id' => $searchResult->provider_id, 'doctor_id' => $searchResult->doctor_id] );
        }
        return $medicalProvidersArray ;
    }
    /*
 search doctors and return array of doctor id and provider id only
 return array('0'=>['doctor_id'=>'','provider_id'=>''],'1'=>['doctor_id'=>'','provider_id'=>''],..........................)
 */


    public function detailedDoctorsSearch($doctor_name , $medical_name ,  $speciality_id , $region_id , $governrate_id ,$degree_id , $service_id ,$minPrice , $maxPrice , $userId,$page=1,$lang){
    $SearchData=DB::select("CALL search_detailed(?,?,?,?,?,?,?,?,?,?,?,?,?,?);",
    [$service_id==''?'%%':"$service_id",$userId,$doctor_name==''?'%%':'%'.$doctor_name.'%',$medical_name==''?'%%':'%'.$medical_name.'%',$speciality_id==''?'%%':"$speciality_id",$degree_id==0?'%%':"$degree_id",$region_id==0?'%%':"$region_id",$governrate_id==0?'%%':"$governrate_id",$minPrice,$maxPrice,(($page-1)*30),30,$lang,url('storage/')]);

    $SearchDataNumber=DB::select("CALL total_search_result(?,?,?,?,?,?,?,?,?,?);",
    [$service_id==''?'%%':"$service_id",$userId,$doctor_name==''?'%%':'%'.$doctor_name.'%',$medical_name==''?'%%':'%'.$medical_name.'%',$speciality_id==''?'%%':"$speciality_id",$degree_id==0?'%%':"$degree_id",$region_id==0?'%%':"$region_id",$governrate_id==0?'%%':"$governrate_id",$minPrice,$maxPrice]);

        //if (preg_match('/[اأإء-ي]/ui', $doctor_name))

        $total=0;
        foreach($SearchDataNumber as $number){
            $total=$number->total;
            break;
        }
        $respone =  ['data'=>$SearchData, 'current_page' => $page ,'total' => $total ,'last_page'=>ceil($total/30)];

        return $respone;



    }

    public function listMedicalProviders ()
    {
        $listMedicalProviders = MedicalProvider::get();
        return $listMedicalProviders;
    }

    public function medicalProviderInfo($medicalId , $specialityId )
    {

        $medicalProvider = MedicalProvider::where('id', $medicalId)->first();
        if(Auth::user()->token()->user_lang=='ar') {
            $breif = $medicalProvider->brief;
        } else {
            $breif = $medicalProvider->brief_en;
        }
        $servicesArray = $this->medicalProviderSpecialties($medicalId ,$specialityId );

        $respone =  ['brief'=>$breif , 'medical_provider_img'=>url('storage/'.$medicalProvider->user->avatar),  'services'=>$servicesArray,'latitude'=>$medicalProvider->latitude,'longitude'=>$medicalProvider->longitude ];

        return $respone;
    }


    public function medicalProviderSpecialties($medicalId , $specialityId)
    {
        $servicesArray = [];
        $specialties = MedicalProviderHasSpecialties::where('medical_provider_id', $medicalId )->where('speciality_id',$specialityId)->get();
        for ($i=0 ; $i<count($specialties) ;$i++) {

            for ($s = 0; $s < count($specialties[$i]->services); $s++) {
                if (Auth::user()->token()->user_lang == 'ar') {
                    $serviceName = $specialties[$i]->services[$s]['name_ar'];
                } else {
                    $serviceName = $specialties[$i]->services[$s]['name_en'];
                }
                $medicalproviderServices = ['service_name' => $serviceName, 'service_price' => $specialties[$i]->services[$s]['pivot']['price']];
                array_push($servicesArray, $medicalproviderServices);
            }
        }
        return $servicesArray ;
    }

    public function updateWhereId($array ,$id)
    {
        $medical = MedicalProvider::find( $id );
        foreach ($array as $key=>$value){
            $medical->{$key}=$value;
        }
        $medical->save();
        return true ;
    }

    public function getWhereId($selectArray , $id)
    {
        $medical = MedicalProvider::find( $id);
        $respone=[];
        foreach ($selectArray as $select)
        {
         array_push($respone , [$select=>$medical->{$select}]);
        }
        return $respone;
    }


}
