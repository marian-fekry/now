<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;
use Illuminate\Support\Str;
use Mail;
use Illuminate\Support\Facades\DB;
class Doctor extends Model
{
  protected $hidden = [
      'created_at','updated_at'
  ];
    // users relation
    public function user(){
      return $this->belongsTo('App\User');
    }
    //user relation for request to use withTrashed
    public function userRequest(){
        return $this->belongsTo('App\User' ,  'user_id')->withTrashed();
    }
    // secretary relation

    // specialty realtion

    //medical provider relation
    public function medical_providers(){
      return $this->belongsToMany('App\MedicalProvider','doctor_has_medical_provider');
    }
    public function  secretary(){
        return $this->hasOne('App\Secretary' , 'doctor_id' , 'id');
    }
    public function speciality(){
        return $this->belongsTo('App\Specialty' , 'speciality_id' , 'id' );
    }
    public function jobTitle(){
        return $this->belongsTo('App\Jobtitle' , 'jobtitle' , 'id' );
    }
    public function reviews(){
        return $this->hasMany('App\Review');
    }


    public function addDoctorToMedicalProvider($name,$email,$degree,$specialtyId,$secretary=array(),$medicalProviderId){
      //check if this mail found previously or not
      $isFound=User::where('email',$email)->get(); // check made in users table so mails not repeated between different types of users
      if($isFound->isEmpty()){

        $user=new User;
        $user->name=$name['en'];
        $user->fullname=$name['ar'];
        $user->fullname_en=$name['en'];
        $user->email=$email;
        $user->role_id=2;
        $password=bin2hex(openssl_random_pseudo_bytes(4));
        $user->password=bcrypt($password);
        $user->token= Str::random(32);

        if($user->save()){
          DB::insert('insert into user_roles(user_id,role_id) values (?,?)',[$user->id,5]);
          $doctor=new Doctor;
          $doctor->user_id=$user->id;
          $doctor->name_en=$name['en'];
          $doctor->jobtitle=$degree;
          $doctor->speciality_id=$specialtyId;


          if($doctor->save()){
            //add doctor id and medical provider id to the pivot table
            $doctor->medical_providers()->attach($medicalProviderId);
            // send email to doctor
            Mail::to($user)->send(new \App\Mail\NewDoctor($email,$password, $name['en'],$user->token));
            // add secretary to doctor if Found
            if(!empty($secretary)){
              $createSecretary=new Secretary;
              $createSecretary->addToDoctor($secretary['name'],$secretary['email'],$doctor->id);
            }
            return true;
          }else{
            return false;
          }
        }else{
          return false;
        }
      }else{
        //add doctor to medical provider in the pivot table
        $doctor=Doctor::with('user')->whereHas('user',function($query) use ($email){
          $query->where('email',$email)->where('verified',1);
        })->first();
        if(null!==$doctor){
          $doctor->medical_providers()->attach($medicalProviderId);
          if(!empty($secretary)){
            $secretaryEX = User::where('email' , $secretary['email']);
            if(!empty($secretaryEX)){
                $createSecretary=new Secretary;
                $createSecretary->addToDoctor($secretary['name'],$secretary['email'],$doctor['0']->id);
            }
          }
          return true;
        }

      }

      return;
    }


    public function removeDoctorFromMedicalProvider($doctorId,$medicalProviderId){

      $doctor=Doctor::find($doctorId);
      $doctor->medical_providers()->detach($medicalProviderId);
      return;
    }


    public function editDoctor($doctorId,$name='',$email='',$degree='',$specialty=''){
      $doctor=\App\Doctor::where('id',$doctorId)->first();
      //check if this mail found previously or not
      $user=\App\User::find($doctor->user_id); // check made in users table so mails not repeated between different types of users
      if($user){
        if(!empty($name)){
            $user->name=$name;
        }
        if(!empty($email)){
            $user->email=$email;
        }

        $user->save(); //save data of the users table


        if(!empty($degree)||!empty($specialty)){
            if(!empty($degree)){$doctor->jobtitle=$degree;}
            if(!empty($specialty)){$doctor->speciality_id=$specialty;}
            $doctor->save();
        }
      return true;
    }else{
      return false;
    }
  }

    public function addDoctorAdmin($name,$email, $password ,$fullname , $jobtitle, $name_en   ,$speciality_id  ,$imagePath = '',$medicalProviderIds){
        //check if this mail found previously or not
        $isFound=User::where('email',$email)->get(); // check made in users table so mails not repeated between different types of users

        if(count($isFound)==0){
            $user=new User;
            $user->name = $name;
            $user->email = $email;
            $user->fullname = $fullname;
            $user->fullname_en = $name_en;
            $user->avatar= "users/".$imagePath;
            $user->password=bcrypt($password);
            $user->role_id='2';
            $user->token= Str::random(32);

            if($user->save()){
                $savedUser = $user->save();
                DB::table('user_roles')->insert(['user_id' => $user->id, 'role_id' => 5]);
                $doctor=new Doctor;
                $doctor->user_id=$user->id;
                $doctor->jobtitle=$jobtitle;
                $doctor->name_en =$name_en;
                $doctor->speciality_id=$speciality_id;

                if($doctor->save()){
                    $newDoctor = Doctor::find($doctor->id);
                    $newDoctor->medical_providers()->attach($medicalProviderIds);
                    Mail::to($user)->send(new \App\Mail\NewDoctor($email,$password,$name_en, $user->token));
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }

    }


    public function editDoctorAdmin($id , $name,$email ,$password,$fullname , $jobtitle, $name_en   ,$speciality_id  ,$medicalProviderIds,$imagePath = ''){
        $doctorModel =new Doctor;
        $doctor = $doctorModel->find($id);
        $doctor->jobtitle = $jobtitle;
        $doctor->speciality_id = $speciality_id;
        $doctor->name_en =$name_en;
            if($doctor->save()){
                $userModel = new User;
                $user = $userModel->find($doctor->user_id);
                $user->name = $name;
                $user->email = $email;
                $user->fullname = $fullname;
                $user->fullname_en = $name_en;
                $user->avatar= "users/".$imagePath;
                if($password != "") {
                    $user->password = bcrypt($password);
                }
                if($user->save()){
                    //$doctor->medical_providers()->detach();
                    if(!is_null($medicalProviderIds))
                    $doctor->medical_providers()->sync($medicalProviderIds);
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }

    }


}
