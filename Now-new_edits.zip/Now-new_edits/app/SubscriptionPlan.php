<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
class SubscriptionPlan extends Model
{
    //
    protected $hidden = [
        'created_at','updated_at'
    ];

    public function index($governrate_id)
    {
        if (Auth::user()->token()->user_lang == 'ar') {
            $title = "name_ar As name";
            $body = "body_ar As body";
        } else {
            $title = "body_en As name";
            $body = "body_en As body";
        }
        $userId=Auth::user()->id;
        $medicalProvider=\App\MedicalProvider::where('user_id',$userId)->first();
        $medicalProviderId=$medicalProvider->id;
        $plans = SubscriptionPlan::where('disabled' , '=' , 0)->select(['id' ,$title ,$body ,'price','frequency'])->paginate(30);
        $respone=[];
        foreach ($plans as $plan)
        {
            $meta=array();
            if($plan->id==1){
                $subscriptionOrder= new \App\SubscriptionOrder();
                $highestBid=$subscriptionOrder->getHighestBid();

                $meta=array('highestBid'=>$highestBid);
            }else if($plan->id==3){
                $governeratesTimeReservation= new \App\GoverneratesTimeReservations();
                $lastReservedMin=$governeratesTimeReservation->getGovernerateReservedMinutes($governrate_id);
                $meta=array('lastReservedMin'=>$lastReservedMin);
            }

            $subscriptionOrders=SubscriptionOrder::where('medical_provider_id',$medicalProviderId)->where('subscription_plan_id',$plan->id)->where('status','Active')->get();
            if($subscriptionOrders){
                $data=[];

                foreach ($subscriptionOrders as $subscriptionOrder) {
                    if($subscriptionOrder->subscriptionPlans->frequency=='Month') {
                     $endDate=$subscriptionOrder->created_at->addMonths(1)->toDateString();
                    }
                    else {
                        $endDate=$subscriptionOrder->created_at->addWeek(1)->toDateString();
                    }
                    array_push($data , [
                        'amount' => $subscriptionOrder->amount,
                        'start_date'=>$subscriptionOrder->created_at->toDateString(),
                        'end_date'=>$endDate,]  );
                }
            }
            array_push($respone ,['id'=>$plan->id , 'name'=>$plan->name  , 'body'=>$plan->body , 'price'=>$plan->price, 'frequency'=>$plan->frequency,'meta'=>$meta,'order'=>$data]);

        }


       return $respone;
    }

    public function getPlan($id)
    {
        if (Auth::user()->token()->user_lang == 'ar') {
            $title = "name_ar As name";
            $body = "body_ar As body";
        } else {
            $title = "body_en As name";
            $body = "body_en As body";
        }
        $plan = SubscriptionPlan::where('id' , $id)->select(['id' ,$title ,$body ,'price'])->first();
        return $plan;
    }

}
