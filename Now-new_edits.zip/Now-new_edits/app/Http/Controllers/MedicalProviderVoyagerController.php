<?php

namespace App\Http\Controllers;

use App\Doctor;
use App\Governrate;
use App\Jobtitle;
use App\MedicalProvider;
use App\Service;
use App\Specialty;
use App\MedicalProviderHasSpecialties ;
use Exception;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Str;
use phpDocumentor\Reflection\Types\Array_;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
use TCG\Voyager\Http\Controllers\VoyagerBaseController as BaseVoyagerController;
use Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Storage;
use Image;
use Mail;
class MedicalProviderVoyagerController extends BaseVoyagerController
{
    public function index(Request $request)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $dataTypeContent=[];
            $medicalproviders=MedicalProvider::orderBy("id","desc")->paginate(10);
            $i=0;
            $dataTypeContent=[];
            if($medicalproviders)
            {
                foreach ($medicalproviders as $key=>$medicalprovider)
                {
                    $user=User::find($medicalprovider->user_id);
                    if($user)
                    {
                        if($medicalprovider->governrate_id != "")
                        {
                            $governratename=Governrate::find($medicalprovider->governrate_id);
                            $user["governrate"]=$governratename->name_en;
                        }
                        $governratename=Governrate::find($medicalprovider->governrate_id);
                        if($governratename)
                        {
                            $user["governrate"]=$governratename->name_en;

                        }
                        $user["brief"]=$medicalprovider->brief;
                        $user["address"]=$medicalprovider->address;
                        $user["typemedical"]=$medicalprovider->type;
                        $dataTypeContent[$i]=$user;
                        $i++;
                    }
                }

            }
            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;

            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

            $view = "vendor.voyager.medical-providers.browse";

            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($dataTypeContent) && !empty($dataTypeContent['0']->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $dataTypeContent['0']->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }
            return Voyager::view($view, compact(
                'actions',
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'medicalproviders'
                          ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
    public function update(Request $request, $id)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Compatibility with Model binding.
        $id = $id instanceof Model ? $id->{$id->getKeyName()} : $id;

        $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

        // Check permission
        $this->authorize('edit', $data);

        // Validate fields with ajax
        $val = $this->validateBread($request->all(), $dataType->editRows, $dataType->name, $id);
        $medicalProviderModel = new MedicalProvider();
        $medicalProvider = $medicalProviderModel->where('user_id', $id)->first();

//        if ($val->fails()) {
//            return response()->json(['errors' => $val->messages()]);
//        }
        $valid=Validator::make($request->all(),[
            'name' => [
                'required', 'Filled' , 'string' ,
                Rule::unique('users')->ignore($id),
            ],
            'fullname' => [
                'required', 'Filled'  , 'string' ,
            ],
            'email' => [
                'required', 'Filled' , 'E-Mail' , 'string' ,
                Rule::unique('users')->ignore( $id),
            ],
            'name_en' => [
                'required', 'Filled'  , 'string' ,
                //Rule::unique('medical_providers')->ignore( $medicalProvider->id),
            ],
            'typemedical' => [
                'required',
            ],
            'edit_governrate' => [
                'required',
            ],
            'edit_job'=>'required_if:typemedical,private_clinic|Filled|string',

        ],["edit_governrate"=>"Edit Governorate Is Required"])->validate();

//        if($valid->fails()) {
//           return response()->json(['errors' => $valid->messages()]);
//        }


        if (!$request->ajax()) {
            $usermedical= User::find($id);
            $usermedical->name=$request->name;
            $usermedical->fullname=$request->fullname;
            $usermedical->fullname_en=$request->name_en;
            $usermedical->email= $request->email;
            if($request->password != "") {
                $usermedical->password = bcrypt($request->password);
            }
            $usermedical->save();
            $medicalProvider->type=$request->typemedical;
            $medicalProvider->name_en=$request->name_en;
            $medicalProvider->brief=$request->brief;
            $medicalProvider->brief_en=$request->brief_en;
            $medicalProvider->address=$request->address;
            $medicalProvider->address_en=$request->address_en;
            $medicalProvider->governrate_id=$request->edit_governrate;
            if($medicalProvider->save())
            {
                if(!empty($request->file('logo'))) {
                    $imagePath = $request->file('logo')->store('');
                    $image = Image::make(Storage::get($imagePath))->encode();
                    Storage::put($imagePath,$image);
                    User::where('id', $data->id)->update(['avatar' => "users/".$imagePath]);
                }
                User::where('id', $data->id)->update(['fullname_en' => $request->name_en]);
                if($request->edit_job!='') {
                    Doctor::where('id', $request->doctor_id)->update(['jobtitle' => $request->edit_job]);
                }

                if($request->service && $request->specialtiyId!='')
                foreach ($request->service as $key=>$value)
                {
                    foreach ($request->service[$key] as $key2=>$value2) {
                        $ServiceSpecialty = new Service;
                        $ServiceSpecialty->addServiceToSpecialty($request->service[$key][$key2] , $request->specialtiyId[$key][$key2] , $medicalProvider->id , $request->price[$key][$key2]);
                    }
                }

                if(isset($request->specialtiy))
                {
                    foreach ($request->specialtiy as $key=>$value)
                    {

                        $medicalProviderHasSpecialties = new Specialty;
                        $medicalProviderHasSpecialties->addSpecialtyToProvider($request->specialtiy[$key] , $medicalProvider->id);
                        foreach ($request->service[$key] as $key2=>$value2) {
                            $serviceSpecialty = new Service; ;
                            $serviceSpecialty->addServiceToSpecialty($request->service[$key][$key2] , $request->specialtiy[$key] ,$medicalProvider->id , $request->price[$key][$key2] );
                        }
                    }
                }


            }
            $countParametersUrl = count(explode('&', $request->redirects_to));
            if($countParametersUrl>1) {
                $parametersString = explode('?', $request->redirects_to);
                preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
                $parameterString = "";
                for ($i = 0; $i < $countParametersUrl; $i++) {
                    $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
                }
                $routeName = "medical.search";
            }
            else{
                $previousUrl = explode('page=' , $request->redirects_to);
                $routeName = "voyager.medical-providers.index";
                $parameterString= "page=";
                $parameterString.= $previousUrl['1'] ?? 1;
            }
            event(new BreadDataUpdated($dataType, $data));

            return redirect()
                ->route($routeName , [$parameterString])
                ->with([
                    'message'    => __('voyager::generic.successfully_updated')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function edit(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        $dataTypeContent=User::find($id);
        foreach ($dataType->editRows as $key => $row) {
            $dataType->editRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }

        //$medical=DB::table('medical_providers')->Where("user_id","=",$dataTypeContent->id)->get();
        $medical=MedicalProvider::where('user_id',$dataTypeContent->id)->with('doctors')->get();
        $govermentName = Governrate::find($medical['0']->governrate_id);
        $dataTypeContent->name_en =$dataTypeContent->fullname_en;//$medical[0]->name_en;
        $dataTypeContent->typemedical=$medical[0]->type;
        $dataTypeContent->brief=$medical[0]->brief;
        $dataTypeContent->brief_en =$medical[0]->brief_en ;
        $dataTypeContent->address=$medical[0]->address;
        $dataTypeContent->address_en =$medical[0]->address_en;
        $dataTypeContent->governrateid=$medical[0]->governrate_id;
        $dataTypeContent->doctors=$medical[0]->doctors;
        $dataTypeContent->governratename= (isset($govermentName->name_ar)) ? $govermentName->name_ar : '';
        $allgovernrate=Governrate::where("disabled","=",0)->paginate(10);
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'edit');

        // Check permission
        $this->authorize('edit', $dataTypeContent);

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $services = new Service();
        $listServices = $services->listServices();
        $specialties = new Specialty();
        $listSpecialties= $specialties->listSpecialties();
        $medicalProviderSpecialties = DB::table('medical_provider_has_specialties')->where('medical_provider_id', $medical[0]->id)->get(['speciality_id','id']);
        $medicalProviderServices = [];
            foreach($medicalProviderSpecialties as $medicalProviderSpecialtie)
            {
                $medicalServices = DB::table('medical_provider_specialty_has_services')->where('medical_provider_has_speciality_id', $medicalProviderSpecialtie->id)->get();
                for ($i=0 ;$i<count($medicalServices) ;$i++)
                {
                    $medicalProviderServices[$medicalProviderSpecialtie->speciality_id][$i] =  ['service'=>$medicalServices[$i]->service_id  ,'price'=> $medicalServices[$i]->price] ;
                }

            }

        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        $allServices=Service::where("disabled","=",0)->where('deleted_at' , "=" , Null)->paginate(10);
        $listSpecialties=Specialty::where("disabled","=",0)->where('deleted_at' , "=" , Null)->paginate(10);
        $alljobs=Jobtitle::where("disabled","=",0)->paginate(10);
        $jobs=[];
        $i=0;
        if($alljobs)
        {
            foreach ($alljobs as $job)
            {
                $jobs[$i]=$job;
                $i++;
            }

        }
        $specialtiesRender =  str_replace(array("\n", "\r"), '', $listSpecialties->render());
        $servicesRender =  str_replace(array("\n", "\r"), '', $allServices->render());;
        $newGovernrate = Governrate::find($request->old('edit_governrate'));
        $dataTypeContent['governrate_name']= $newGovernrate['name_ar'] ;
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable' , 'listServices' , 'listSpecialties' , 'medicalProviderSpecialties' , 'medicalProviderServices','allgovernrate', 'allServices' , 'specialtiesRender' , 'servicesRender','alljobs','jobs'));
    }
    public function create(Request $request)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=',$slug)->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? new $dataType->model_name()
            : false;

        foreach ($dataType->addRows as $key => $row) {
            $dataType->addRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }
        $allgovernrate=Governrate::where("disabled","=",0)->where('deleted_at' , "=" , Null)->paginate(10);
        $allServices=Service::where("disabled","=",0)->where('deleted_at' , "=" , Null)->paginate(10);
        $listSpecialties=Specialty::where("disabled","=",0)->where('deleted_at' , "=" , Null)->paginate(10);
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'add');

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $services = new Service();
        $listServices = $services->listServices();


        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        $alljobs=Jobtitle::where("disabled","=",0)->paginate(10);
        $jobs=[];
        $i=0;
        if($alljobs)
        {
            foreach ($alljobs as $job)
            {
                $jobs[$i]=$job;
                $i++;
            }

        }
        $specialtiesRender =  str_replace(array("\n", "\r"), '', $listSpecialties->render());
        $servicesRender =  str_replace(array("\n", "\r"), '', $allServices->render());
        $newJobTitle = Jobtitle::find($request->old('add_job'));
        $dataTypeContent['job_name']= $newJobTitle['name_en'] ;
        $newGovernrate = Governrate::find($request->old('add_governrate'));
        $dataTypeContent['governrate_name']= $newGovernrate['name_en'] ;
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable' ,'allgovernrate' , 'listServices' , 'listSpecialties' , 'allServices' , 'servicesRender' , 'specialtiesRender','alljobs','jobs'));
    }
    public function store(Request $request)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        // Validate fields with ajax
        $val = $this->validateBread($request->all(), $dataType->addRows);

        if ($val->fails()) {
            return response()->json(['errors' => $val->messages()]);
        }

        $valid=Validator::make($request->all(),[
            'name'=>'required|Unique:users|Filled|string',
            'fullname'=>'required|Filled|string',
            'email'=>'required|Unique:users|Filled|E-Mail|string',
            'name_en' => 'required', 'Filled'  , 'string' ,
            'password' => 'required', 'Filled' , 'string' ,
            'typemedical' => 'required' ,
            'add_governrate' => 'required',
            'add_job'=>'required_if:typemedical,private_clinic',
        ],["add_governrate.required" => "Governrate Is Required" , "add_job.required_if" => "Job Is Required"])->validate();
//        if($valid->fails()) {
//            return response()->json(['errors' => $valid->messages()]);
//        }
        if (!$request->has('_validate')) {
            $request['lang']= 'en';
            $request['verified']= 0;
             $request['disabled']= 0;
            $data = $this->insertUpdateData($request, $slug, $dataType->addRows, new $dataType->model_name());
            if(!empty($request->file('logo'))) {
                $imagePath = $request->file('logo')->store('');
                $image = Image::make(Storage::get($imagePath))->encode();
                Storage::put($imagePath,$image);
                User::where('id', $data->id)->update(['avatar' => "users/".$imagePath]);
            }

            User::where('id', $data->id)->update(['fullname_en' =>$request->name_en , 'token' =>Str::random(32) , 'role_id'=>2 , 'type'=>'medical_provider']);
            $user_id=User::where("id","=",$data->id)->get();
            $newmedical= new MedicalProvider();
            $newmedical->type=$request->typemedical;
            $newmedical->name_en=$request->name_en;
            $newmedical->user_id=$user_id[0]->id;
            $newmedical->brief=$request->brief;
            $newmedical->brief_en=$request->brief_en;
            $newmedical->address=$request->address;
            $newmedical->address_en=$request->address_en;
            $newmedical->governrate_id=$request->add_governrate;
            if($newmedical->save())
            {
                if($newmedical->type=='private_clinic'){
                    $doctor=new Doctor;
                    $doctor->name_en=$newmedical->name_en;
                    $doctor->user_id=$user_id[0]->id;
                    $doctor->jobtitle=$request->add_job;
                    $doctor->speciality_id=$request->specialtiy['1'];
                    if($doctor->save()) {
                        $doctor->medical_providers()->attach($newmedical->id);
                    }
                }
                if(isset($request->specialtiy))
                {
                    foreach ($request->specialtiy as $key=>$value) {
                        $medicalProviderHasSpecialties = new Specialty;
                        $medicalProviderHasSpecialties->addSpecialtyToProvider($request->specialtiy[$key] , $newmedical->id);
                        foreach ($request->service[$key] as $key2=>$value2)
                        {
                            $serviceSpecialty = new Service; ;
                            $serviceSpecialty->addServiceToSpecialty($request->service[$key][$key2] , $request->specialtiy[$key] ,$newmedical->id , $request->price[$key][$key2] );
                        }

                    }
                }
            }
            DB::table('user_roles')->insert(
                ['user_id' => $user_id[0]->id ,'role_id' => 11]
            );
            Mail::to($user_id)->send(new \App\Mail\NewMedicalProvider($request->email,$request->password , $request->fullname , $user_id[0]->token));
            event(new BreadDataAdded($dataType, $data));

            if ($request->ajax()) {
                return response()->json(['success' => true, 'data' => $data]);
            }

            return redirect()
                ->route("voyager.medical-providers.index")
                ->with([
                    'message'    => __('voyager::generic.successfully_added_new')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function Deletemedical(Request $request)
    {

        $ids = [];

        // Bulk delete, get IDs from POST
        $ids =  $request->row_id;
        foreach($ids as $id)
        {
            if(!empty($id)) {
                $user = User::find($id);
                if (!$user) {
                    return 'false';
                } else {
                    if ($user->medicalprovider->doctor()->count() > 0) {
                        return 'false';
                    }
                    $user->delete();
                    //delete relation between medicalprovider and specialtiy and service after soft delete medicalprovider
                    $medicalSpecialties = MedicalProviderHasSpecialties::where('medical_provider_id' , $user->medicalprovider->id )->get();
                    foreach ($medicalSpecialties as $medicalSpecialtie)
                    {
                        DB::table('medical_provider_specialty_has_services')->where('medical_provider_has_speciality_id',  $medicalSpecialtie->id)->delete();
                    }
                    DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $user->medicalprovider->id)->delete();
                }
            }
        }
        return 'true';
    }
    public function delete_single($id)
    {
        $user = User::find($id);
        $privaterReservations = MedicalProviderHasSpecialties::where('medical_provider_id' , $user->medicalprovider->id )->whereNotNull('departement_secretary_id')->count();
        if ($user) {
            if ($user->medicalprovider->doctor()->count() > 0) {
                throw new Exception(__('messages.this_medical_have_doctors') , '23000');
            }
            if ($privaterReservations > 0) {
                throw new Exception(__('messages.this_medical_have_private_reservations') , '23000');
            }
            $user->delete();
            //delete relation between medicalprovider and specialtiy and service after soft delete medicalprovider
            $medicalSpecialties = MedicalProviderHasSpecialties::where('medical_provider_id' , $user->medicalprovider->id )->get();
             foreach ($medicalSpecialties as $medicalSpecialtie)
             {
                 DB::table('medical_provider_specialty_has_services')->where('medical_provider_has_speciality_id',  $medicalSpecialtie->id)->delete();
             }
            DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $user->medicalprovider->id)->delete();

        }
        $user->save();
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "medical.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.medical-providers.index";
            $parameterString= "page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()
            ->route($routeName , [$parameterString]);

    }
    public function show(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $dataTypeContent = call_user_func([$model, 'findOrFail'], $id);
        } else {
            // If Model doest exist, get data from table name
            $dataTypeContent = DB::table($dataType->name)->where('id', $id)->first();
        }
        $medical= MedicalProvider::where("user_id","=",$id)->with('specialty')->get();
        //$medical=$medical->toArray();
        $governrate=Governrate::find($medical[0]['governrate_id']);
        $medicalProviderServices = [];
        $medicalProviderSpecialties = DB::table('medical_provider_has_specialties')->where('medical_provider_id', $medical[0]->id)->get(['speciality_id','id']);
         foreach ($medicalProviderSpecialties as $medicalProviderSpecialtie) {
             //$medicalServices = DB::table('medical_provider_specialty_has_services')->where('medical_provider_has_speciality_id', $medicalProviderSpecialtie->id)->get();
             $medicalServices = DB::table('medical_provider_specialty_has_services')
                 ->join('services', function ($join) {
                     $join->on('medical_provider_specialty_has_services.service_id', '=', 'services.id');
                 })
                 ->select('medical_provider_specialty_has_services.*', 'services.name_ar as ser_name', 'medical_provider_specialty_has_services.price')
                 ->where('medical_provider_specialty_has_services.medical_provider_has_speciality_id', $medicalProviderSpecialtie->id)
                 ->get();
             array_push($medicalProviderServices , $medicalServices);
         }

        // Replace relationships' keys for labels and create READ links if a slug is provided.
        $dataTypeContent = $this->resolveRelations($dataTypeContent, $dataType, true);

        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'read');

        // Check permission
        $this->authorize('read', $dataTypeContent);

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "medical.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.medical-providers.index";
            $parameterString= "page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        $view = 'voyager::bread.read';

        if (view()->exists("voyager::$slug.read")) {
            $view = "voyager::$slug.read";
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable','medical','governrate' , 'medicalProviderServices' , 'medicalProviderSpecialties' , 'routeName' , 'parameterString'));
    }

    function filter_search_services(Request $request)
    {
        if($request->get('type')==1) {
          $table = new \App\Service ;
          $name = "serv";
        }
        elseif ($request->get('type')==2) {
            $table = new \App\Specialty ;
            $name = "spec";
        }
        $serviceId = $request->get('serviceId');
        $serviceName = $request->get('serviceName');
        $query=$request->get('query')!==null? $request->get('query') : "" ;
        $list = $table::where('name_ar', 'LIKE', "%{$query}%")->orWhere('name_en', 'LIKE', "%{$query}%")->where('disabled','=',0)->paginate(10);
        return Voyager::view('vendor.voyager.medical-providers.paginate_service', compact('list' , 'serviceId' , 'serviceName' , 'name'))->render();
    }
    function filter_search_governrates(Request $request)
    {
        $query=$request->get('query')!==null? $request->get('query') : "" ;
        $allgovernrate = Governrate::where('name_ar', 'LIKE', "%{$query}%")->orWhere('name_en', 'LIKE', "%{$query}%")->where('disabled','=',0)->paginate(10);
        return Voyager::view('vendor.voyager.medical-providers.paginate_governrate', compact('allgovernrate' ))->render();
    }

    public function deleteService (Request $request)
    {

       $medicalSpecialtiy = $request->get('medical_specialties');
        $serviceId = $request->get('service_id');
        DB::table('medical_provider_specialty_has_services')->where('medical_provider_has_speciality_id',  $medicalSpecialtiy)->where('service_id' , $serviceId)->delete();
    }
    public function deleteSpecialtiy (Request $request)
    {
        $medicalSpecialtiy = $request->get('medical_specialties');
        DB::table('medical_provider_specialty_has_services')->where('medical_provider_has_speciality_id',  $medicalSpecialtiy)->delete();
        DB::table('medical_provider_has_specialties')->where('id',  $medicalSpecialtiy)->delete();
    }
    public function medicalSearch(Request $request)
    {

        $emailSearch = $request->email;
        $nameArSearch = $request->name_ar;
        $nameEnSearch = $request->name_en;
        $typeSearch = $request->type;
        $statusSearch = $request->status;
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = "medical-providers";
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $dataTypeContent=[];
            if($typeSearch!='') {
                $medicalproviders=MedicalProvider::where('type',$typeSearch)->whereHas('user',function($query) use ($emailSearch , $nameArSearch , $nameEnSearch,$statusSearch){
                if($emailSearch!='')
                    $query->where('email','like' , '%'.$emailSearch .'%');
                 if($nameArSearch!='')
                        $query->where('fullname','like' , '%'.$nameArSearch.'%');
                 if($nameEnSearch!='')
                        $query->where('fullname_en','like','%'.$nameEnSearch.'%');
                 if($statusSearch!='')
                        $query->where('verified',$statusSearch);
                })->orderBy("id","desc")->paginate(10);
            }
            else
            {
                $medicalproviders=MedicalProvider::whereHas('user',function($query) use ($emailSearch , $nameArSearch , $nameEnSearch,$statusSearch){
                if($emailSearch!='')
                    $query->where('email','like' , '%'.$emailSearch .'%');
                if($nameArSearch!='')
                    $query->where('fullname','like' , '%'.$nameArSearch.'%');
                if($nameEnSearch!='')
                    $query->where('fullname_en','like','%'.$nameEnSearch.'%');
                if($statusSearch!='')
                    $query->where('verified',$statusSearch);
                })->orderBy("id","desc")->paginate(10);
            }

            $medicalproviders->appends(['email' => $emailSearch ,'name_ar' =>$nameArSearch ,'name_en'=>$nameEnSearch,'type'=>$typeSearch ,'status'=>$statusSearch]);
            $i=0;
            $dataTypeContent=[];
            if($medicalproviders)
            {
                foreach ($medicalproviders as $key=>$medicalprovider)
                {
                    $user=User::find($medicalprovider->user_id);
                    if($user)
                    {
                        if($medicalprovider->governrate_id != "")
                        {
                            $governratename=Governrate::find($medicalprovider->governrate_id);
                            $user["governrate"]=$governratename->name_en;
                        }
                        $governratename=Governrate::find($medicalprovider->governrate_id);
                        if($governratename)
                        {
                            $user["governrate"]=$governratename->name_en;
                            $user["brief"]=$medicalprovider->brief;
                            $user["address"]=$medicalprovider->address;
                            $user["typemedical"]=$medicalprovider->type;
                            $dataTypeContent[$i]=$user;
                            $i++;
                        }
                    }
            }

            }
            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;

            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

            $view = "vendor.voyager.medical-providers.browse";

            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($dataTypeContent) && !empty($medicalproviders->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $medicalproviders->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }
            return Voyager::view($view, compact(
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'medicalproviders',
                'emailSearch',
                'nameArSearch',
                'nameEnSearch',
                'typeSearch',
                'statusSearch',
                'actions'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }

    }

}
