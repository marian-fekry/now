<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Specialty;
class SpecialtiesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }
    public function specialities_func(){
        if(Auth::user()->hasPermission('browse_specialties')==1) {
            $obj=new Specialty();
            $allspeciality =$obj->specialities();
            return OutPut::Response($allspeciality,'',200);
        } else {
            return OutPut::Response('',__('messages.auth_error_specialities'),401);
        }
    }
    public function addspeciality(Request $request){
        $user=Auth::user();
        app()->setLocale($user->token()->user_lang);
        $valid=Validator::make($request->all(),[
            'speciality'=>'required|Filled|integer',
        ]);
        if($valid->fails()){
            return OutPut::Response('',$valid->Errors(),403);
        }
        if(Auth::user()->hasPermission('add_specialties')==1) {
            $obj=new Specialty();
            $checkadding =$obj->add_speciality($request->input('speciality'));
            if( $checkadding == false )
            {
                return "please check your speciality";
            }
            return OutPut::Response('','speciality added correctly',200);
        } else {
            return OutPut::Response('','You are not Authorized ',401);
        }
    }
}
