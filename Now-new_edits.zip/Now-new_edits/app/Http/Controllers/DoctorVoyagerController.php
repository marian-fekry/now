<?php

namespace App\Http\Controllers;
use App\Doctor;
use App\Jobtitle;
use App\MedicalProvider;
use App\Specialty;
use Exception;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use phpDocumentor\Reflection\Types\Array_;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
use TCG\Voyager\Http\Controllers\VoyagerBaseController as BaseVoyagerController;
use Redirect;
use Validator;
use Carbon\Carbon ;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Storage;
use Image;
class DoctorVoyagerController extends BaseVoyagerController
{
    public function index(Request $request)
    {

        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();
        // Check permission

        $this->authorize('browse', app($dataType->model_name));
        $getter = $dataType->server_side ? 'paginate' : 'get';
        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');
            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');
            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $doctors= Doctor::select('user.*', 'doctors.id', 'doctors.speciality_id', 'doctors.jobtitle' , 'doctors.name_en')->leftJoin('users as user', 'user.id', '=', 'doctors.user_id')->where('user.deleted_at' , '=' , Null)->orderBy('created_at', 'DESC')->paginate(10);
            $i=0;
            if(count($doctors)) {
                foreach ($doctors as $doctor) {
                    $dataTypeContent[$i] = $doctor;
                    $medicals = DB::table('doctor_has_medical_provider')->select('medical_provider_id')->where("doctor_id", "=", $dataTypeContent[$i]->id)->get();
                    foreach ($medicals as $medical) {
                        $specific = DB::table('medical_providers')->select('name_en')->where("id", "=", $medical->medical_provider_id)->get();
                        $dataTypeContent[$i]->medical = $specific[0]->name_en;
                    }
                    $i++;
                }
                $i++;
            }
            else {
                $dataTypeContent = [] ;
            }

            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }

            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;
            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;
            $view = "vendor.voyager.doctors.browse";
            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }


            return Voyager::view($view, compact(
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'doctors'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
    public function update(Request $request, $id)
    {
        $doctor = New Doctor();
        $medical_provider_id = explode(",", $request->medical_provider_id['0']);
         if($medical_provider_id['0']=='')
         {
             $medical_provider_id = [];
         }
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'doctors')->first();
        // Compatibility with Model binding.
        $id = $id instanceof Model ? $id->{$id->getKeyName()} : $id;
        $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);
        // Check permission
        $this->authorize('edit', $data);
        // Validate fields with ajax
        //$val = $this->validateBread($request->all(), $dataType->editRows, $dataType->name, $id);
        //if ($val->fails()) {
          //  return response()->json(['errors' => $val->messages()]);
        //}
        $doctor=$doctor->find($id);
        $valid=Validator::make($request->all(),[
            'name' => [
                'required', 'Filled' , 'string' ,
                Rule::unique('users')->ignore($doctor->user_id),
            ],
            'email' => [
                'required', 'Filled' , 'E-Mail' , 'string' ,
                Rule::unique('users')->ignore( $doctor->user_id),
            ],
            /*'password' => 'required', 'Filled' , 'string' ,*/
            'name_en' => 'required', 'Filled'  , 'string' ,
            'edit_job' => 'required' ,
            'edit_speciality' => 'required' ,
        ])->validate();

        if (!$request->ajax()) {
            //$this->insertUpdateData($request, $slug, $dataType->editRows, $data);
            if(!empty($request->file('logo'))) {

                $imagePath = $request->file('logo')->store('');
                $image = Image::make(Storage::get($imagePath))->encode();
                Storage::put($imagePath, $image);
            }
            else
            {
                if($doctor->user->avatar!="users/default.png") {
                    $imagePath=explode("/",$doctor->user->avatar);
                    $imagePath=$imagePath['1'];
                }
                else {
                    $imagePath="default.png";
                }
            }
            $data = $doctor->editDoctorAdmin($id,$request->name,$request->email,$request->password,$request->fullname , $request->edit_job ,$request->name_en,$request->edit_speciality , $medical_provider_id,$imagePath);
             $countParametersUrl = count(explode('&', $request->redirects_to));
            if($countParametersUrl>1) {
                $parametersString = explode('?', $request->redirects_to);
                preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
                $parameterString = "";
                for ($i = 0; $i < $countParametersUrl; $i++) {
                    $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
                }
                $routeName = "doctor.search";
            }
            else{
                $previousUrl = explode('page=' , $request->redirects_to);
                $routeName = "voyager.doctors.index";
                $parameterString= "page=";
                $parameterString.= $previousUrl['1'] ?? 1;
            }
            event(new BreadDataUpdated($dataType, $data));
            return redirect()
                ->route($routeName ,[$parameterString])
                ->with([
                    'message'    => __('voyager::generic.successfully_updated')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function edit(Request $request, $id)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'doctors')->first();
        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? app($dataType->model_name)->findOrFail($id)
            : DB::table($dataType->name)->where('id', $id)->first(); // If Model doest exist, get data from table name
        foreach ($dataType->editRows as $key => $row) {
            $dataType->editRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }

        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'edit');
        // Check permission
        $this->authorize('edit', $dataTypeContent);
        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $view = 'voyager::bread.edit-add';
        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        $alljobs=Jobtitle::where("disabled","=",0)->paginate(10);
        $jobs=[];
        $i=0;
        if($alljobs)
        {
            foreach ($alljobs as $job)
            {
                $jobs[$i]=$job;
                $i++;
            }

        }
        $allspeciality=Specialty::where("disabled","=",0)->paginate(10);
        $specialities=[];
        $i=0;
        if($allspeciality)
        {
            foreach ($allspeciality as $speciality)
            {
                $specialities[$i]=$speciality;
                $i++;
            }

        }
        $allmedicalProviders=MedicalProvider::whereHas('user',function($query){
            return $query->where('deleted_at', '=', Null)->where('disabled','=',0);
        })->paginate(10);
        $medicalProviders=[];
        $i=0;
        if($allmedicalProviders)
        {
            foreach ($allmedicalProviders as $medicalProvider) {
                $user=User::where('id','=',$medicalProvider->user_id)->get();
                if($user)
                {
                    $medicalProviders[$i]=$medicalProvider;
                    $medicalProviders[$i]['name']=$user[0]->name;
                    $i++;
                }
            }
        }
        $userInfo = DB::table('users')->where('id', $dataTypeContent->user_id)->first();
        $medical_Providers = new MedicalProvider();
        $listMedicalProviders = $medical_Providers->listMedicalProviders();
        $doctorMedicalProviders = "";
        $doctorMedicalProvidersIds = [];
        foreach($dataTypeContent->medical_providers as $medical) {
            $doctorMedicalProviders.=$medical->name_en . " , " ;
            array_push($doctorMedicalProvidersIds ,$medical->id);
        }
        $doctorMedicalProvidersIds=implode(",",$doctorMedicalProvidersIds);
        $newJobTitle = Jobtitle::find($request->old('edit_job'));
        $dataTypeContent['job_name']= $newJobTitle['name_en'] ;
        $newSpecialty = Specialty::find($request->old('edit_speciality'));
        $dataTypeContent['spec_name']= $newSpecialty['name_en'] ;
        $dataTypeContent['newDoctorMedicalProviders']= '';
        $newdoctorMedicalProvidersIds=explode(',' , $request->old('medical_provider_id')['0']);
        $newDoctorMedicalProviders= [];
        if(count($newdoctorMedicalProvidersIds)>1) {
            foreach ($newdoctorMedicalProvidersIds as $newdoctorMedicalProvidersId) {
                $medicalName = MedicalProvider::find($newdoctorMedicalProvidersId);
                array_push($newDoctorMedicalProviders, $medicalName->user->fullname_en);
            }
            $dataTypeContent['medicalNamesHidden']=implode(",",$newDoctorMedicalProviders);
        }
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable' , 'userInfo' , 'listMedicalProviders' ,'medicalProviders','allmedicalProviders','allspeciality','specialities','alljobs','jobs' ,'doctorMedicalProviders' ,'doctorMedicalProvidersIds'));
    }
    public function create(Request $request)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'doctors')->first();
        // Check permission
        $this->authorize('add', app($dataType->model_name));
        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? new $dataType->model_name()
            : false;
        foreach ($dataType->addRows as $key => $row) {
            $dataType->addRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }
        $dataTypeContent->avatar="users/default.png";
        $alljobs = Jobtitle::where('disabled','=',0)->where('deleted_at' , '=' , Null)->paginate(10);
        $jobs=[];
        $i=0;
        if($alljobs)
        {
            foreach ($alljobs as $job)
            {
                $jobs[$i]=$job;
                $i++;
            }
        }
        $allspeciality = Specialty::where('disabled','=',0)->where('deleted_at' , '=' , Null)->paginate(10);
        $specialities=[];
        $i=0;
        if($allspeciality)
        {
            foreach ($allspeciality as $speciality)
            {
                $specialities[$i]=$speciality;
                $i++;
            }
        }
        $allmedicalProviders=MedicalProvider::whereHas('user',function($query){
            return $query->where('deleted_at', '=', Null);
        })->paginate(10);
        $medicalProviders=[];
        $i=0;
        if($allmedicalProviders)
        {
            foreach ($allmedicalProviders as $medicalProvider) {
                $user=User::where('id','=',$medicalProvider->user_id)->where('disabled','=',0)->get();
                if($user)
                {
                    $medicalProviders[$i]=$medicalProvider;
                    $medicalProviders[$i]['name']=$user[0]->name;
                    $i++;
                }
            }
        }
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'add');
        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $medical_Providers = new MedicalProvider();
        $listMedicalProviders = $medical_Providers->listMedicalProviders();
        $view = 'voyager::bread.edit-add';
        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        $newJobTitle = Jobtitle::find($request->old('add_job'));
        $dataTypeContent['job_name']= $newJobTitle['name_en'] ;
        $newSpecialty = Specialty::find($request->old('edit_speciality'));
        $dataTypeContent['spec_name']= $newSpecialty['name_en'] ;
        $dataTypeContent['newDoctorMedicalProviders']= '';
        $newdoctorMedicalProvidersIds=explode(',' , $request->old('medical_provider_id')['0']);
        $newDoctorMedicalProviders= [];
        if(count($newdoctorMedicalProvidersIds)>1) {
            foreach ($newdoctorMedicalProvidersIds as $newdoctorMedicalProvidersId) {
                $medicalName = MedicalProvider::find($newdoctorMedicalProvidersId);
                array_push($newDoctorMedicalProviders, $medicalName->user->fullname_en);
            }
            $dataTypeContent['medicalNamesHidden']=implode(",",$newDoctorMedicalProviders);
        }
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable' , 'listMedicalProviders','medicalProviders','allmedicalProviders','allspeciality','specialities','alljobs','jobs'));
    }
    public function store(Request $request)
    {
        $doctor = New Doctor();
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'doctors')->first();
        // Check permission
        $this->authorize('add', app($dataType->model_name));
        // Validate fields with ajax
//        $val = $this->validateBread($request->all(), $dataType->addRows);
//        if ($val->fails()) {
//            return response()->json(['errors' => $val->messages()]);
//        }
        $valid = Validator::make($request->all(),[
            'name'=>'required|Unique:users|Filled|string',
            'password' => 'required', 'Filled' , 'string' ,
            'name_en' => 'required', 'Filled'  , 'string' ,
            'email'=>'required|Unique:users|Filled|E-Mail|string',
            'add_job' => 'required' ,
            'add_speciality' => 'required' ,
        ],['add_job.required'=>"Job Title Is Required",'add_speciality.required'=>"Speciality Is Required"])->validate();
//        if($valid->fails()) {
//            return response()->json(['errors' => $valid->messages()]);
//        }
        if (!$request->has('_validate')) {
            //$data = $this->insertUpdateData($request, $slug, $dataType->addRows, new $dataType->model_name());
            if(!empty($request->file('logo'))) {
                $imagePath = $request->file('logo')->store('');
                $image = Image::make(Storage::get($imagePath))->encode();
                Storage::put($imagePath, $image);
            }
            else
            {
                $imagePath ="default.png";
            }
            $medical_provider_id = explode(",", $request->medical_provider_id['0']);
            if($medical_provider_id['0']=='')
            {
                $medical_provider_id = [];
            }
            $data = $doctor->addDoctorAdmin($request->name,$request->email  , $request->password  ,$request->fullname , $request->add_job , $request->name_en, $request->add_speciality,$imagePath , $medical_provider_id);
            event(new BreadDataAdded($dataType, $data));
            if ($request->ajax()) {
                return response()->json(['success' => true, 'data' => $data]);
            }
            return redirect()
                ->route("voyager.doctors.index")
                ->with([
                    'message'    => __('voyager::generic.successfully_added_new')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function deleteDoctor(Request $request)
    {
        $ids = [];
        // Bulk delete, get IDs from POST
        $ids =  $request->row_id;
        if(!empty($ids)){
            foreach($ids as $id)
            {
                $doctor = Doctor::find($id);
                $user = User::find($doctor->user_id);
                $user->delete();
                $doctor->jobtitle=0;
                $doctor->save();
                //$user->save();
            }
        }
        return 'true';
    }
    public function delete_single($id)
    {
        $doctor = Doctor::find($id);
        $user = User::find($doctor->user_id);
        if ($user->doctor->secretary()->count() > 0) {
            throw new Exception(__('messages.this_doctor_have_secretary') , '23000');
        }
        $user->delete();
        $doctor->jobtitle=0;
        $doctor->save();
        //$user->save();
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "doctor.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.doctors.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()
            ->route($routeName , [$parameterString]);
    }
    public function show(Request $request, $id)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'doctors')->first();
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $dataTypeContent = call_user_func([$model, 'findOrFail'], $id);

        } else {
            // If Model doest exist, get data from table name
            $dataTypeContent = DB::table($dataType->name)->Join('doctor', 'users.id', '=', 'doctors.user_id')->where('users.id', $id)->first();
        }

        // Replace relationships' keys for labels and create READ links if a slug is provided.
        $dataTypeContent = $this->resolveRelations($dataTypeContent, $dataType, true);
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'read');
        // Check permission
        $this->authorize('read', $dataTypeContent);
        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $userInfo = DB::table('users')->where('id', $dataTypeContent->user_id)->first();
        $doctorMedicalProviders = DB::table('doctor_has_medical_provider')->where('doctor_id', $id)->get(['medical_provider_id']);
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "doctor.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.doctors.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        $view = 'voyager::bread.read';
        if (view()->exists("voyager::$slug.read")) {
            $view = "voyager::$slug.read";
        }
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable' , 'userInfo' , 'doctorMedicalProviders' , 'routeName' , 'parameterString'));
    }

    public function doctorDeactivate($id)
    {
        $doctor = Doctor::find($id);
        $user = User::find($doctor->user_id);
        $user->disabled = 1;
        $user->save();
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "doctor.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.doctors.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName , [$parameterString]);
    }

    public function doctorActivate($id)
    {
        $doctor = Doctor::find($id);
        $user = User::find($doctor->user_id);
        $user->disabled = 0;
        $user->save();
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "doctor.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.doctors.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName , [$parameterString]);
    }
    function filter_search(Request $request)
    {
        if($request->get('type') == 1)
        {
            $query=$request->get('query')!==null? $request->get('query') : "" ;
            $alljobs = Jobtitle::where('name_en', 'LIKE', "%{$query}%")->orWhere('name_ar', 'LIKE', "%{$query}%")->where('disabled','=',0)->paginate(10);
            $jobs=[];
            $i=0;
            if($alljobs)
            {
                foreach ($alljobs as $job)
                {
                    $jobs[$i]=$job;
                    $i++;
                }
            }
            return Voyager::view('vendor.voyager.doctors.paginate_jop', compact('alljobs','jobs'))->render();
        }
        else if($request->get('type') == 2)
        {
            $query=$request->get('query')!==null? $request->get('query') : "" ;
            $allspeciality = Specialty::where('name_en', 'LIKE', "%{$query}%")->orWhere('name_ar', 'LIKE', "%{$query}%")->where('disabled','=',0)->paginate(10);
            $specialities=[];
            $i=0;
            if($allspeciality)
            {
                foreach ($allspeciality as $speciality)
                {
                    $specialities[$i]=$speciality;
                    $i++;
                }
            }
            return Voyager::view('vendor.voyager.doctors.paginate_speciality', compact('allspeciality','specialities'))->render();
        }
        else if($request->get('type') == 3)
        {
            $medicalIds=$request->get('medicalIds');
            $query=$request->get('query')!==null? $request->get('query') : "" ;
            $allmedicalProviders = User::where('name', 'LIKE', "%{$query}%")->where('disabled','=',0)->has('medicalprovider')->paginate(10);
            $medicalProviders=[];
            $i=0;
            if($allmedicalProviders)
            {
                foreach ($allmedicalProviders as $medical)
                {
                    $user=MedicalProvider::where('user_id','=',$medical->id)->get();
                    if($user)
                    {
                        $medicalProviders[$i]=$user[0];
                        $medicalProviders[$i]['name']=$medical->name;
                        $i++;
                    }
                }
            }
            return Voyager::view('vendor.voyager.doctors.paginate_medical', compact('allmedicalProviders','medicalProviders','medicalIds'))->render();
        }
    }
    public function doctorSearch(Request $request)
    {

        $emailSearch = $request->email;
        $nameArSearch = $request->name_ar;
        $nameEnSearch = $request->name_en;
        $medicalNameSearch = $request->medical;
        $specialitySearch = $request->speciality;
        $jobtitleSearch = $request->jobtitle;
        $statusSearch = $request->status;

        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = "doctors";
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();
        // Check permission

        $this->authorize('browse', app($dataType->model_name));
        $getter = $dataType->server_side ? 'paginate' : 'get';
        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');
            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');
            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $doctors= Doctor::select('user.*', 'doctors.id', 'doctors.speciality_id', 'doctors.jobtitle' , 'doctors.name_en')->leftJoin('users as user', 'user.id', '=', 'doctors.user_id')->where('user.deleted_at' , '=' , Null)->whereHas('user',function($query) use ($emailSearch , $nameArSearch , $nameEnSearch,$statusSearch){
                if($emailSearch!='')
                    $query->where('email','like' , '%'.$emailSearch .'%');
                if($nameArSearch!='')
                    $query->where('fullname','like' , '%'.$nameArSearch.'%');
                if($nameEnSearch!='')
                    $query->where('fullname_en','like','%'.$nameEnSearch.'%');
                if($statusSearch!='')
                    $query->where('verified',$statusSearch);
            })->whereHas('medical_providers',function($query) use ($medicalNameSearch){
                if($medicalNameSearch!='')
                {
                    $query->wherehas('user' ,function($query) use ( $medicalNameSearch )
                    {
                        $query->where('fullname_en', 'like' , '%'.$medicalNameSearch.'%');
                        $query->orWhere('fullname', 'like' , '%'.$medicalNameSearch.'%');
                    });
                }
            })->whereHas('speciality',function($query) use ($specialitySearch){
                if($specialitySearch!='')
                 $query->where('name_en', 'like' , '%'.$specialitySearch.'%')->orWhere('name_ar', 'like' , '%'.$specialitySearch.'%');

            })->whereHas('jobTitle',function($query) use ($jobtitleSearch){
                $query->where('name_en', 'like' , '%'.$jobtitleSearch.'%')->orWhere('name_ar', 'like' , '%'.$jobtitleSearch.'%');
            })
                ->orderBy('created_at', 'DESC')->paginate(10);
            $doctors->appends(['email' => $emailSearch ,'name_ar' =>$nameArSearch ,'name_en'=>$nameEnSearch,'medical'=>$medicalNameSearch,'speciality'=>$specialitySearch,'jobtitle'=>$jobtitleSearch,'status'=>$statusSearch]);
            $i=0;
            if(count($doctors)) {
                foreach ($doctors as $doctor) {
                    $dataTypeContent[$i] = $doctor;
                    $medicals = DB::table('doctor_has_medical_provider')->select('medical_provider_id')->where("doctor_id", "=", $dataTypeContent[$i]->id)->get();
                    foreach ($medicals as $medical) {
                        $specific = DB::table('medical_providers')->select('name_en')->where("id", "=", $medical->medical_provider_id)->get();
                        $dataTypeContent[$i]->medical = $specific[0]->name_en;
                    }
                    $i++;
                }
                $i++;
            }
            else {
                $dataTypeContent = [] ;
            }

            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }

            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;
            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;
            $view = "vendor.voyager.doctors.browse";
            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }


            return Voyager::view($view, compact(
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'doctors',
                'emailSearch',
                'nameArSearch',
                'nameEnSearch',
                'medicalNameSearch',
                'specialitySearch',
                'jobtitleSearch',
                'statusSearch'

            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }

}
