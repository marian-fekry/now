<?php

namespace App\Http\Controllers;

use App\Mail\EmailVerification as EmailVerification;
use App\Patient;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;
use phpDocumentor\Reflection\Types\Array_;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
use TCG\Voyager\Http\Controllers\VoyagerBaseController as BaseVoyagerController;
use Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Storage;
use Image;
use TCG\Voyager\Models\Role;


class userVoyagerController extends BaseVoyagerController
{
    public function index(Request $request)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $alladmin=User::where("role_id",'!=' ,2)->orderBy("id","desc")->paginate(10);
            $dataTypeContent=[];
            $i=0;
            if($alladmin)
            {
                foreach ($alladmin as $admin) {
                    $dataTypeContent[$i]=$admin;
                    $dataTypeContent[$i]['password']=$admin->password;
                    $i++;
                }
            }

            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;

            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

            $view = "vendor.voyager.userstable.browse";

            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($dataTypeContent['0']->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $dataTypeContent['0']->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }
            return Voyager::view($view, compact(
                'actions',
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'alladmin'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
    public function create(Request $request)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? new $dataType->model_name()
            : false;

        foreach ($dataType->addRows as $key => $row) {
            $dataType->addRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }
        $allroles=Role::whereNotIn('id' ,  ['2', '4' , '5' , '6' , '7' , '8' , '9' , '10' , '11'])->paginate(10);
        $roles=[];
        $i=0;
        if($allroles)
        {
            foreach ($allroles as $role ) {
                $roles[$i]=$role;
                $i++;
            }
        }
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'add');

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        if(!is_null($request->old('add_role'))) {
             $request->old('add_role') ;
            $newRole = Role::find($request->old('add_role'));
            $dataTypeContent['role_name'] = $newRole->name;
        }
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable','allroles','roles'));
    }
    public function Deleteadmin(Request $request)
    {

        $ids = [];
        // Bulk delete, get IDs from POST
        $ids =  $request->row_id;
        foreach($ids as $id)
        {
            if(!empty($id)) {
                $user = User::find($id);
                if (!$user) {
                    return 'false';
                } else {
                    $user->delete();
                }
            }
        }
        return 'true';
    }
    public function delete_single($id)
    {
        $user = User::find($id);
        if ($user){
            $user->delete();
        }
        return redirect()->route("voyager.userstable.index");
    }
    public function store(Request $request)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        // Validate fields with ajax
        //$val = $this->validateBread($request->all(), $dataType->addRows);

        /*if ($val->fails()) {
            return response()->json(['errors' => $val->messages()]);
        }*/
        $valid=Validator::make($request->all(),[
            'name' => [
                'required', 'Filled','regex:/^[\pL\s\-]+$/u' ,'string' ,
                Rule::unique('users')->ignore( $request->user_id),
            ],
            'email' => [
                'required', 'Filled','E-Mail', 'string' ,
                Rule::unique('users')->ignore( $request->user_id),
            ],
            'password' => [
                'required','Filled',
            ],
            'add_role' => [
                'required','Filled',
            ],
        ],["add_role.required"=>"Is Required","add_role.Filled"=>"Is Required"])->validate();
//        if($valid->fails()) {
//            return response()->json(['errors' => $valid->messages()]);
//        }

        if (!$request->has('_validate')) {
            $file=$request->avatar;
            if(!empty($file))
            {
                $imagePath = $file->store('');
                $image = Image::make(Storage::get($imagePath))->resize(200,200)->encode();
                Storage::put($imagePath,$image);
//                $data = $this->insertUpdateData($request, $slug, $dataType->addRows, new $dataType->model_name());
                $data =new User();
                $data->name=$request->name;
                $data->email=$request->email;
                $data->password=bcrypt($request->password);
                $data->role_id=$request->add_role;
                if($data->save())
                {
                    $row=User::find($data->id);
                    $row->avatar= "users/".$imagePath;
                    $row->save();
                }
            }
            else
            {
                //$data = $this->insertUpdateData($request, $slug, $dataType->addRows, new $dataType->model_name());
                $data =new User();
                $data->name=$request->name;
                $data->email=$request->email;
                $data->password=bcrypt($request->password);
                $data->role_id=$request->add_role;
                if($data->save())
                {
                    $row=User::find($data->id);
                    $row->avatar= "users/default.png";
                    $row->save();
                }
            }
            event(new BreadDataAdded($dataType, $data));

            if ($request->ajax()) {
                return response()->json(['success' => true, 'data' => $data]);
            }

            return redirect()
                ->route("voyager.{$dataType->slug}.index")
                ->with([
                    'message'    => __('voyager::generic.successfully_added_new')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function show(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $dataTypeContent = call_user_func([$model, 'findOrFail'], $id);
        } else {
            // If Model doest exist, get data from table name
            $dataTypeContent = DB::table($dataType->name)->where('id', $id)->first();
        }

        // Replace relationships' keys for labels and create READ links if a slug is provided.
        $dataTypeContent = $this->resolveRelations($dataTypeContent, $dataType, true);

        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'read');

        // Check permission
        $this->authorize('read', $dataTypeContent);

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.read';

        if (view()->exists("voyager::$slug.read")) {
            $view = "voyager::$slug.read";
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable'));
    }
    public function update(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Compatibility with Model binding.
        $id = $id instanceof Model ? $id->{$id->getKeyName()} : $id;

        $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

        // Check permission
        $this->authorize('edit', $data);

        // Validate fields with ajax
        //$val = $this->validateBread($request->all(), $dataType->editRows, $dataType->name, $id);

        /*if ($val->fails()) {
            return response()->json(['errors' => $val->messages()]);
        }*/
        $valid=Validator::make($request->all(),[
            'name' => [
                'required', 'Filled','regex:/^[\pL\s\-]+$/u' ,'string' ,
                Rule::unique('users')->ignore($id),
            ],
            'email' => [
                'required', 'Filled','E-Mail', 'string' ,
                Rule::unique('users')->ignore($id),
            ],
        ])->validate();


        if (!$request->ajax()) {
            $file=$request->avatar;
            if(!empty($file))
            {
                $imagePath = $file->store('');
                $image = Image::make(Storage::get($imagePath))->resize(200,200)->encode();
                Storage::put($imagePath,$image);
                $row=User::find($id);
                $row->avatar= "users/".$imagePath;
                $row->name=$request->name;
                $row->email=$request->email;
                $row->role_id=$request->edit_role;
                if($request->password != "")
                {
                    $row->password=bcrypt($request->password);
                }
                $row->save();
            }
            else
            {
                $row=User::find($id);
                $row->name=$request->name;
                $row->email=$request->email;
                $row->role_id=$request->edit_role;
                if($request->password != "")
                {
                    $row->password=bcrypt($request->password);
                }
                $row->save();
            }

            event(new BreadDataUpdated($dataType, $data));

            return redirect()
                ->route("voyager.{$dataType->slug}.index")
                ->with([
                    'message'    => __('voyager::generic.successfully_updated')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function edit(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? app($dataType->model_name)->findOrFail($id)
            : DB::table($dataType->name)->where('id', $id)->first(); // If Model doest exist, get data from table name
        foreach ($dataType->editRows as $key => $row) {
            $dataType->editRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }

        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'edit');

        // Check permission
        $this->authorize('edit', $dataTypeContent);
        $allroles=Role::whereNotIn('id' ,  [ '4' , '5' , '6' , '7' , '8' , '9' , '10' , '11'])->paginate(10);
        $roles=[];
        $i=0;
        if($allroles)
        {
            foreach ($allroles as $role ) {
                $roles[$i]=$role;
                $i++;
            }
        }
        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        if(!is_null($request->old('edit_role'))) {
            $request->old('edit_role') ;
            $newRole = Role::find($request->old('edit_role'));
            $dataTypeContent['role_name'] = $newRole->name;
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable','allroles','roles'));
    }
    public function userProfile(Request $request)
    {
        $slug = "userstable";

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();
        $id = Auth::user()->id;

        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? app($dataType->model_name)->findOrFail($id)
            : DB::table($dataType->name)->where('id', $id)->first(); // If Model doest exist, get data from table name
        foreach ($dataType->editRows as $key => $row) {
            $dataType->editRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }

        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'edit');

        // Check permission
        $this->authorize('edit', $dataTypeContent);
        $allroles=Role::all();
        $allroles=$allroles->toArray();
        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable','allroles'));
    }
    function filter_search(Request $request)
    {
        $query=$request->get('query')!==null? $request->get('query') : "" ;
        $allroles = Role::where('name', 'LIKE', "%{$query}%")->paginate(10);
        $roles=[];
        $i=0;
        if($allroles)
        {
            foreach ($allroles as $role)
            {
                $roles[$i]=$role;
                $i++;
            }
        }
        return Voyager::view('vendor.voyager.userstable.paginate_role', compact('roles','allroles'))->render();

    }
    function resendVerifiedEmail(Request $request)
    {
        $valid=Validator::make($request->all(),[
            'email'=>'required|Filled|email|string',
        ]);
        if($valid->fails()){
            return OutPut::Response('',$valid->Errors(),403);
        }

        $user = new User ();
        $userExists = $user->getUserByEmail($request->email);
        $userVerified =  $user->checkUserverification($userExists->token);
        if(!$userExists) {
            return redirect()->back()->with('message', 'Worng Email');
        }
        if(($userVerified == 1)) {
            return redirect()->back()->with('message', 'This account already verified');
        }
        else {
            if($userExists->isSecretary() || $userExists->isPrivateReservation() ||  $userExists->isDoctor()) {
                $password = bin2hex(openssl_random_pseudo_bytes(4));
                $userExists->password = bcrypt($password);
                $userExists->save();
            }
            if($userExists->isSecretary()){
                Mail::to($userExists)->send(new \App\Mail\NewSecretary($userExists->email,$password,$userExists->fullname ,$userExists->token));
                return redirect()->back()->with('message', 'Your Verification Mail has been sent');
            }
            if($userExists->isPrivateReservation()){
                Mail::to($userExists)->send(new \App\Mail\NewDepartementSecretary($userExists->email,$password,'' ,$userExists->token));
                return redirect()->back()->with('message', 'Your Verification Mail has been sent');
            }
            if($userExists->isDoctor()){
              Mail::to($userExists)->send(new \App\Mail\NewDoctor($userExists->email,$password,'' ,$userExists->token));
                return redirect()->back()->with('message', 'Your Verification Mail has been sent');
            }
            if (Mail::failures()) {
                return redirect()->back()->with('message', __('messages.mail_error'));
            }
            \Illuminate\Support\Facades\Mail::to($userExists)->send(new EmailVerification($userExists->token ));
            return redirect()->back()->with('message', 'Your Verification Mail has been sent');
        }
    }

    public function adminSearch(Request $request)
    {
        $emailSearch = $request->email;
        $nameSearch = $request->name;
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $alladmin=User::where("role_id",'!=' ,2)->where('email','like','%'.$emailSearch.'%')->where('name','like','%'.$nameSearch.'%')->orderBy("id","desc")->paginate(10);
            $alladmin->appends(['email' => $emailSearch ,'name' =>$nameSearch]);
            $dataTypeContent=[];
            $i=0;
            if($alladmin)
            {
                foreach ($alladmin as $admin) {
                    $dataTypeContent[$i]=$admin;
                    $dataTypeContent[$i]['password']=$admin->password;
                    $i++;
                }
            }

            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;

            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

            $view = "vendor.voyager.userstable.browse";

            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($dataTypeContent) && !empty($dataTypeContent['0']->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $dataTypeContent['0']->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }
            return Voyager::view($view, compact(
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'alladmin',
                'emailSearch',
                'nameSearch',
                'actions'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
}
