<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User ;
use Carbon\Carbon ;
use Session;
class VerifiedEmailController extends Controller
{
    use OutPut;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function verifyEmail($token )
    {
        if(!isset($token)  || $token=='' )
        {
            //return OutPut::Response('',__('messages.please open link from your eamil'),403);
            Session::flash('error', __('messages.verify_account'));
            return view('verifyemail');
        }
      $user = new User();
        if($user->checkUserverification($token))
        {
            //return OutPut::Response('', __('messages.You are already Verified'), 403);
            Session::flash('error', __('messages.already_verified'));
            return view('verifyemail');
        }
       $tokenCreatedAt = $user->chekUserToken($token);
       if($tokenCreatedAt) {
           if ($tokenCreatedAt->diffInHours(Carbon::now(), false) > 24) {
               $user->createNewToken($token);
               //return OutPut::Response('', __('messages.your token expried'), 403);
               Session::flash('error', __('messages.token_expried'));
               return view('verifyemail');
           }
           if ($user->verifyUser($token)) {
               //return OutPut::Response('', __('messages.your account activted'), 200);
               Session::flash('success', __('messages.account_activted'));
               return view('verifyemail');
           }
       }
        //return OutPut::Response('', __('messages.your token expried'), 403);
        Session::flash('error', __('messages.token_expried'));
        return view('verifyemail');

    }
}
