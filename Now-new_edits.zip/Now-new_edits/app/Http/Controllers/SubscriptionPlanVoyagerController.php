<?php
namespace App\Http\Controllers;


use App\SubscriptionOrder;
use Illuminate\Http\Request;
use App\Request as requestmodel;
use App\SubscriptionCart;
use App\SubscriptionPackage;
use App\SubscriptionPlan;
use App\Governrate;
use App\MedicalProvider;
use App\Service;
use App\Specialty;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use phpDocumentor\Reflection\Types\Array_;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
use TCG\Voyager\Http\Controllers\VoyagerBaseController as BaseVoyagerController;
use Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Storage;
use Image;


class SubscriptionPlanVoyagerController extends BaseVoyagerController
{

    public function index(Request $request){
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $dataTypeContent=[];
            $i=0;
            $sub_plans=SubscriptionPlan::paginate(10);
            foreach ($sub_plans as $plan)
            {
                $dataTypeContent[$i]=$plan;
                $dataTypeContent[$i]['name']=$plan->name_en;
                $dataTypeContent[$i]['disabled']=$plan->disabled;
                $medicals=SubscriptionOrder::where("subscription_plan_id","=",$plan->id)->where('status','Active')->count();
                $dataTypeContent[$i]['number']=$medicals;
                $i++;
            }
            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;

            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

            $view = "vendor.voyager.medical-providers.browse";

            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($sub_plans->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $sub_plans->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }
            return Voyager::view($view, compact(
                'actions',
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
    public function update(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Compatibility with Model binding.
        $id = $id instanceof Model ? $id->{$id->getKeyName()} : $id;

        $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

        // Check permission
        $this->authorize('edit', $data);

        // Validate fields with ajax
        $val = $this->validateBread($request->all(), $dataType->editRows, $dataType->name, $id);

        if ($val->fails()) {
            return response()->json(['errors' => $val->messages()]);
        }
        $valid=Validator::make($request->all(),[
            'name_ar' => [
                'required', 'Filled','regex:/^[\pL\s\-]+$/u' ,'string' ,
                Rule::unique('subscription_plans')->ignore($id),
            ],
            'name_en' => [
                'required', 'Filled','regex:/^[\pL\s\-]+$/u', 'string' ,
                Rule::unique('subscription_plans')->ignore($id),
            ],
            'body_en' => [
                'required', 'Filled','string' ,
            ],
            'body_ar' => [
                'required', 'Filled','string',
            ],
            'price' =>[
                'required', 'Filled', 'numeric','min:1' , 'max:999999.99', 'regex:/^\d+(\.\d{1,2})?$/',
            ]

        ])->validate();
//        if($valid->fails()) {
//            return response()->json(['errors' => $valid->messages()]);
//        }
        if (!$request->ajax()) {
            $sub_plan=SubscriptionPlan::find($id);
            $sub_plan->name_ar=$request->name_ar;
            $sub_plan->name_en=$request->name_en;
            $sub_plan->body_en=$request->body_en;
            $sub_plan->body_ar=$request->body_ar;
            $sub_plan->price=$request->price;
            $sub_plan->save();
            $previousUrl = explode('page=' , $request->redirects_to);
            event(new BreadDataUpdated($dataType, $data));

            return redirect()
                ->route("voyager.subscription-plans.index" , ['page'=>$previousUrl['1'] ?? 1])
                ->with([
                    'message'    => __('voyager::generic.successfully_updated')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function edit(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=',$slug)->first();

        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? app($dataType->model_name)->findOrFail($id)
            : DB::table($dataType->name)->where('id', $id)->first(); // If Model doest exist, get data from table name
        $sub_plan= SubscriptionPlan::find($id);
        $dataTypeContent->price=$sub_plan->price;
        $dataTypeContent->ar_name=$sub_plan->name_ar;
        $dataTypeContent->en_name=$sub_plan->name_en;
        $dataTypeContent->ar_body=$sub_plan->body_ar;
        $dataTypeContent->en_body=$sub_plan->body_en;
        foreach ($dataType->editRows as $key => $row) {
            $dataType->editRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }

        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'edit');

        // Check permission
        $this->authorize('edit', $dataTypeContent);

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable'));
    }
    public function show(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug','=',$slug)->first();

        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $dataTypeContent = call_user_func([$model, 'findOrFail'], $id);
        } else {
            // If Model doest exist, get data from table name
            $dataTypeContent = DB::table($dataType->name)->where('id', $id)->first();
        }

        // Replace relationships' keys for labels and create READ links if a slug is provided.
        $dataTypeContent = $this->resolveRelations($dataTypeContent, $dataType, true);
        $dataTypeContent->number=SubscriptionOrder::where("subscription_plan_id","=",$dataTypeContent->id)->where('status','Active')->count();
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'read');

        // Check permission
        $this->authorize('read', $dataTypeContent);

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.read';

        if (view()->exists("voyager::$slug.read")) {
            $view = "voyager::$slug.read";
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable'));
    }
    public function subscribersInfo (Request $request)
    {
        $this->authorize('browse', app('App\SubscriptionPlan'));
        $orders= \App\SubscriptionOrder::where('status','Active')->where('subscription_plan_id',$request->id)->orderBy('created_at')->paginate(30);
        $orders->appends(['id' => $request->id ]);
        $subscription_plan_id= $request->id;
        return Voyager::view('voyager::subscription-plans.subscribers', compact('orders','subscription_plan_id'));
    }
    public function editOrderImage(Request $request)
    {
        $valid=Validator::make($request->all(),[
            'ad_image' => [
                'image','max:10240'
            ],
            'ad_url'=>['required']
        ]);
        if(!empty($request->file('ad_image')))
        {
            $data = getimagesize($request->file('ad_image'));
            $width = $data[0];
            $height = $data[1];
            if($width==$height) {
                $valid->errors()->add('ad_image', 'invalid dimensions for image');
            }

        }
        if(count($valid->errors())>0) {
            return Redirect::back()->withErrors($valid->messages());
        }

        $subscriptionOrder = SubscriptionOrder::find($request->id);
        if(!empty($request->file('ad_image'))) {
            $imagePath = $request->file('ad_image')->store('/users/advertise-images');
            $image = Image::make(Storage::get($imagePath))->encode();
            Storage::put($imagePath, $image);
//            if (! \File::exists(storage_path().'/app/public/users/advertise-images')){
//                \File::makeDirectory(storage_path().'/app/public/users/advertise-images',0777,true,true);
//            }
//            \File::put(storage_path().'/app/public/users/'.$imagePath,$image);
            $orderMeta  = array(
                'image' => $request->file('ad_image')->hashName(),
                'url' => $request->ad_url,
            );
        }
        else {
            $imagePathOld=json_decode($subscriptionOrder->order_meta)->image;
            $orderMeta  = array(
                'image' => $imagePathOld,
                'url' => $request->ad_url,
            );
        }

        $orderMeta = json_encode($orderMeta);
        $subscriptionOrder->order_meta=$orderMeta;
        if($subscriptionOrder->save())
        {
            return Redirect::back();
        }
    }
}
