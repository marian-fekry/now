<?php

namespace App\Http\Controllers;
use App\PrivateReservation;
use App\Specialty;
use Illuminate\Http\Request;
use App\User;
use App\MedicalProviderHasSpecialties;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use phpDocumentor\Reflection\Types\Array_;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
use TCG\Voyager\Http\Controllers\VoyagerBaseController as BaseVoyagerController;
use Redirect;
use Validator;
use Carbon\Carbon ;
use App\MedicalProvider;
use Illuminate\Validation\Rule;
class PrivateReservationVoyagerController extends BaseVoyagerController
{
    public function index(Request $request)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();
        // Check permission
        $this->authorize('browse', app($dataType->model_name));
        $getter = $dataType->server_side ? 'paginate' : 'get';
        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');
            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');
            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $dataTypeContent = DB::table('private_reservations')->leftJoin('users as user', 'user.id', '=', 'private_reservations.user_id')->where('user.deleted_at' , '=' , Null)->get(['user.*' ,'private_reservations.id' ]);
            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            $dataTypeContent=PrivateReservation::whereHas('user',function($query){
                $query->where('deleted_at' , '=' , Null);
            })->orderBy('id', 'DESC')->paginate(10);

            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;
            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;
            $view = "vendor.voyager.private-reservations.browse";
            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($dataTypeContent->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $dataTypeContent->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }
            return Voyager::view($view, compact(
                'actions',
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
    public function update(Request $request, $id)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'private-reservations')->first();
        // Compatibility with Model binding.
        $id = $id instanceof Model ? $id->{$id->getKeyName()} : $id;
        $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);
        // Check permission
        $this->authorize('edit', $data);
        // Validate fields with ajax
        $val = $this->validateBread($request->all(), $dataType->editRows, $dataType->name, $id);
        if ($val->fails()) {
            return response()->json(['errors' => $val->messages()]);
        }
        $valid = Validator::make($request->all(),[
            'name' => [
                'required', 'Filled' , 'string' ,
                Rule::unique('users')->ignore( $request->user_id),
            ],
            'email' => [
                'required', 'Filled' , 'E-Mail' , 'string' ,
                Rule::unique('users')->ignore( $request->user_id),
            ],
            'password' =>  'nullable|string' ,
            'hidden_edit_speciality' =>  'required' ,
        ] , ["hidden_edit_speciality.required"=>"Speciality Is Required"])->validate();

        if (!$request->ajax()) {
            //$this->insertUpdateData($request, $slug, $dataType->editRows, $data);
            $privateReservation = New PrivateReservation();
            $privateReservation->editPrivateReservationAdmin($request->email, $request->name,$request->hidden_edit_speciality  ,$request->hidden_edit_medical,$id,$request->password);

            event(new BreadDataUpdated($dataType, $data));
            $countParametersUrl = count(explode('&', $request->redirects_to));
            if($countParametersUrl>1) {
                $parametersString = explode('?', $request->redirects_to);
                preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
                $parameterString = "";
                for ($i = 0; $i < $countParametersUrl; $i++) {
                    $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
                }
                $routeName = "privateReservation.search";
            }
            else{
                $previousUrl = explode('page=' , $request->redirects_to);
                $routeName = "voyager.private-reservations.index";
                $parameterString= "page=";
                $parameterString.= $previousUrl['1'] ?? 1;
            }
            return redirect()
                ->route($routeName , $parameterString)
                ->with([
                    'message'    => __('voyager::generic.successfully_updated')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function edit(Request $request, $id)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'private-reservations')->first();
        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? app($dataType->model_name)->findOrFail($id)
            : DB::table($dataType->name)->where('id', $id)->first(); // If Model doest exist, get data from table name
        foreach ($dataType->editRows as $key => $row) {
            $dataType->editRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'edit');
        // Check permission
        $this->authorize('edit', $dataTypeContent);
        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $view = 'vendor.voyager.private-reservations.edit-add';
        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        $userInfo = DB::table('users')->where('id', $dataTypeContent->user_id)->first();
        $allmedicalProviders=MedicalProvider::whereHas('user',function($query){
            return $query->where('deleted_at', '=', Null)->where('disabled','=',0);
        })->paginate(10);
        $medicalProviders=[];
        $i=0;
        if($allmedicalProviders)
        {
            foreach ($allmedicalProviders as $medicalProvider) {
                $user=User::where('id','=',$medicalProvider->user_id)->get();
                if($user)
                {
                    $medicalProviders[$i]=$medicalProvider;
                    $medicalProviders[$i]['name']=$user[0]->name;
                    $i++;
                }
            }
        }
        $allspecialities = Specialty::where('disabled','=',0)->paginate(10);
        $specialities=[];
        $i=0;
        if($allspecialities)
        {
            foreach ($allspecialities as $speciality)
            {
                $specialities[$i]=$speciality;
                $i++;
            }
        }
        $medical_Providers = new MedicalProvider();
        $listMedicalProviders = $medical_Providers->listMedicalProviders();
        $userInfo = DB::table('users')->where('id', $dataTypeContent->user_id)->first();
        $medicalProviderSpecialties = DB::table('medical_provider_has_specialties')->where('departement_secretary_id', $id)->first();
       if($medicalProviderSpecialties) {
           $medicalproviderSpecialtiesAll = DB::table('specialties')
               ->join('medical_provider_has_specialties', function ($join) use ($medicalProviderSpecialties) {
                   $join->on('medical_provider_has_specialties.speciality_id', '=', 'specialties.id')
                       ->where('medical_provider_has_specialties.medical_provider_id', '=', $medicalProviderSpecialties->medical_provider_id);
               })
               ->get();
       }
       else
       {
           $medicalproviderSpecialtiesAll = [];
       }
       if(!is_null($request->old('hidden_edit_medical'))) {
           $newMedicalName = MedicalProvider::find($request->old('hidden_edit_medical'));
           $dataTypeContent['medical_name'] = $newMedicalName->user->fullname_en;
       }
        if(!is_null($request->old('hidden_edit_speciality'))) {
            $newSpecialty = Specialty::find($request->old('hidden_edit_speciality'));
            $newSpecialty['speciality_name'] = $newSpecialty->name_en;
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable' , 'userInfo' , 'listMedicalProviders' , 'medicalProviderSpecialties' , 'medicalproviderSpecialtiesAll','allmedicalProviders','medicalProviders','allspecialities','specialities'));
    }
    public function create(Request $request)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'private-reservations')->first();
        // Check permission
        $this->authorize('add', app($dataType->model_name));
        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? new $dataType->model_name()
            : false;
        foreach ($dataType->addRows as $key => $row) {
            $dataType->addRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'add');
        // Check if BREAD is Translatable
        $allmedicalProviders=MedicalProvider::whereHas('user',function($query){
            return $query->where('deleted_at', '=', Null);
        })->where('type' , '!=' , 'private_clinic')->paginate(10);
        $medicalProviders=[];
        $i=0;
        if($allmedicalProviders)
        {
            foreach ($allmedicalProviders as $medicalProvider) {
                $user=User::where('id','=',$medicalProvider->user_id)->where('disabled','=',0)->get();
                if($user)
                {
                    $medicalProviders[$i]=$medicalProvider;
                    $medicalProviders[$i]['name']=$user[0]->name;
                    $i++;
                }
            }
        }
        $allspecialities = Specialty::paginate(10);
        $specialities=[];
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $view = 'voyager::bread.edit-add';
        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        $medical_Providers = new MedicalProvider();
        $listMedicalProviders = $medical_Providers->listMedicalProviders();
        $userInfo = DB::table('users')->where('id', $dataTypeContent->user_id)->first();
        if(!is_null($request->old('hidden_add_medical'))) {
            $newMedicalName = MedicalProvider::find($request->old('hidden_add_medical'));
            $dataTypeContent['medical_name'] = $newMedicalName->user->fullname_en;
        }
        if(!is_null($request->old('hidden_edit_speciality'))) {
            $newSpecialty = Specialty::find($request->old('hidden_edit_speciality'));
            $newSpecialty['speciality_name'] = $newSpecialty->name_en;
        }
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable' , 'userInfo' , 'listMedicalProviders','allmedicalProviders','allspecialities','specialities','medicalProviders'));
    }
    public function store(Request $request)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'private-reservations')->first();
        // Check permission
        $this->authorize('add', app($dataType->model_name));
        // Validate fields with ajax
        $val = $this->validateBread($request->all(), $dataType->addRows);
        if ($val->fails()) {
            return response()->json(['errors' => $val->messages()]);
        }
        $valid = Validator::make($request->all(),[
            'name'=>'required|Filled|string',
            'password' => 'required', 'Filled' , 'string' ,
            'email'=>'required|Unique:users|Filled|E-Mail|string',
            'hidden_add_medical' => 'required' ,
            'hidden_add_speciality' => 'required' ,
        ],["hidden_add_medical.required"=>"Medical Provider Is Required","hidden_add_speciality.required"=>"Speciality Is Required"])->validate();
//        if($valid->fails()) {
//            return response()->json(['errors' => $valid->messages()]);
//        }
        if (!$request->has('_validate')) {
            //$data = $this->insertUpdateData($request, $slug, $dataType->addRows, new $dataType->model_name());
            $privateReservation = New PrivateReservation();
            $data = $privateReservation->addPrivateReservationAdmin($request->name,$request->email, $request->password  ,$request->hidden_add_speciality  ,$request->hidden_add_medical);
            event(new BreadDataAdded($dataType, $data));
            if ($request->ajax()) {
                return response()->json(['success' => true, 'data' => $data]);
            }
            return redirect()
                ->route("voyager.private-reservations.index")
                ->with([
                    'message'    => __('voyager::generic.successfully_added_new')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function deletePrivateReservation(Request $request)
    {
        $ids = [];
        // Bulk delete, get IDs from POST
        $ids =  $request->row_id;
        if(!empty($ids)){
            foreach($ids as $id)
            {
                $privateReservation = PrivateReservation::find($id);
                MedicalProviderHasSpecialties::where('departement_secretary_id', $id)->update(['departement_secretary_id' => Null]);
                $user = User::find($privateReservation->user_id);
                $user->delete();
                //$user->save();
            }
        }
        return 'true';
    }
    public function delete_single($id)
    {
        $privateReservation = PrivateReservation::find($id);
        MedicalProviderHasSpecialties::where('departement_secretary_id', $id)->update(['departement_secretary_id' => Null]);
        $user = User::find($privateReservation->user_id);
        $user->delete();
        //$user->save();
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "privateReservation.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.private-reservations.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()
            ->route($routeName ,[$parameterString]);
    }
    public function show(Request $request, $id)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'private-reservations')->first();
        $dataTypeMainTable = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $modelMainContent = app($dataTypeMainTable->model_name);
            $dataTypeContent = call_user_func([$model, 'findOrFail'], $id);
            $dataTypeContentMainTable = call_user_func([$modelMainContent, 'findOrFail'], $dataTypeContent->user_id);


        } else {
            // If Model doest exist, get data from table name
            $dataTypeContent = DB::table($dataType->name)->Join('doctor', 'users.id', '=', 'private_reservations.user_id')->where('users.id', $id)->first();
        }

        // Replace relationships' keys for labels and create READ links if a slug is provided.
        $dataTypeContent = $this->resolveRelations($dataTypeContent, $dataType, true);
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'read');
        // Check permission
        $this->authorize('read', $dataTypeContent);
        $privateReservation = PrivateReservation::find($id);
        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "privateReservation.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.private-reservations.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        $view = 'vendor.voyager.private-reservations.read';
        if (view()->exists("voyager::$slug.read")) {
            $view = "voyager::$slug.read";
        }
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable' , 'dataTypeMainTable' , 'dataTypeContentMainTable' , 'privateReservation' , 'routeName' , 'parameterString' ));
    }

    public function medicalproviderSpecialties (Request $request)
    {
        $id =  $request->id;
        $medicalproviderSpecialties = DB::table('specialties')
            ->join('medical_provider_has_specialties', function ($join)  use ($id){
                $join->on('medical_provider_has_specialties.speciality_id', '=', 'specialties.id')
                    ->where('medical_provider_has_specialties.medical_provider_id', '=', $id);
            })
            ->get();
        return response()->json($medicalproviderSpecialties);
    }

    public function privateReservationDeactivate($id)
    {
        $privateReservation = PrivateReservation::find($id);
        $user = User::find($privateReservation->user_id);
        $user->disabled = 1;
        $user->save();
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "privateReservation.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.private-reservations.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName , [$parameterString]);
    }

    public function privateReservationActivate($id)
    {
        $privateReservation = PrivateReservation::find($id);
        $user = User::find($privateReservation->user_id);
        $user->disabled = 0;
        $user->save();
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "privateReservation.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.private-reservations.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName , [$parameterString]);
    }
    function filter_search(Request $request)
    {
        if($request->get('type') == 1)
        {
            $query=$request->get('query')!==null? $request->get('query') : "" ;
            $allmedicalProviders = User::where('name', 'LIKE', "%{$query}%")->where('disabled','=',0)->whereHas('medicalprovider' ,function($q){
            $q->where('type', '!=', 'private_clinic');})->paginate(10);
            $medicalProviders=[];
            $i=0;
            if($allmedicalProviders)
            {
                foreach ($allmedicalProviders as $medical)
                {
                    $user=MedicalProvider::where('user_id','=',$medical->id)->get();
                    if($user)
                    {
                        $medicalProviders[$i]=$user[0];
                        $medicalProviders[$i]['name']=$medical->name;
                        $i++;
                    }
                }
            }
            return Voyager::view('vendor.voyager.private-reservations.paginate_medical', compact('allmedicalProviders','medicalProviders'))->render();
        }
        else if($request->get('type') == 2)
        {
            $allspecialities=DB::table("medical_provider_has_specialties")->where("medical_provider_id","=",$request->medical_provider_id)->paginate(10);
            $query=$request->get('query')!==null? $request->get('query') : "" ;
            $specialities = [];
            $i = 0;
            if($allspecialities) {
                foreach ($allspecialities as $speciality) {
                    $speciality_from_speciality = Specialty::where("id","=",$speciality->speciality_id)->where('name_en', 'LIKE', "%{$query}%")
                        ->orwhere(function($q) use ($query , $speciality) {
                            $q->where("id","=",$speciality->speciality_id)->where('name_ar', 'LIKE', "%{$query}%");
                        })->where('disabled', '=', 0)->get();
                    if ($speciality_from_speciality) {
                        foreach ($speciality_from_speciality as $speciality)
                        {
                            $specialities[$i] = $speciality;
                            $i++;
                        }

                    }
                }
            }
            return Voyager::view('vendor.voyager.private-reservations.paginate_speciality', compact('allspecialities','specialities'))->render();
        }
    }
    function hadPrivate(Request $request)
    {
        $ifhad=DB::table("medical_provider_has_specialties")->where("speciality_id","=",$request->speciality)->where("medical_provider_id","=",$request->medical_provider_id)->get();
        if($ifhad[0]->departement_secretary_id == null)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
    public function privateReservationSearch(Request $request)
    {

        $emailSearch = $request->email;
        $nameSearch = $request->name;
        $medicalNameSearch = $request->medical;
        $specialitySearch = $request->speciality;
        $statusSearch = $request->status;
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = "private-reservations";
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();
        // Check permission
        $this->authorize('browse', app($dataType->model_name));
        $getter = $dataType->server_side ? 'paginate' : 'get';
        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');
            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');
            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $dataTypeContent = DB::table('private_reservations')->leftJoin('users as user', 'user.id', '=', 'private_reservations.user_id')->where('user.deleted_at' , '=' , Null)->get(['user.*' ,'private_reservations.id' ]);
            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            $dataTypeContent=PrivateReservation::whereHas('user',function($query) use ($emailSearch,$nameSearch,$statusSearch){
                $query->where('deleted_at' , '=' , Null);
                if($emailSearch!='')
                    $query->where('email','like' , '%'.$emailSearch .'%');
                if($nameSearch!='')
                    $query->where('fullname','like' , '%'.$nameSearch.'%');
                if($statusSearch!='')
                    $query->where('verified',$statusSearch);
            })->whereHas('medicalProvider',function($query) use ($medicalNameSearch){
                if($medicalNameSearch!='')
                {
                    $query->wherehas('user' ,function($query) use ( $medicalNameSearch )
                    {
                        $query->where('fullname_en', 'like' , '%'.$medicalNameSearch.'%');
                        $query->orWhere('fullname', 'like' , '%'.$medicalNameSearch.'%');
                    });
                }
            })->whereHas('privateReservationSpecialty',function($query) use ($specialitySearch){
        if($specialitySearch!='')
            $query->where('name_en', 'like' , '%'.$specialitySearch.'%')->orWhere('name_ar', 'like' , '%'.$specialitySearch.'%');

          })->paginate(10);

            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;
            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;
            $view = "vendor.voyager.private-reservations.browse";
            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($dataTypeContent->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $dataTypeContent->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }
            return Voyager::view($view, compact(
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'emailSearch',
                'nameSearch',
                'medicalNameSearch',
                'specialitySearch',
                'statusSearch',
                'actions'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }

}
