<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Jobtitle;

class JobtitleController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }
    public function index(){
        if(Auth::user()->hasPermission('browse_jobtitles')==1) {
            $obj=new Jobtitle();
            $allJobTitles =$obj->index();
            return OutPut::Response($allJobTitles,'',200);
        } else {
            return OutPut::Response('',__('messages.auth_error_jobtitle'),401);
        }
    }

}
