<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Specialty;
use App\Staticpage;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use phpDocumentor\Reflection\Types\Array_;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
use TCG\Voyager\Http\Controllers\VoyagerBaseController as BaseVoyagerController;
use Redirect;
use Illuminate\Support\Facades\validator;
use Illuminate\Validation\Rule;
use Carbon\Carbon ;
class StaticPageVoyagerController extends BaseVoyagerController
{
    public function index(Request $request)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $pages=Staticpage::paginate(10);
            $dataTypeContent=[];
            $i=0;
            foreach ($pages as $page)
            {
                $dataTypeContent[$i]['id']=$page->id;
                $dataTypeContent[$i]['title']=$page->title;
                $dataTypeContent[$i]['title_ar']=$page->title_ar;
                $dataTypeContent[$i]['arabic']=$page->arabic;
                $dataTypeContent[$i]['english']=$page->english;
                $dataTypeContent[$i]['disabled']=$page->disabled;
                $i++;
            }
            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;

            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

            $view = "vendor.voyager.staticpages.browse";

            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($pages->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $pages->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }
            return Voyager::view($view, compact(
                'actions',
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'pages'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
    public function update(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Compatibility with Model binding.
        $id = $id instanceof Model ? $id->{$id->getKeyName()} : $id;

        $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

        // Check permission
        $this->authorize('edit', $data);

        // Validate fields with ajax
        $val = $this->validateBread($request->all(), $dataType->editRows, $dataType->name, $id);

        if ($val->fails()) {
            return response()->json(['errors' => $val->messages()]);
        }


        if (!$request->ajax()) {
            $textpage=Staticpage::find($id);
            $textpage->title=$request->title;
            $textpage->title_ar=$request->title_ar;
            $textpage->arabic= $request->arabic;
            $textpage->english=$request->english;
            $textpage->save();
            event(new BreadDataUpdated($dataType, $data));

            return redirect()
                ->route("voyager.staticpages.index")
                ->with([
                    'message'    => __('voyager::generic.successfully_updated')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function edit(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        foreach ($dataType->editRows as $key => $row) {
            $dataType->editRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }
        $dataTypeContent=Staticpage::find($id);
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'edit');
        // Check permission

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';


        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable'));
    }
    public function create(Request $request)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? new $dataType->model_name()
            : false;

        foreach ($dataType->addRows as $key => $row) {
            $dataType->addRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }


        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'add');

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable'));
    }
    public function show(Request $request, $id)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $dataTypeContent = call_user_func([$model, 'findOrFail'], $id);
        } else {
            // If Model doest exist, get data from table name
            $dataTypeContent = DB::table($dataType->name)->where('id', $id)->first();
        }

        // Replace relationships' keys for labels and create READ links if a slug is provided.
        $dataTypeContent = $this->resolveRelations($dataTypeContent, $dataType, true);
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'read');

        // Check permission
        $this->authorize('read', $dataTypeContent);

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.read';

        if (view()->exists("voyager::$slug.read")) {
            $view = "voyager::$slug.read";
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable'));
    }
    public function store(Request $request)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();
        // Check permission
        $this->authorize('add', app($dataType->model_name));
        // Validate fields with ajax
        $val = $this->validateBread($request->all(), $dataType->addRows);
        if ($val->fails()) {
            return response()->json(['errors' => $val->messages()]);
        }
        if (!$request->has('_validate')) {
            $data= new Staticpage();
            $slugpage=$request->title;
            $slugpage=strtolower($request->title);
            $slugpage= $string = preg_replace('/\s+/', '', $slugpage);
            $slugpage=$slugpage ."". mt_rand(1,100)."".mt_rand(1000,100000);
            $data->arabic=$request->arabic;
            $data->english=$request->english;
            $data->title=$request->title;
            $data->title_ar=$request->title_ar;
            $data->slug=$slugpage;
            $data->save();
            event(new BreadDataAdded($dataType, $data));
            if ($request->ajax()) {
                return response()->json(['success' => true, 'data' => $data]);
            }
            return redirect()
                ->route("voyager.staticpages.index")
                ->with([
                    'message'    => __('voyager::generic.successfully_added_new')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function Deletepage(Request $request)
    {

        $ids = [];

        // Bulk delete, get IDs from POST
        $ids =  $request->row_id;
        foreach($ids as $id)
        {
            if(!empty($id)) {
                $user = Staticpage::find($id);
                $user->deleted_at = Carbon::now();
                $user->save();
            }
        }
        return 'true';

    }
    public function delete_single($id)
    {
        $user = Staticpage::find($id);
        $user->deleted_at = Carbon::now();
        $user->save();
        return redirect()->route("voyager.staticpages.index");
    }

    public function staticPageDeactivate($id)
    {
        $jobTitle = Staticpage::find($id);
        $jobTitle->disabled = 1;
        $jobTitle->save();
        return redirect()->route("voyager.staticpages.index");
    }

    public function staticPageActivate($id)
    {
        $jobTitle = Staticpage::find($id);
        $jobTitle->disabled = 0;
        $jobTitle->save();
        return redirect()->route("voyager.staticpages.index");
    }
}
