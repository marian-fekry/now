<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\SubscriptionPlan;
use App\SubscriptionOrder;
use Validator;
class SubscriptionPlansController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api',['except'=>['loginAds']]);
    }
    public function subscriptionPlans(Request $request){
        $valid=Validator::make($request->all(),[
            'governrate_id'=>'required|Filled',
        ]);

        if($valid->fails()){
            return OutPut::Response('',$valid->Errors(),403);
        }
        if(Auth::user()->hasRole('ROLE_HOSPITAL')||Auth::user()->hasRole('ROLE_PRIVATE_CLINIC')||Auth::user()->hasRole('ROLE_SHARED_CLINIC')||Auth::user()->hasRole('ROLE_MEDICAL_PROVIDER')) {
            $obj=new SubscriptionPlan();
            $plans =$obj->index($request->input('governrate_id'));
            return OutPut::Response($plans,'',200);
        } else {
            return OutPut::Response('',__('messages.auth_error_plans'),401);
        }
    }


    public function subscriptionOrderPay(Request $request)
    {
        if(Auth::user()->hasRole('ROLE_HOSPITAL')||Auth::user()->hasRole('ROLE_PRIVATE_CLINIC')||Auth::user()->hasRole('ROLE_SHARED_CLINIC')||Auth::user()->hasRole('ROLE_MEDICAL_PROVIDER')) {
            $valid=Validator::make($request->all(),[
                'subscription_plan_id'=>'required|Filled|numeric',
                'amount'=>'required|Filled|numeric',
                'duration_minutes'=>'required_if:subscription_plan_id,3|Filled|numeric',

                'cardNumber'=>'required|Filled|numeric',
                'cardType'=>'required|Filled|string',
                'expMonth'=>'required|Filled|numeric',
                'expYear'=>'required|Filled|numeric',
                'cvc'=>'required|Filled|numeric',
                'cardHolderName'=>'required|Filled|string',
                'userIP'=>'required|Filled|ip',
            ]);

            if($valid->fails()){
                return OutPut::Response('',$valid->Errors(),403);
            }

            if($request->input('duration_minutes')<=0 && $request->input('subscription_plan_id')==3){
                return OutPut::Response('', __('messages.adding_plan_error_duration_below_min'), 403);
            }
            $userId=Auth::user()->id;
            $medicalProvider=\App\MedicalProvider::where('user_id',$userId)->first();
            $medicalProviderId=$medicalProvider->id;

            $reservation=\App\SubscriptionOrder::where('medical_provider_id',$medicalProviderId)
            ->where('subscription_plan_id',$request->input('subscription_plan_id'))
            ->where('status','Active')->first();
            if(null!==$reservation){
                return OutPut::Response('', __('messages.adding_plan_already_join'), 403);
            }

            $plan = \App\SubscriptionPlan::where('disabled' , '=' , 0)->where('id',$request->input('subscription_plan_id'))->first();
            if(null!==$plan){
                if($request->input('amount')>=$plan->price){

                }else{
                    return OutPut::Response('', __('messages.adding_plan_error_amount_below_min'), 403);
                }
            }else{
                return OutPut::Response('', __('messages.adding_plan_error_plan_not_found'), 403);
            }



            $date = gmdate('Y-m-d H:i:s');
            $code = 250181972896;
            $key = 'sWNb4o7FH~S%?JgkO^QP';
            $hash = hash_hmac('md5', strlen($code) . $code . strlen($date) . $date, $key);
            $headers = array(
                'Content-Type: application/json',
                'Accept: application/json',
                'X-Avangate-Authentication: '.'code="' . $code . '" date="' . $date . '" hash="' . $hash . '"',
            );
            $userName=explode(" ",Auth::user()->fullname);
            $firstName=$userName[0];
            $address1 = isset($medicalProvider->governrate->name_en)?$medicalProvider->governrate->name_en:"riyadh";
            $lastName='user';
            if(sizeof($userName)==2){
                $lastName=$userName[1];
            }
            $data='{
                "Currency":"sar",
                "Language":"ar",
                "Country":"SA",
                "Items":[
                    {
                    "Quantity":"1",
                    "IsDynamic":true,
                    "PurchaseType":"PRODUCT",
                    "Price":{
                        "Amount":"'.$request->input('amount').'"
                    },
                    "Name":"'.$plan->name_en.'"
                }],
                "BillingDetails":{
                        "FirstName":"'.$firstName.'",
                        "LastName":"'.$lastName.'",
                        "CountryCode":"SA",
                        "City":"riyadh",
                        "Address1":"'.$address1.'",
                        "Zip":"12345",
                        "Email":"'.Auth::user()->email.'"
                },
                "PaymentDetails":{
                    "Type":"TEST",
                    "Currency":"sar",
                    "CustomerIP":"'.$request->input('userIP').'",
                    "PaymentMethod":{
                        "HolderName":"'.$request->input('cardHolderName').'",
                        "CardNumber":"'.$request->input('cardNumber').'",
                        "ExpirationYear":"20'.$request->input('expYear').'",
                        "ExpirationMonth":"'.$request->input('expMonth').'",
                        "CCID":"'.$request->input('cvc').'",
                        "CardType":"'.$request->input('cardType').'",
                        "Vendor3DSReturnURL":"'.url('/').'",
                        "Vendor3DSCancelURL":"'.url('/').'"
                    }
                }
            }
            ';

            $ch =curl_init();
            curl_setopt($ch,CURLOPT_URL,"https://api.2checkout.com/rest/5.0/orders/");
            curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
            curl_setopt($ch,CURLOPT_POST,1);
            curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
            curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
            $output=curl_exec($ch);

            curl_close($ch);
            $output=json_decode($output,TRUE);
            if(isset($output['error_code'])){
                return OutPut::Response('',$output['message'], 403);
            }

            if($output['Errors']!=null){
                $errors=array();
                foreach ($output['Errors'] AS $key=>$val){
                    array_push($errors,array($key=>array($val)));
                }
                $errors=$errors[0];
                return OutPut::Response('', $errors, 403);
            }

            $ReferenceNumber=$output['RefNo'];
            sleep(15);

            return OutPut::Response(array("RefNo"=>$ReferenceNumber),'',200);
        } else {
            return OutPut::Response('',__('messages.auth_error_plans'),401);
        }
    }
    public function subscriptionOrder(Request $request)
    {
        if(Auth::user()->hasRole('ROLE_HOSPITAL')||Auth::user()->hasRole('ROLE_PRIVATE_CLINIC')||Auth::user()->hasRole('ROLE_SHARED_CLINIC')||Auth::user()->hasRole('ROLE_MEDICAL_PROVIDER')) {
            $valid=Validator::make($request->all(),[
                'subscription_plan_id'=>'required|Filled|numeric',
                'amount'=>'required|Filled|numeric',
                'duration_minutes'=>'required_if:subscription_plan_id,3|Filled|numeric',
                'RefNo'=>'required|Filled|numeric',

            ]);

            if($valid->fails()){
                return OutPut::Response('',$valid->Errors(),403);
            }

            if($request->input('duration_minutes')<=0 && $request->input('subscription_plan_id')==3){
                return OutPut::Response('', __('messages.adding_plan_error_duration_below_min'), 403);
            }
            $userId=Auth::user()->id;
            $medicalProvider=\App\MedicalProvider::where('user_id',$userId)->first();
            $medicalProviderId=$medicalProvider->id;

            $reservation=\App\SubscriptionOrder::where('medical_provider_id',$medicalProviderId)
            ->where('subscription_plan_id',$request->input('subscription_plan_id'))
            ->where('status','Active')->first();
            if(null!==$reservation){
                return OutPut::Response('', __('messages.adding_plan_already_join'), 403);
            }

            $plan = \App\SubscriptionPlan::where('disabled' , '=' , 0)->where('id',$request->input('subscription_plan_id'))->first();
            if(null!==$plan){
                if($request->input('amount')>=$plan->price){

                }else{
                    return OutPut::Response('', __('messages.adding_plan_error_amount_below_min'), 403);
                }
            }else{
                return OutPut::Response('', __('messages.adding_plan_error_plan_not_found'), 403);
            }



            $date = gmdate('Y-m-d H:i:s');
            $code = 250181972896;
            $key = 'sWNb4o7FH~S%?JgkO^QP';
            $hash = hash_hmac('md5', strlen($code) . $code . strlen($date) . $date, $key);
            $headers = array(
                'Content-Type: application/json',
                'Accept: application/json',
                'X-Avangate-Authentication: '.'code="' . $code . '" date="' . $date . '" hash="' . $hash . '"',
            );

            $PaymentConfirmed=false;
            $retryCounter=0;
            while(!$PaymentConfirmed){
                $ch =curl_init();
                curl_setopt($ch,CURLOPT_URL,"https://api.2checkout.com/rest/5.0/orders/".$request->input('RefNo')."/");
                curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
                curl_setopt($ch,CURLOPT_POST,0);
                curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
                $res=curl_exec($ch);
                curl_close($ch);
                $res=json_decode($res,TRUE);
                if(isset($res['Status'])&& isset($res['ApproveStatus']) && $res['Status']=="COMPLETE" && $res['ApproveStatus']=="OK"){
                    $PaymentConfirmed=true;
                    break;
                }else{
                    $retryCounter++;
                }
                if($res['Errors']!=null){
                    $errors=array();
                    foreach ($res['Errors'] AS $key=>$val){
                        array_push($errors,array($key=>array($val)));
                    }
                    $errors=$errors[0];
                    return OutPut::Response('', $errors, 403);
                }
                if($retryCounter==10){
                    return OutPut::Response('', __('messages.payment_not_confirmed'), 403);
                }
                sleep(5);
            }

            $orderMeta  = array();
            if(null!==($request->input('duration_minutes'))){
                $orderMeta  = array(
                    'duration_minutes' => $request->duration_minutes,
                );
            }

            $orderMeta = json_encode($orderMeta);
            $subscriptionOrder=new SubscriptionOrder();
            // check if this reference found before
            $orderRef=\App\SubscriptionOrder::where('reference_number',$request->input('RefNo'))->first();
            if(null!==$orderRef){
                return OutPut::Response('', __('messages.ref_number_already_used'), 403);
            }else{
                $subscriptionOrderAdd=$subscriptionOrder->add( $medicalProviderId,$request->subscription_plan_id , $request->amount , $orderMeta,$request->input('RefNo'));
                if($subscriptionOrderAdd) {
                    if($request->input('subscription_plan_id')==3){
                        $governeratesTimeReservations=new \App\GoverneratesTimeReservations();

                        $governeratesTimeReservations->setGovernerateReservedMinutes($medicalProviderId,$medicalProvider->governrate_id,$request->duration_minutes,$subscriptionOrderAdd->id);
                    }
                    return OutPut::Response('', __('messages.plans_added_successful'), 200);
                }
                else {
                    return OutPut::Response('', __('messages.adding_plan_error'), 403);
                }
            }


        } else {
            return OutPut::Response('',__('messages.auth_error_plans'),401);
        }
    }

    public function loginAds ()
    {
        $subscriptionOrder=new \App\SubscriptionOrder();
        $ads=$subscriptionOrder->loginAds();
        return OutPut::Response($ads, '', 200);
    }



}
