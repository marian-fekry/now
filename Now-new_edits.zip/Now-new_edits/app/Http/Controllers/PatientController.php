<?php

namespace App\Http\Controllers;
use App\Patient;
use App\Request as RequestModel;
use Illuminate\Http\Request;
use Validator;
use Auth;

class PatientController extends Controller
{
  use OutPut;

  public function __construct()
  {
      $this->middleware('auth:api');
  }

  public function arrived(Request $request){
    $user=Auth::user();
    app()->setLocale($user->token()->user_lang);
    $valid=Validator::make($request->all(),[
      'request_id'=>'required|Filled|numeric',
      'respond'=>'required|Filled|string',// respond can have values y - n only
    ]);

    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }

    $req = \App\Request::where('status','Confirm')->where('id',$request->input("request_id"))->first();
    if($req!=null){
      if((Auth::user()->id==$req->patient->user_id)){
        if($request->input("respond")=="y"){
          $doctor=\App\Doctor::find($req->doctor_id);
          $secretary=\App\Secretary::where('doctor_id',$req->doctor_id)->first();
          if($secretary!=null&&isset($secretary->user_id)){
            \App\notifications::sendReminder($req->id,$secretary->user_id,'patient_arrive_mp');
          }
          \App\notifications::sendReminder($req->id,$doctor->user_id,'patient_arrive_mp');
          return OutPut::Response('','',200);
        }else{
          return OutPut::Response('','',200);
        }
      }else{
        return OutPut::Response('',__('messages.auth_error'),401);
      }
    }else{
      return OutPut::Response('',__('messages.auth_error'),401);
    }


  }

  public function edit(Request $request){
    // patient can edit his name-email-mobile-birthdate-gender
      $user=Auth::user();
      if(!($user->isPatient() || $user->isSecretary() || $user->isPrivateReservation() ) ) {
          return OutPut::Response('',__('messages.auth_error'),401);
      }
      app()->setLocale($user->token()->user_lang);
    $valid=Validator::make($request->all(),[
      'email'=>'required_without_all:name,mobile,birthdate,gender|Unique:users|email|string',
      'name'=>'required_without_all:email,mobile,birthdate,gender|string',
      'mobile'=>'required_without_all:email,name,birthdate,gender|string|nullable',
      'birthdate'=>'required_without_all:email,name,mobile,gender|string|nullable',
      'gender'=>'required_without_all:email,name,mobile,birthdate|string',
    ]
        );
    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }

    $patient = new Patient();
    $patientId=Auth::user()->id;
    $patientResponse=$patient->editPatient($request->input(),$patientId);
    if(!$patientResponse){
      return OutPut::Response('',__('messages.patient_edit_error'),505);
    }
    return OutPut::Response('',__('messages.update_successful'),200);
  }

  public function get_patient_from_request(Request $request){
    $valid=Validator::make($request->all(),[
      'request_id'=>'required|numeric|Filled',
    ]
        );
    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }

    $request=\App\Request::find($request->input('request_id'));
    if(null!==$request){
      $data=array(
        "name"=>$request->patient->user->fullname,
        "email"=>$request->patient->user->email,
        "mobile"=>$request->patient->user->mobile,
      );
      return OutPut::Response($data,'',200);
    }else{
      return OutPut::Response('','',403);
    }

  }

    public function apiDashboard(){
        $user=Auth::user();
        if(!$user->isPatient()) {
            return OutPut::Response('',__('messages.auth_error'),401);
        }
        $requestModel = new RequestModel();
        $currentRequestscount = $requestModel->currentRequestCount('patient_id' , $user->patient->id);
        $oldRequestscount = $requestModel->oldRequestCount('patient_id' ,  $user->patient->id );
        $pendingRequestsCount=$requestModel->pendingRequestCount('patient_id' ,  $user->patient->id , 'Approve');
        $waitingRequestsCount=$requestModel->pendingRequestCount('patient_id' ,$user->patient->id , 'Request');
        return OutPut::Response([
            "current_requests_count"=> $currentRequestscount,
            "old_requests_count"=> $oldRequestscount,
            "pending_requests_count"=> $pendingRequestsCount,
            'waiting_requests_count'=>$waitingRequestsCount,
        ],'',200);

    }

    public function pendingRequests (){
        $user=Auth::user();
        if(!$user->isPatient()) {
            return OutPut::Response('',__('messages.auth_error'),401);
        }
        $requestModel = new RequestModel();
        $pendingRequests=$requestModel->pendingRequests('patient_id' , $user->patient->id ,$user ,'Approve');
        return OutPut::Response($pendingRequests,'',200);

    }
}
