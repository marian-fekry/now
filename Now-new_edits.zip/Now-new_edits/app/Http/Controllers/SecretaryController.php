<?php

namespace App\Http\Controllers;
use App\Patient;
use App\Secretary;
use Illuminate\Http\Request;
use Validator;
use Auth;
use DB;
use App\Request as RequestModel ;
class SecretaryController extends Controller
{
  use OutPut;

  public function __construct()
  {
      $this->middleware('auth:api');
  }

  public function show($id){

  }

  public function edit(Request $request){
    // patient can edit his name-email-mobile-birthdate-gender
      $user=Auth::user();
      app()->setLocale($user->token()->user_lang);
      if(!( $user->isSecretary() || $user->isPrivateReservation() ) ) {
          return OutPut::Response('',__('messages.auth_error'),401);
      }
    $valid=Validator::make($request->all(),[
      'name'=>'required_without_all:email|string',
      'email'=>'required_without_all:name|string',
    ]
        );
    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }

    if(null!=$request->input('name')){
      $user->fullname=$request->input('name');
      $user->name=$request->input('name');
    }

    if(null!=$request->input('email')){
      $user->email=$request->input('email');
    }



    if($user->save()){
      return OutPut::Response('',__('messages.update_successful'),200);
    }else{
      return OutPut::Response('',__('messages.update_fail'),505);
    }

  }

    public function apiDashboard(){
        $user=Auth::user();
        if(!$user->isSecretary() || $user->secretary->doctor_id==0) {
            return OutPut::Response('',__('messages.auth_error'),401);
        }
        $doctorModel = new RequestModel();
        $currentRequestscount = $doctorModel->currentRequestCount('doctor_id' , $user->secretary->doctor_id);
        $oldRequestscount = $doctorModel->oldRequestCount('doctor_id' , $user->secretary->doctor_id );
        $pendingRequestsCount=$doctorModel->pendingRequestCount('doctor_id' , $user->secretary->doctor_id ,  'Request');
        $waitingRequestsCount=$doctorModel->pendingRequestCount('doctor_id' ,$user->secretary->doctor_id , 'Approve');
        return OutPut::Response([
            "current_requests_count"=> $currentRequestscount,
            "old_requests_count"=> $oldRequestscount,
            "pending_requests_count"=> $pendingRequestsCount,
            'waiting_requests_count'=>$waitingRequestsCount,
        ],'',200);

    }
    public function pendingRequests (){
        $user=Auth::user();
        if(!$user->isSecretary() || $user->secretary->doctor_id==0) {
            return OutPut::Response('',__('messages.auth_error'),401);
        }
        $doctorModel = new RequestModel();
        $pendingRequests=$doctorModel->pendingRequests('doctor_id' , $user->secretary->doctor_id ,$user ,'Request');
        return OutPut::Response($pendingRequests,'',200);

    }
    public function apiDashboardPrivateReservation(){
        $user=Auth::user();
        if(!$user->isPrivateReservation()) {
            return OutPut::Response('',__('messages.auth_error'),401);
        }
        $doctorsData = DB::table('doctors')
            ->join('doctor_has_medical_provider', 'doctor_has_medical_provider.doctor_id', '=','doctors.id')
            ->where( 'doctor_has_medical_provider.medical_provider_id', '=', $user->privatereservation->medicalProvider['0']->id)
            ->where( 'doctors.speciality_id', '=', $user->privatereservation->privateReservationSpecialty['0']->id)
            ->select('doctors.id')
            ->get();
        $doctors=array();
        foreach ($doctorsData as $doctor )
        {
            array_push($doctors , $doctor->id);
        }
        $privateReservationModel = new \App\PrivateReservation();
        $currentRequestscount = $privateReservationModel->currentRequestCount($doctors , $user->privatereservation->medicalProvider['0']->id);
        $oldRequestscount = $privateReservationModel->oldRequestCount($doctors , $user->privatereservation->medicalProvider['0']->id);
        $pendingRequestsCount=$privateReservationModel->pendingFromPrivateReservationsRequestCount($doctors , $user->privatereservation->medicalProvider['0']->id);
        $waitingRequestsCount=$privateReservationModel->pendingFromPatientRequestCount($doctors , $user->privatereservation->medicalProvider['0']->id);
        return OutPut::Response([
            "current_requests_count"=> $currentRequestscount,
            "old_requests_count"=> $oldRequestscount,
            "pending_requests_count"=> $pendingRequestsCount,
            'waiting_requests_count'=>$waitingRequestsCount,
        ],'',200);

    }
    public function pendingPrivateReservation (){
        $user=Auth::user();
        if(!$user->isPrivateReservation()) {
            return OutPut::Response('',__('messages.auth_error'),401);
        }
        $doctorsData = DB::table('doctors')
            ->join('doctor_has_medical_provider', 'doctor_has_medical_provider.doctor_id', '=','doctors.id')
            ->where( 'doctor_has_medical_provider.medical_provider_id', '=', $user->privatereservation->medicalProvider['0']->id)
            ->where( 'doctors.speciality_id', '=', $user->privatereservation->privateReservationSpecialty['0']->id)
            ->select('doctors.id')
            ->get();
        $doctors=array();
        foreach ($doctorsData as $doctor )
        {
            array_push($doctors , $doctor->id);
        }
        $privateReservationModel = new \App\PrivateReservation();
        $pendingRequests=$privateReservationModel->pendingRequests($doctors , $user->privatereservation->medicalProvider['0']->id , $user);
        return OutPut::Response($pendingRequests,'',200);

    }
}
