<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
class ActivationController extends \TCG\Voyager\Http\Controllers\VoyagerBaseController
{
    public function deactivate(Request $request, $id)
  {

      $slug = $this->getSlug($request);

      $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

      // Check permission
      $this->authorize('delete', app($dataType->model_name));

      // Init array of IDs
      $ids = [];

      if (empty($id)) {
          // Bulk delete, get IDs from POST
          $ids = explode(',', $request->ids);
      } else {
          // Single item delete, get ID from URL
          $ids[] = $id;
      }

      foreach ($ids as $id) {
          $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

          if($data->disabled==0){
            $data->disabled=1;
            $data->save();
          }

          //$this->cleanup($dataType, $data);
      }

      $displayName = count($ids) > 1 ? $dataType->display_name_plural : $dataType->display_name_singular;

      $res = true;//$data->destroy($ids);
      $data = $res
          ? [
              'message'    => __('messages.successfully_deactivated')." {$displayName}",
              'alert-type' => 'success',
          ]
          : [
              'message'    => __('messages.deactivate_error')." {$displayName}",
              'alert-type' => 'error',
          ];

      if ($res) {
          event(new BreadDataDeleted($dataType, $data));
      }
      $countParametersUrl = count(explode('&', url()->previous()));
      if($countParametersUrl>1) {
          $parametersString = explode('?', url()->previous());
          preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
          $parameterString = "";
          for ($i = 0; $i < $countParametersUrl; $i++) {
              $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
          }
          if($dataType->slug!='specialties'){
              $searchAction =substr($dataType->slug, 0, -1);
          }
          else{
              $searchAction ="specialty";
          }
          $routeName = "{$searchAction}.search";
      }
      else{
          $previousUrl = explode('page=' , url()->previous());
          $routeName = "voyager.{$dataType->slug}.index";
          $parameterString= "page=";
          $parameterString.= $previousUrl['1'] ?? 1;
      }
      return redirect()->route($routeName, [$parameterString])->with($data);
  }
    public function activate(Request $request, $id)
  {

      $slug = $this->getSlug($request);

      $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

      // Check permission
      $this->authorize('delete', app($dataType->model_name));

      // Init array of IDs
      $ids = [];

      if (empty($id)) {
          // Bulk delete, get IDs from POST
          $ids = explode(',', $request->ids);
      } else {
          // Single item delete, get ID from URL
          $ids[] = $id;
      }

      foreach ($ids as $id) {
          $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

          if($data->disabled==1){
            $data->disabled=0;
            $data->save();
          }

          //$this->cleanup($dataType, $data);
      }

      $displayName = count($ids) > 1 ? $dataType->display_name_plural : $dataType->display_name_singular;

      $res = true;//$data->destroy($ids);
      $data = $res
          ? [

              'message'    => __('messages.successfully_activated')." {$displayName}",
              'alert-type' => 'success',
          ]
          : [
              'message'    => __('messages.activate_error')." {$displayName}",
              'alert-type' => 'error',
          ];

      if ($res) {
          event(new BreadDataDeleted($dataType, $data));
      }
      $countParametersUrl = count(explode('&', url()->previous()));
      if($countParametersUrl>1) {
          $parametersString = explode('?', url()->previous());
          preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
          $parameterString = "";
          for ($i = 0; $i < $countParametersUrl; $i++) {
              $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
          }
          if($dataType->slug!='specialties'){
              $searchAction =substr($dataType->slug, 0, -1);
          }
          else{
              $searchAction ="specialty";
          }
          $routeName = "{$searchAction}.search";
      }
      else{
          $previousUrl = explode('page=' , url()->previous());
          $routeName = "voyager.{$dataType->slug}.index";
          $parameterString= "page=";
          $parameterString.= $previousUrl['1'] ?? 1;
      }
      return redirect()->route($routeName , [$parameterString])->with($data);
  }
    public function activateadvertise(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'subscription-plans')->first();

        // Check permission
        $this->authorize('delete', app($dataType->model_name));

        // Init array of IDs
        $ids = [];

        if (empty($id)) {
            // Bulk delete, get IDs from POST
            $ids = explode(',', $request->ids);
        } else {
            // Single item delete, get ID from URL
            $ids[] = $id;
        }

        foreach ($ids as $id) {
            $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

            if($data->disabled==1){
                $data->disabled=0;
                $data->save();
            }

            //$this->cleanup($dataType, $data);
        }

        $displayName = count($ids) > 1 ? $dataType->display_name_plural : $dataType->display_name_singular;

        $res = true;//$data->destroy($ids);
        $data = $res
            ? [

                'message'    => __('messages.successfully_activated')." {$displayName}",
                'alert-type' => 'success',
            ]
            : [
                'message'    => __('messages.activate_error')." {$displayName}",
                'alert-type' => 'error',
            ];

        if ($res) {
            event(new BreadDataDeleted($dataType, $data));
        }

        return redirect()->route("voyager.subscription-plans.index")->with($data);

    }
    public function deactivateadvertise(Request $request, $id)
    {

        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'subscription-plans')->first();

        // Check permission
        $this->authorize('delete', app($dataType->model_name));

        // Init array of IDs
        $ids = [];

        if (empty($id)) {
            // Bulk delete, get IDs from POST
            $ids = explode(',', $request->ids);
        } else {
            // Single item delete, get ID from URL
            $ids[] = $id;
        }

        foreach ($ids as $id) {
            $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

            if($data->disabled==0){
                $data->disabled=1;
                $data->save();
            }

            //$this->cleanup($dataType, $data);
        }

        $displayName = count($ids) > 1 ? $dataType->display_name_plural : $dataType->display_name_singular;

        $res = true;//$data->destroy($ids);
        $data = $res
            ? [
                'message'    => __('messages.successfully_deactivated')." {$displayName}",
                'alert-type' => 'success',
            ]
            : [
                'message'    => __('messages.deactivate_error')." {$displayName}",
                'alert-type' => 'error',
            ];

        if ($res) {
            event(new BreadDataDeleted($dataType, $data));
        }

        return redirect()->route("voyager.subscription-plans.index")->with($data);
    }
    public function activatepatient(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Check permission
        $this->authorize('delete', app($dataType->model_name));

        // Init array of IDs
        $ids = [];

        if (empty($id)) {
            // Bulk delete, get IDs from POST
            $ids = explode(',', $request->ids);
        } else {
            // Single item delete, get ID from URL
            $ids[] = $id;
        }

        foreach ($ids as $id) {
            $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

            if($data->disabled==1){
                $data->disabled=0;
                $data->save();
            }

            //$this->cleanup($dataType, $data);
        }

        $displayName = count($ids) > 1 ? $dataType->display_name_plural : $dataType->display_name_singular;

        $res = true;//$data->destroy($ids);
        $data = $res
            ? [

                'message'    => __('messages.successfully_activated')." {$displayName}",
                'alert-type' => 'success',
            ]
            : [
                'message'    => __('messages.activate_error')." {$displayName}",
                'alert-type' => 'error',
            ];

        if ($res) {
            event(new BreadDataDeleted($dataType, $data));
        }
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "patient.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.patients.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName , [$parameterString])->with($data);

    }
    public function deactivatepatient(Request $request, $id)
    {

        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Check permission
        $this->authorize('delete', app($dataType->model_name));

        // Init array of IDs
        $ids = [];

        if (empty($id)) {
            // Bulk delete, get IDs from POST
            $ids = explode(',', $request->ids);
        } else {
            // Single item delete, get ID from URL
            $ids[] = $id;
        }

        foreach ($ids as $id) {
            $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

            if($data->disabled==0){
                $data->disabled=1;
                $data->save();
            }

            //$this->cleanup($dataType, $data);
        }

        $displayName = count($ids) > 1 ? $dataType->display_name_plural : $dataType->display_name_singular;

        $res = true;//$data->destroy($ids);
        $data = $res
            ? [
                'message'    => __('messages.successfully_deactivated')." {$displayName}",
                'alert-type' => 'success',
            ]
            : [
                'message'    => __('messages.deactivate_error')." {$displayName}",
                'alert-type' => 'error',
            ];

        if ($res) {
            event(new BreadDataDeleted($dataType, $data));
        }
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "patient.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.patients.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName ,[$parameterString])->with($data);
    }
    public function activatesecretary(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Check permission
        $this->authorize('delete', app($dataType->model_name));

        // Init array of IDs
        $ids = [];

        if (empty($id)) {
            // Bulk delete, get IDs from POST
            $ids = explode(',', $request->ids);
        } else {
            // Single item delete, get ID from URL
            $ids[] = $id;
        }

        foreach ($ids as $id) {
            $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

            if($data->disabled==1){
                $data->disabled=0;
                $data->save();
            }

            //$this->cleanup($dataType, $data);
        }

        $displayName = count($ids) > 1 ? $dataType->display_name_plural : $dataType->display_name_singular;

        $res = true;//$data->destroy($ids);
        $data = $res
            ? [

                'message'    => __('messages.successfully_activated')." {$displayName}",
                'alert-type' => 'success',
            ]
            : [
                'message'    => __('messages.activate_error')." {$displayName}",
                'alert-type' => 'error',
            ];

        if ($res) {
            event(new BreadDataDeleted($dataType, $data));
        }
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "secretary.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.secretaries.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName, [$parameterString])->with($data);

    }
    public function deactivatesecretary(Request $request, $id)
    {

        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Check permission
        $this->authorize('delete', app($dataType->model_name));

        // Init array of IDs
        $ids = [];

        if (empty($id)) {
            // Bulk delete, get IDs from POST
            $ids = explode(',', $request->ids);
        } else {
            // Single item delete, get ID from URL
            $ids[] = $id;
        }

        foreach ($ids as $id) {
            $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

            if($data->disabled==0){
                $data->disabled=1;
                $data->save();
            }

            //$this->cleanup($dataType, $data);
        }

        $displayName = count($ids) > 1 ? $dataType->display_name_plural : $dataType->display_name_singular;

        $res = true;//$data->destroy($ids);
        $data = $res
            ? [
                'message'    => __('messages.successfully_deactivated')." {$displayName}",
                'alert-type' => 'success',
            ]
            : [
                'message'    => __('messages.deactivate_error')." {$displayName}",
                'alert-type' => 'error',
            ];

        if ($res) {
            event(new BreadDataDeleted($dataType, $data));
        }
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "secretary.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.secretaries.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName , [$parameterString])->with($data);
    }
    public function activatemedical(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Check permission
        $this->authorize('delete', app($dataType->model_name));

        // Init array of IDs
        $ids = [];

        if (empty($id)) {
            // Bulk delete, get IDs from POST
            $ids = explode(',', $request->ids);
        } else {
            // Single item delete, get ID from URL
            $ids[] = $id;
        }

        foreach ($ids as $id) {
            $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

            if($data->disabled==1){
                $data->disabled=0;
                $data->save();
            }

            //$this->cleanup($dataType, $data);
        }

        $displayName = count($ids) > 1 ? $dataType->display_name_plural : $dataType->display_name_singular;

        $res = true;//$data->destroy($ids);
        $data = $res
            ? [

                'message'    => __('messages.successfully_activated')." {$displayName}",
                'alert-type' => 'success',
            ]
            : [
                'message'    => __('messages.activate_error')." {$displayName}",
                'alert-type' => 'error',
            ];

        if ($res) {
            event(new BreadDataDeleted($dataType, $data));
        }
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "medical.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.medical-providers.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName , [$parameterString])->with($data);

    }
    public function deactivatemedical(Request $request, $id)
    {

        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Check permission
        $this->authorize('delete', app($dataType->model_name));

        // Init array of IDs
        $ids = [];

        if (empty($id)) {
            // Bulk delete, get IDs from POST
            $ids = explode(',', $request->ids);
        } else {
            // Single item delete, get ID from URL
            $ids[] = $id;
        }

        foreach ($ids as $id) {
            $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

            if($data->disabled==0){
                $data->disabled=1;
                $data->save();
            }

            //$this->cleanup($dataType, $data);
        }

        $displayName = count($ids) > 1 ? $dataType->display_name_plural : $dataType->display_name_singular;

        $res = true;//$data->destroy($ids);
        $data = $res
            ? [
                'message'    => __('messages.successfully_deactivated')." {$displayName}",
                'alert-type' => 'success',
            ]
            : [
                'message'    => __('messages.deactivate_error')." {$displayName}",
                'alert-type' => 'error',
            ];

        if ($res) {
            event(new BreadDataDeleted($dataType, $data));
        }
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "medical.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.medical-providers.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName , [$parameterString])->with($data);
    }

}
