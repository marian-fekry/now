<?php

namespace App\Http\Controllers;

use App\Secretary;
use Illuminate\Http\Request;
use Validator;
use Auth;
use App\Doctor;
use App\MedicalProvider;
use App\MedicalProviderHasSpecialties;
use App\Specialty ;
use App\Service;
use App\PrivateReservation;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\MessageBag;
use App\Request as RequestModel ;
class MedicalProviderController extends Controller
{
  use OutPut;

  public function __construct()
  {
      $this->middleware('auth:api');
  }

  public function edithospital(Request $request , MessageBag $message_bag){
      $user=Auth::user();
      if(!$user->isSharedClinic() && !$user->isHospital() && !$user->isMedicalProvider()) {
          return OutPut::Response('',__('messages.auth_error'),401);
      }
      app()->setLocale($user->token()->user_lang);
    $valid=Validator::make($request->all(),[
      //profile data validation
      'name'=>'required_without_all:specialties,departementsecretary,doctors,name_en,email,brief,address,governerte_id,region_id,type|Filled|string',
      'name_en'=>'required_without_all:specialties,departementsecretary,doctors,email,brief,address,governerte_id,region_id,type|Filled|string',
      'email'=>'required_without_all:specialties,departementsecretary,doctors,name,name_en,brief,address,governerte_id,region_id,type|Filled|email|string',
      'brief'=>'required_without_all:specialties,departementsecretary,doctors,name,name_en,email,address,governerte_id,region_id,type|string|nullable',
      'address'=>'required_without_all:specialties,departementsecretary,doctors,name,name_en,email,brief,region_id,type|string|nullable',
      'governerte_id'=>'required|numeric',
       'region_id'=>'required|numeric',
      'type'=>'required_without_all:specialties,doctors,name,name_en,email,brief,governerte_id,address|string|nullable',
      // assign specialties
      'specialties'=>'required_without_all:users,departementsecretary,doctors,name,name_en,email,brief,address,governerte_id,region_id,type|array',
      'specialties.*.speciality_id'=>'Filled|numeric',

      'specialties.*.private_reservation_email'=>'email|string|nullable',

      'specialties.*.services'=>'array',
      'specialties.*.services.*.service_id'=>'required_with:specialties.*.services,specialties.*.services.*.service_price|Filled|numeric',
      'specialties.*.services.*.service_price'=>'required_with:specialties.*.services,specialties.*.services.*.id|Filled|numeric',


      // add doctors
      'doctors'=>'required_without_all:users,specialties,departementsecretary,name,name_en,email,brief,address,governerte_id,region_id,type|array',
      'doctors.*.doctor_name'=>'nullable|string',
      'doctors.*.doctor_name_en'=>'nullable|string',

      'doctors.*.doctor_email'=>'required_with:doctors.*.doctor_name,doctors.*.doctor_name_en,doctors.*.doctor_degree,doctors.*.doctor_speciality_id,doctors|Filled|email|string',
      'doctors.*.doctor_degree'=>'nullable|string',
      'doctors.*.doctor_speciality_id'=>'required_with:doctors.*.doctor_name,doctors.*.doctor_email,doctors.*.doctor_degree,doctors|nullable|numeric',


      'doctors.*.secretary_name'=>'required_with:doctors.*.secretary_email|nullable|string',
      'doctors.*.secretary_email'=>'required_with:doctors.*.secretary_name|nullable|E-Mail|string'

    ]);

    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }
    $errors = [];

    /////////logic of edit presents here//////////////////////////////////////////////////////////
    // edit medical provider name - email - brief - address
    if(null!==($request->input('email'))){
      $userData=\App\User::where('email',$request->input('email'))->first();
      if(null!==$userData){
        if(Auth::user()->id!=$userData->id){
          return OutPut::Response('',__('messages.emial_already_found'),403);
        }
      }

    }
    if(null!==($request->input('name'))||null!==($request->input('name_en'))||null!==($request->input('email'))||null!==($request->input('brief'))||null!==($request->input('address')) ||null!==($request->input('degree')) ||null!==($request->input('type'))){
      $medicalprovider=new MedicalProvider;
      $medicalproviderResponse=  $medicalprovider->editProvider(
        $request->input('name',''),$request->input('name_en',''),$request->input('email',''),$request->input('brief',''),
        $request->input('address',''),$request->input('governerte_id',''),$request->input('degree',''),
        $request->input('type',''),$request->input('specialties',array()),$user->id
      );
    }
      // assign specialties
      if(Auth::user()->hasPermission('assign_specialty') && Auth::user()->hasPermission('assign_service') ){
        if (null !== ($request->input('specialties'))&& sizeof($request->input('specialties'))>0) {
            $medicalprovider = MedicalProvider::where('user_id', $user->id)->first();

            foreach($request->input('specialties') as $specialty){
              if(!isset($specialty['speciality_id'])){
                continue;
              }

              if(isset($specialty['action'])){
                $specialnyAction=new Specialty;
                if($specialty['action']=='add'){
                  $A=$specialnyAction->addSpecialtyToProvider($specialty['speciality_id'],$medicalprovider->id);
                  //$privateReservation->addDepartementSecretary($private_reservation_email,$medicalprovider->id,$specialty['speciality_id']);
                  foreach ($specialty['services'] as $service) {
                    if(!isset($service['service_id'])){
                      continue;
                    }
                      $serviceAction=new Service;
                      $serviceAction->addServiceToSpecialty($service['service_id'],$specialty['speciality_id'],$medicalprovider->id,$service['service_price']);
                  }
                }else if($specialty['action']=='delete'){
                  $specialnyAction->deleteSpecialtyFromProvider($specialty['speciality_id'],$medicalprovider->id);
                }else{
                  // action not recognized
                }
              }else{
                //no action take on specialties, but service could be added
                foreach ($specialty['services'] as $service) {
                  if(!isset($service['service_id'])){
                    continue;
                  }
                  if(isset($service['action'])){
                    $serviceAction=new Service;
                    if($service['action']=='add'){
                      $serviceAction->addServiceToSpecialty($service['service_id'],$specialty['speciality_id'],$medicalprovider->id,$service['service_price']);
                    }else if($service['action']=='delete'){
                      $serviceAction->deleteServiceFromSpecialty($service['service_id'],$specialty['speciality_id'],$medicalprovider->id);
                    }else if($service['action']=='edit'){
                      $serviceAction->editServiceInSpecialty($service['service_id'],$specialty['speciality_id'],$medicalprovider->id);
                    }else{
                      // action not recognized
                    }
                  }else{
                    //no action take on  service
                  }
                }
              }

              $private_reservation_email=isset($specialty['private_reservation_email'])?$specialty['private_reservation_email']:NULL;
              $privateReservation=new PrivateReservation;
              if(isset($specialty['private_reservation_action'])) {
                if($specialty['private_reservation_action']=='add'&&isset($specialty['speciality_id'])&&!empty($specialty['speciality_id'])){
                  $privateReservationResponse=$privateReservation->addDepartementSecretary($private_reservation_email,$medicalprovider->id,$specialty['speciality_id']);
                  if($privateReservationResponse=='email_is_not_private_reservation'){$message_bag->add('private_reservation_email', __('messages.private_reservation_email_used_before' , ['private_reservation_email'=>$private_reservation_email])) ;}
                  if($privateReservationResponse=='already_linked_to_departement'){$message_bag->add('already_linked_to_departement', __('messages.already_linked_to_departement' , ['private_reservation_email'=>$private_reservation_email])) ;}
                }else if($specialty['private_reservation_action']=='delete'&&isset($specialty['speciality_id'])&&!empty($specialty['speciality_id'])) {
                  if(isset($specialty['private_reservation_id'])){$privateReservationResponse=$privateReservation->removeDepartementSecretary($specialty['private_reservation_id'],$medicalprovider->id,$specialty['speciality_id']);}
                }else if($specialty['private_reservation_action']=='edit'&&isset($specialty['speciality_id'])&&!empty($specialty['speciality_id'])){
                  $privateReservationResponse=$privateReservation->addDepartementSecretary($private_reservation_email,$medicalprovider->id,$specialty['speciality_id']);
                  if($privateReservationResponse=='email_is_not_private_reservation'){$message_bag->add('private_reservation_email', __('messages.private_reservation_email_used_before' , ['private_reservation_email'=>$private_reservation_email])) ;}
                  if($privateReservationResponse=='already_linked_to_departement'){$message_bag->add('already_linked_to_departement', __('messages.already_linked_to_departement'));}
                }else{
                  // do nothing
                }
              }

            }
        }
     }

    if(Auth::user()->hasPermission('add_doctors')){
      if(null!==($request->input('doctors'))&& sizeof($request->input('doctors'))>0){
        $doctorsData=$request->input('doctors');

        foreach($doctorsData AS $doctorData){

          if(isset($doctorData['action'])){
            $doctor=new Doctor;
            if($doctorData['action']=='add'){
              // adding secretary for the doctor called in the same function of addToMedicalProvider
              $secretaryName=isset($doctorData['secretary_name'])?$doctorData['secretary_name']:"";
              $secretaryEmail=isset($doctorData['secretary_email'])?$doctorData['secretary_email']:"";
              $secretary=array();
              if(!empty($secretaryName)&&!empty($secretaryEmail)){
                $secretary=array('name'=>$secretaryName,'email'=>$secretaryEmail);
              }

              $doctor_name_ar=isset($doctorData['doctor_name'])?$doctorData['doctor_name']:"";
              $doctor_name_en=isset($doctorData['doctor_name_en'])?$doctorData['doctor_name_en']:"";
              $doctorName=array('ar'=>$doctor_name_ar,'en'=>$doctor_name_en);
              $medicalprovider=MedicalProvider::where('user_id',Auth::user()->id)->first();


              $newUser=\App\User::where('email',$doctorData['doctor_email'])->first();
              $newDoctorSpeciality=0;
              if(null==$newUser){
                    $newDoctorSpeciality=$doctorData['doctor_speciality_id'];}
              else{
                  if($newUser->isDoctor() && !$newUser->isPrivateClinic()){
                    $newDoctorSpeciality=$newUser->doctor->speciality_id;
                  }

              }
              $medicalproviderSpecialties =  MedicalProviderHasSpecialties::where('medical_provider_id', $medicalprovider->id)->where("speciality_id",$newDoctorSpeciality)->get();
              if(null==$newUser||($newUser->isDoctor() && !$newUser->isPrivateClinic())){

                if(null==$newUser){
                  $doctorResponse=$doctor->addDoctorToMedicalProvider($doctorName,$doctorData['doctor_email'],$doctorData['doctor_degree_id'],$doctorData['doctor_speciality_id'],$secretary,$medicalprovider->id);

                }else{
                    if($newUser->verified==0){
                        $message_bag->add('doctor_email', __('messages.doctor_account_not_activated_yet' , ['doctor_email'=>$doctorData['doctor_email']])) ;
                    }
                  $DoctorInMedical=DB::table('doctor_has_medical_provider')->where("medical_provider_id",$medicalprovider->id)->where("doctor_id",$newUser->doctor->id)->get();
                  if($DoctorInMedical->isEmpty()){
                    if(null!=$medicalproviderSpecialties){
                      $doctorResponse=$doctor->addDoctorToMedicalProvider($doctorName,$doctorData['doctor_email'],$doctorData['doctor_degree_id'],$doctorData['doctor_speciality_id'],$secretary,$medicalprovider->id);
                    }else{
                      return OutPut::Response('',__('messages.doctor_specialty_not_found_in_mp'),403);
                    }
                  }else{
                    return OutPut::Response('',__('messages.doctor_found_before_in_mp'),403);
                  }
                }


              }else{
                //return OutPut::Response('',__('messages.try_add_non_doctor'),403);
                  $message_bag->add('doctor_email', __('messages.doctor_email_used_before' , ['doctor_email'=>$doctorData['doctor_email']])) ;
              }


            }else if ($doctorData['action']=='delete'){
              $doctorResponse=$doctor->removeDoctorFromMedicalProvider($doctorData['doctor_id'],$medicalprovider->id);
            }else if ($doctorData['action']=='edit'){
              $doctorResponse=$doctor->editDoctor($doctorData['doctor_id'],isset($doctorData['doctor_name'])?$doctorData['doctor_name']:"",$doctorData['doctor_email'],$doctorData['doctor_degree_id'],$doctorData['doctor_speciality_id']);
            }else{
                // no action needed
            }
          }
          if(isset($doctorData['secretary_action'])){
            $secretary=new Secretary;

            if($doctorData['secretary_action']=='add' && isset($doctorData['doctor_id'])&&!empty($doctorData['doctor_id'])){
              $secretaryResponse=$secretary->addToDoctor($doctorData['secretary_name'],$doctorData['secretary_email'],$doctorData['doctor_id']);
              if($secretaryResponse=='email_is_not_secretary'){$message_bag->add('email_is_not_secretary', __('messages.email_is_not_secretary' , ['secretary_email'=>$doctorData['secretary_email']])) ;}
              if($secretaryResponse=='already_linked_to_doctor'){$message_bag->add('already_linked_to_doctor', __('messages.already_linked_to_doctor' , ['secretary_email'=>$doctorData['secretary_email']])) ;}
            }else if($doctorData['secretary_action']=='delete' && isset($doctorData['doctor_id'])&&!empty($doctorData['doctor_id'])){
              $secretary->removeFromDoctor($doctorData['secretary_id']);
            }else if($doctorData['secretary_action']=='edit' && isset($doctorData['doctor_id'])&&!empty($doctorData['doctor_id'])){
              $secretaryResponse=$secretary->editSecretary($doctorData['secretary_name'],$doctorData['secretary_email'],$doctorData['secretary_id']);
              if($secretaryResponse=='email_is_not_secretary'){$message_bag->add('email_is_not_secretary', __('messages.email_is_not_secretary' , ['secretary_email'=>$doctorData['secretary_email']])) ;}
              if($secretaryResponse=='already_linked_to_doctor'){$message_bag->add('already_linked_to_doctor', __('messages.already_linked_to_doctor' , ['secretary_email'=>$doctorData['secretary_email']])) ;}
            }else{
              // no action needed
            }
          }


        }
      }
    }
    if(count($message_bag)>0){
        return OutPut::Response('',$message_bag,403);
    }
    return OutPut::Response('',__('messages.edit_successful'),200);
  }



  public function editclinic(Request $request){
      $user=Auth::user();
      app()->setLocale($user->token()->user_lang);
      if(!$user->isPrivateClinic() && !$user->isMedicalProvider()) {
          return OutPut::Response('',__('messages.auth_error'),401);
      }

    $valid=Validator::make($request->all(),[
      //profile data validation
      'name'=>'required_without_all:specialties,doctors,name_en,email,brief,address,governerte_id,region_id,degree,type|Filled|string',
        'name_en'=>'required_without_all:specialties,doctors,email,brief,address,governerte_id,region_id,degree,type|Filled|string',
      'email'=>'required_without_all:specialties,doctors,name,name_en,brief,address,governerte_id,region_id,degree,type|Filled|email|string',
      'brief'=>'required_without_all:specialties,doctors,name,name_en,email,address,governerte_id,region_id,degree,type|string|nullable',
      'address'=>'required_without_all:specialties,doctors,name,name_en,email,brief,governerte_id,region_id,degree,type|string|nullable',
      'governerte_id'=>'required_without_all:specialties,doctors,name,name_en,email,brief,governerte_id,region_id,degree,type|numeric',
       'region_id'=>'required_without_all:specialties,doctors,name,name_en,email,brief,governerte_id,region_id,degree,type|numeric',
      'degree'=>'required_without_all:specialties,doctors,name,name_en,email,brief,governerte_id,region_id,type|numeric|nullable',
      'type'=>'required_without_all:specialties,doctors,name,name_en,email,brief,governerte_id,region_id,address|string|nullable',

      // assign specialties
//      'specialties'=>'required_without_all:users,doctors,name,name_en,email,brief,address,governerte_id,type|array|Filled',
        'specialties'=>'required_if:type,private_clinic|array|Filled',
      'specialties.*.speciality_id'=>'Filled|numeric',

      'specialties.*.services'=>'array',
      'specialties.*.services.*.service_id'=>'required_with:specialties.*.services,specialties.*.services.*.service_price|Filled|numeric',
      'specialties.*.services.*.service_price'=>'required_with:specialties.*.services,specialties.*.services.*.id|Filled|numeric',


      'doctors'=>'required_without_all:users,specialties,service,name,name_en,email,brief,address,governerte_id,region_id|array|Filled',
      'doctors.secretary_name'=>'required_with:doctors.secretary_email|Filled|string',
      'doctors.secretary_email'=>'required_with:doctors.secretary_name|Filled|E-Mail|string'

    ]);

    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }

    /////////logic of edit presents here//////////////////////////////////////////////////////////
    // edit medical provider name - email - brief - address
    if(null!==($request->input('email'))){
      $userData=\App\User::where('email',$request->input('email'))->first();
      if(null!==$userData){
        if(Auth::user()->id!=$userData->id){
          return OutPut::Response('',__('messages.emial_already_found'),403);
        }
      }

    }
    if(null!==($request->input('name'))||null!==($request->input('name_en'))||null!==($request->input('email'))||null!==($request->input('brief'))||null!==($request->input('address')) ||null!==($request->input('degree')) ||null!==($request->input('type'))){
      $medicalprovider=new MedicalProvider;
      $medicalproviderResponse=  $medicalprovider->editProvider(
        $request->input('name',''),$request->input('name_en',''),$request->input('email',''),$request->input('brief',''),
        $request->input('address',''),$request->input('governerte_id',''),$request->input('degree',''),
        $request->input('type',''),$request->input('specialties',array()),$user->id
      );
    }
    // assign specialties
      if(Auth::user()->hasPermission('assign_specialty') && Auth::user()->hasPermission('assign_service') ){
      if (null !== ($request->input('specialties'))) {
          $medicalprovider = MedicalProvider::where('user_id', $user->id)->first();

          foreach($request->input('specialties') as $specialty){
            if(!isset($specialty['speciality_id'])){
              continue;
            }


            if(isset($specialty['action'])){
              $specialnyAction=new Specialty;
              if($specialty['action']=='add'){

                $specialnyAction->addSpecialtyToProvider($specialty['speciality_id'],$medicalprovider->id);
                foreach ($specialty['services'] as $service) {
                  if(!isset($service['service_id'])){
                    continue;
                  }
                    $serviceAction=new Service;
                    $serviceAction->addServiceToSpecialty($service['service_id'],$specialty['speciality_id'],$medicalprovider->id,$service['service_price']);
                }
              }else if($specialty['action']=='delete'){
                $specialnyAction->deleteSpecialtyFromProvider($specialty['speciality_id'],$medicalprovider->id);
              }else{
                // action not recognized
              }
            }else{
              //no action take on specialties, but service could be added
              foreach ($specialty['services'] as $service) {
                if(!isset($service['service_id'])){
                  continue;
                }
                if(isset($service['action'])){
                  $serviceAction=new Service;
                  if($service['action']=='add'){
                    $serviceAction->addServiceToSpecialty($service['service_id'],$specialty['speciality_id'],$medicalprovider->id,$service['service_price']);
                  }else if($service['action']=='delete'){
                    $serviceAction->deleteServiceFromSpecialty($service['service_id'],$specialty['speciality_id'],$medicalprovider->id);
                  }else if($service['action']=='edit'){
                    $serviceAction->editServiceInSpecialty($service['service_id'],$specialty['speciality_id'],$medicalprovider->id);
                  }else{
                    // action not recognized
                  }
                }else{
                  //no action take on  service
                }
              }
            }
          }
      }
   }

    // add doctor (with the option to add secretary to the doctor)
    // in case of private clinic check if he has doctor account before or //
    if($request->input('type')=='private_clinic'){
      $doctor=Doctor::where('user_id',$user->id)->first();
      if(empty($doctor)){
        $doctor=new Doctor;
        $specialties=$request->input('specialties');
        $specialty=(isset($specialties[0]['speciality_id']))?$specialties[0]['speciality_id']:0;
        $doctorName=array('ar'=>$request->input('name'),'en'=>$request->input('name_en'));
        $doctorResponse=$doctor->addDoctorToMedicalProvider($doctorName,$user->email,$request->input('degree',''),$specialty,array(),$user->id);
      }
    }

    if(Auth::user()->hasPermission('add_secretaries')){

      if(null!==($request->input('doctors.secretary_name')) && null!==($request->input('doctors.secretary_action'))){
          $secretary=new Secretary;

          $secretaryData=$request->input('doctors');

          if($secretaryData['secretary_action']=='add' && isset($doctor->id)&&!empty($doctor->id)){
            $secretary->addToDoctor($secretaryData['secretary_name'],$secretaryData['secretary_email'],$doctor->id);
          }else if($secretaryData['secretary_action']=='delete' && isset($doctor->id)&&!empty($doctor->id)){
            $secretary->removeFromDoctor($secretaryData['secretary_id']);
          }else if($secretaryData['secretary_action']=='edit' && isset($doctor->id)&&!empty($doctor->id)){
            $secretary->editSecretary($secretaryData['secretary_name'],$secretaryData['secretary_email'],$secretaryData['secretary_id']);
          }else{
            // no action needed
          }


        }

   }
    return OutPut::Response('',__('messages.edit_successful'),200);
  }

  public function fetchMedicalProvider()
    {
        $user=Auth::user();


        if(!$user->id) {
            return OutPut::Response('','couldn\'t found you request',505);
        }
        if( !$user->isPrivateClinic() && !$user->isHospital() && !$user->isSharedClinic()&& !$user->isMedicalProvider()){
            return OutPut::Response('','couldn\'t found you request',505);
        }
        $medicalprovider=MedicalProvider::where('user_id', $user->id)->first();
        if(Auth::user()->token()->user_lang=='ar') {
           $name = $user->name;
            $governerateName = isset($medicalprovider->governrate->name_ar)?$medicalprovider->governrate->name_ar:"";
            $brief = $medicalprovider->brief;
            $address = $medicalprovider->address;
            $medicalproviderRegion=$medicalprovider->governrate->region->name_ar ?? '';
        }
        else {
            $name =$user->name;// $medicalprovider->name_en;
            $governerateName = isset($medicalprovider->governrate->name_en)?$medicalprovider->governrate->name_en:"";
            $brief = $medicalprovider->brief_en;
            $address = $medicalprovider->address_en;
            $medicalproviderRegion=$medicalprovider->governrate->region->name_en ?? '' ;
        }
        $medicalproviderSpecialties = [];
        $specialties = MedicalProviderHasSpecialties::where('medical_provider_id', $medicalprovider->id)->get();
        for ($i=0 ; $i<count($specialties) ;$i++)
        {
            if(Auth::user()->token()->user_lang=='ar') {
                $specialty_name = $specialties[$i]->specialty->name_ar;
            }
            else {
                $specialty_name = $specialties[$i]->specialty->name_en;
            }
            $servicesArray =[] ;
            for ($s=0 ; $s<count($specialties[$i]->services) ;$s++) {
                if(Auth::user()->token()->user_lang=='ar') {
                  $serviceName = $specialties[$i]->services[$s]['name_ar'];
                }
                else {
                    $serviceName = $specialties[$i]->services[$s]['name_en'];
                }
                $medicalproviderServices = ['service_id'=>$specialties[$i]->services[$s]['id']  , 'service_name'=>$serviceName , 'service_price'=>$specialties[$i]->services[$s]['pivot']['price']];
                array_push($servicesArray , $medicalproviderServices);
            }
            $specialtieArray = [
              'speciality_id'=>$specialties[$i]->speciality_id ,
              'specialty_name'=>$specialty_name ,
              'private_reservation_id'=>$specialties[$i]->departement_secretary_id ,
              'private_reservation_name'=>$specialties[$i]->privateReservation['user']['name'] ,
              'private_reservation_email'=>$specialties[$i]->privateReservation['user']['email'] ,
              'has_private_reservation'=>($specialties[$i]->departement_secretary_id>0)?true:false ,
              "services"=>$servicesArray
            ];
            array_push($medicalproviderSpecialties , $specialtieArray);
        }
        $medicalproviderDoctorArray = [] ;

        foreach ($medicalprovider->doctors AS $medicalproviderdoctor) {

            $jobTitle=\App\Jobtitle::where('id',$medicalproviderdoctor->jobtitle)->first();
            $degree='';
            if(Auth::user()->token()->user_lang=='ar') {
             $doctorSpecialty = $medicalproviderdoctor['speciality']['name_ar'];
             $degree=isset($jobTitle->name_ar)?$jobTitle->name_ar:'';
            }
            else {

                $doctorSpecialty = $medicalproviderdoctor['speciality']['name_en'];
                $degree=isset($jobTitle->name_en)?$jobTitle->name_en:'';
            }
            $doctorName = $medicalproviderdoctor['user']['fullname'];
            $doctorNameEn = $medicalproviderdoctor['name_en'];
            $Usr=\App\User::where('id',$medicalproviderdoctor['user_id'])->first();
            if(null!==$Usr){
              $doctorArray = [
                'doctor_id'=>$medicalproviderdoctor['id'] ,
                'doctor_name'=>$doctorName ,
                'doctor_name_en'=>$doctorNameEn ,
                'doctor_degree'=> $degree ,
                'doctor_degree_id'=>$medicalproviderdoctor->jobtitle,
                'doctor_email'=>$Usr->email,
                'doctor_specialty_name'=> $doctorSpecialty,
                'doctor_speciality_id'=> $medicalproviderdoctor['speciality']['id'],
                'secretary_id'=>$medicalproviderdoctor['secretary']['id'] ,
                'secretary_name'=>$medicalproviderdoctor['secretary']['user']['fullname'] ,
                'secretary_email'=>$medicalproviderdoctor['secretary']['user']['email'],
                'has_secretary'=>($medicalproviderdoctor['secretary']['id']>0)?true:false ,
              ];
              array_push($medicalproviderDoctorArray , $doctorArray);
            }
        }
        return OutPut::Response([
            "name"=> $name,
            "type"=> $medicalprovider->type,
            "governrate_id"=>  $medicalprovider->governrate_id,
            "governerate_name"=>  $governerateName,
            "region_id"=>  $medicalprovider->governrate->region->id ?? '',
            "region_name"=>  $medicalproviderRegion,
            "brief"=>  $brief,
            "address"=>  $address,
            "latitude"=>  $medicalprovider->latitude,
            "longitude"=>  $medicalprovider->longitude,
            "specialties"=> $medicalproviderSpecialties ,
            "doctors"=> $medicalproviderDoctorArray,
        ],'',200);
    }

/////////////////////////////////////////////////////////////////////////////////////////////

  /*,
public function edit(Request $request){
    $userId=Auth::user()->id;
    if(!$userId) {
        return OutPut::Response('','couldn\'t found you request',505);
    }
    $valid=Validator::make($request->all(),[
        'name'=>'required|Filled|string',
        'email'=>'required|E-Mail|Filled|string',
    ]);
    if($valid->fails()){
        return OutPut::Response('',$valid->Errors(),403);
    }
    $user=User::find($userId);
    $user->name=$request->name;
    $user->email=$request->email;
    $user->medicalprovider->brief =  $request->brief ;
    $user->medicalprovider->brief =  $request->address ;
    if($user->save() && $user->medicalprovider->save()){
        return OutPut::Response('','information edit successfully',200);
    }else{
        return OutPut::Response('',"Problem while editing",403);
    }
}
*/

    public function fetchMedicalProviderInfo(Request $request )
    {
        $user=Auth::user();

        if(!$user->id) {
            return OutPut::Response('','couldn\'t found you request',505);
        }
        $valid=Validator::make($request->all(),[
            'medical_id'=>'required|Filled|numeric',
            'speciality_id'=>'required|Filled|numeric',
        ]);

        if($valid->fails()){
            return OutPut::Response('',$valid->Errors(),403);
        }

        // setting the variables
        $medicalId = $request->input('medical_id',0);
        $specialityId = $request->input('speciality_id',0);

        $medicalProvider = new MedicalProvider();
        $medicalProviderInfo = $medicalProvider->medicalProviderInfo($medicalId , $specialityId);

        return OutPut::Response($medicalProviderInfo,'',200);
    }

    public function setLoction(Request $request)
    {
        $user=Auth::user();
        app()->setLocale($user->token()->user_lang);
        if(!$user->id) {
            return OutPut::Response('','couldn\'t found you request',505);
        }
        if(!$user->isSharedClinic() && !$user->isHospital() && !$user->isMedicalProvider() && !$user->isPrivateReservation() && !$user->isPrivateClinic()) {
            return OutPut::Response('',__('messages.auth_error'),401);
        }
        $valid=Validator::make($request->all(),[
            'latitude'=>'required|Filled|string',
            'longitude'=>'required|Filled|string',
        ]);
        if($valid->fails()){
            return OutPut::Response('',$valid->Errors(),403);
        }
        $medical = New MedicalProvider();
        $medical->updateWhereId(['latitude'=>$request->latitude , 'longitude'=>$request->longitude],$user->medicalprovider->id);
        return OutPut::Response('',__('messages.edit_successful'),200);
    }

    public function getLoction(Request $request)
    {
        $user=Auth::user();
        app()->setLocale($user->token()->user_lang);
        if(!$user->id) {
            return OutPut::Response('','couldn\'t found you request',505);
        }
        $valid=Validator::make($request->all(),[
            'medical_id'=>'required|Filled|numeric',
        ]);
        if($valid->fails()){
            return OutPut::Response('',$valid->Errors(),403);
        }
        $medical = MedicalProvider::find( $request->medical_id);
        $respone =  ['latitude'=>$medical->latitude , 'longitude'=>$medical->longitude];
        return OutPut::Response($respone,'',200);

    }

    public function apiDashboard(){
        $user=Auth::user();
        if(!$user->isPrivateClinic() && !$user->isSharedClinic() && !$user->isHospital() && !$user->isMedicalProvider()) {
            return OutPut::Response('',__('messages.auth_error'),401);
        }
        $medicalModel = new RequestModel();
        $currentRequestscount = $medicalModel->currentRequestCount('medical_provider_id' , $user->medicalprovider->id );
        $oldRequestscount = $medicalModel->oldRequestCount('medical_provider_id' , $user->medicalprovider->id );
        $pendingRequestsCount=$medicalModel->pendingRequestCount('medical_provider_id' ,$user->medicalprovider->id ,  'Request');
        $waitingRequestsCount=$medicalModel->pendingRequestCount('medical_provider_id' ,$user->medicalprovider->id , 'Approve');
        return OutPut::Response([
            "current_requests_count"=> $currentRequestscount,
            "old_requests_count"=> $oldRequestscount,
            "pending_requests_count"=> $pendingRequestsCount,
            'waiting_requests_count'=>$waitingRequestsCount,
        ],'',200);

    }

    public function pendingRequests (){
        $user=Auth::user();
        if(!$user->isPrivateClinic() && !$user->isSharedClinic() && !$user->isHospital() && !$user->isMedicalProvider()) {
            return OutPut::Response('',__('messages.auth_error'),401);
        }
        $medicalModel = new RequestModel();
        $pendingRequests=$medicalModel->pendingRequests('medical_provider_id' , $user->medicalprovider->id ,$user ,'Request');
        return OutPut::Response($pendingRequests,'',200);

    }

}
