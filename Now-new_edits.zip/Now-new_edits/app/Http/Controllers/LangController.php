<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
use App;
class LangController extends Controller
{
    use OutPut;

  public function __construct()
  {
      $this->middleware('auth:api');
  }
  public function setLang($local){
      $user=new User;
      if($local=='ar'){
          $user->setLangByToken(Auth::user()->id,'ar' ,Auth::user()->token()->id);
          $user->setLang(Auth::user(),'ar');
          App::setLocale('ar');
      }else{
          $user->setLangByToken(Auth::user()->id,'en' ,Auth::user()->token()->id);
          $user->setLang(Auth::user(),'en');
          App::setLocale('en');
      }
      return OutPut::Response('',__('messages.lang_successful_change'),200);
  }
}
