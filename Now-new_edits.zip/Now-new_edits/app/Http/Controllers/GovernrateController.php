<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Governrate;
use Illuminate\Support\Facades\Auth;
class GovernrateController extends Controller
{
    //
    use OutPut;
    public function __construct()
    {
        $this->middleware('auth:api')->except(['index']);
    }

    public function index(Request $request)
    {
            $governrate=new Governrate();
           $governrates = $governrate->index($request->id , $request->lang);
            return OutPut::Response($governrates,'',200);
    }
}
