<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\Login;
use App ;
use Illuminate\Support\Facades\Auth;
use Validator;
use Hash;
use App\User;
use App\Patient;
use App\MedicalProvider;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmailVerification as EmailVerification ;
class authApiController extends Controller
{
  use OutPut;
  use SendsPasswordResetEmails;
  public function register(Request $request){
      if(!empty($request->user_lang)) {
          app()->setLocale($request->user_lang);
      }
      else {
          app()->setLocale('ar');
      }
      $valid=Validator::make($request->all(),[
      'email'=>'required|Unique:users|Filled|email|string',
      'name'=>'required|Filled|string',
      'password'=>'required|Confirmed|Filled|string|min:6',
      'fullNameAr'=>'required|Filled|string',
      'fullNameEn'=>'string|nullable',
      'type'=>'required|Filled|string',
       'user_lang'=>'Filled|string',
    ]);
    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }

     $user=new User();
      $response=$user->createUser($request->input());
    if($request->type=='patient'){
      $patient=new Patient();
      $patientResponse=$patient->createPatient($response->id);
      if(!$patientResponse){
        return OutPut::Response('',__('messages.patient_create_error'),505);
      }
    }else if($request->type=='medical_provider'){
      $medicalprovider=new MedicalProvider();
      $medicalproviderResponse=$medicalprovider->createProvider($response->id);
      if(!$medicalproviderResponse){
        return OutPut::Response('',__('messages.provider_create_error'),505);
      }
    }else{
      return OutPut::Response('',__('messages.unknown_user'),403);
    }

    $userRole='';
    if($user->isPatient()){
       $userRole='patient';
     }else if($user->isDoctor()){
       $userRole='doctor';
     }else if($user->isSecretary()){
       $userRole='secretary';
     }else if($user->isPrivateReservation()){
       $userRole='private_reservation';
     }else if($user->isHospital()){
       $userRole='hospital';
     }else if($user->isSharedClinic()){
       $userRole='shared_clinic';
     }else if($user->isPrivateClinic()){
       $userRole='private_clinic';
     }else if($user->isMedicalProvider()){
       $userRole='medical_provider';
     }
    Mail::to($response)->send(new EmailVerification($response->token , $response->email));


    return OutPut::Response('',__('messages.register_successful'),200);
    return OutPut::Response($response,'',200);
  }

  public function login(Request $request){
      if(!empty($request->user_lang )) {
          app()->setLocale($request->user_lang);
      }
      else {
          app()->setLocale('ar');
      }
      $valid=Validator::make($request->all(),[
        'email'=>'required|Filled|email|string',
        'password'=>'required|Filled|string|min:6',
        "pushtoken"=>'required|Filled|string',
        "deviceid"=>'required|Filled|string',
        "user_time_zone"=>'Filled|string',
        "user_lang"=>'Filled|string',
      ]);
      if($valid->fails()){
        return OutPut::Response('',$valid->Errors(),403);
      }
      if(Auth::attempt(['email'=>$request->email,'password'=>$request->password,'disabled'=>0])){
  			$user=Auth::user();
  			if(!empty($request->user_time_zone )) {
                $user->user_time_zone =$request->user_time_zone;
                $user->save();
            }
        // set the user current Language
        //App::setlocale($user->lang);

        $pushtoken=new \App\Pushtoken;
        $pushtoken->addtoken($user->id,$request->pushtoken,$request->deviceid);
          if(!empty($user->avatar)){
              $imagePath = url('/').'/storage/'.$user->avatar ;
          }
          else{
              $imagePath = url('/').'/storage/users/default.png' ;
          }

        $userRole='';
        if($user->isPatient()){
           $userRole='patient';
         }else if($user->isDoctor()){
           $userRole='doctor';
         }else if($user->isSecretary()){
           $userRole='secretary';
         }else if($user->isPrivateReservation()){
           $userRole='private_reservation';
         }else if($user->isHospital()){
           $userRole='hospital';
         }else if($user->isSharedClinic()){
           $userRole='shared_clinic';
         }else if($user->isPrivateClinic()){
           $userRole='private_clinic';
         }else if($user->isMedicalProvider()){
           $userRole='medical_provider';
         }
         if($user->verified==1){
           if($userRole=='doctor'){
             $doctor=\App\Doctor::where('user_id',$user->id)->with('speciality')->with('jobTitle')->first();
             $doctorspecialty='';
             $doctorjobtitle='';

             if(null!==$doctor){
               if($doctor->speciality){$doctorspecialty=($user->lang=='ar')?$doctor->speciality->name_ar:$doctor->speciality->name_en;}
               if($doctor->jobTitle){$doctorjobtitle=($user->lang=='ar')?$doctor->jobTitle->name_ar:$doctor->jobTitle->name_en;}
             }


             return OutPut::Response([
               "token"=>$user->createToken('')->accessToken,
               "name"=> $user->fullname,
               "name_en"=> $user->fullname_en,
               "email"=> $user->email,
                "email"=> $user->email,
               "doctorspecialty"=>  $doctorspecialty,
               "doctorjobtitle"=>  $doctorjobtitle,
               "lang"=>  $user->lang,
               "image"=>$imagePath,
               "id"=> $user->id,
               "type"=>$userRole,
              "notifications"=>$user->notifications ],'',200);
           }else if($userRole=='private_clinic'){
             $doctor=\App\Doctor::where('user_id',$user->id)->with('jobTitle')->first();

             $doctorjobtitle='';
             if(null!==$doctor){
               $doctorjobtitle=($doctor->jobTitle!=null)?(($user->lang=='ar')?$doctor->jobTitle->name_ar:$doctor->jobTitle->name_en):"";
             }

             return OutPut::Response([
               "token"=>$user->createToken('')->accessToken,
               "name"=> $user->fullname,
                "name_en"=> $user->fullname_en,
               "email"=> $user->email,
               "birthdate"=>  $user->birthdate,
               "gender"=>  $user->gender,
               "mobile"=>  $user->mobile,
               "lang"=>  $user->lang,
               "image"=>$imagePath,
               "id"=> $user->id,
               "doctorjobtitle"=>  $doctorjobtitle,
               "type"=>$userRole,
                "notifications"=>$user->notifications ],'',200);


           }
           else if($userRole=='hospital' || $userRole=='shared_clinic' || $userRole=='medical_provider') {
               return OutPut::Response([
                   "token"=>$user->createToken('')->accessToken,
                   "name"=> $user->fullname,
                   "name_en"=> $user->fullname_en,
                   "email"=> $user->email,
                   "birthdate"=>  $user->birthdate,
                   "gender"=>  $user->gender,
                   "mobile"=>  $user->mobile,
                   "lang"=>  $user->lang,
                   "image"=>$imagePath,
                   "id"=> $user->id,
                   "type"=>$userRole,
                   "notifications"=>$user->notifications ],'',200);
           }
           else{
             return OutPut::Response([
               "token"=>$user->createToken('')->accessToken,
               "name"=> $user->name,
               "email"=> $user->email,
               "birthdate"=>  $user->birthdate,
               "gender"=>  $user->gender,
               "mobile"=>  $user->mobile,
               "lang"=>  $user->lang,
               "image"=>$imagePath,
               "id"=> $user->id,
               "type"=>$userRole,
                "notifications"=>$user->notifications ],'',200);
           }

         }else{
           return OutPut::Response('',__('messages.verify_account'),450);
         }

  		}else{
        return OutPut::Response('',__('messages.login_error'),403);
  		}
      return;

  }
  public function resetpassword(Request $request){
      app()->setLocale(Auth::user()->token()->user_lang);
    $valid=Validator::make($request->all(),[
      'password'=>'required|Filled|string|min:6',
      'newPassword'=>'required|Confirmed|Filled|string|min:6',
    ]);
    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }
    $userId=Auth::user()->id;
    $user=new User();
    $oldPassword=$request->input("password");


    if(!Hash::check($oldPassword,Auth::user()->password)){
      return OutPut::Response('',__('messages.password_change_error'),403);
    }
    $saveNewPassword=$user->resetPassword($request->newPassword,$userId);
    // if resetPassword function return true, them new password saved successfully
    if($saveNewPassword){
      // revoke the old tokens of this user
      $currentToken=$request->user()->token()->id;
      $tokens=$request->user()->tokens;
      foreach($tokens as $token){
        // delete all except the current one
        if($token->id==$currentToken){continue;}
        $token->delete();
      }


      return OutPut::Response('',__('messages.password_change_successful'),200);
    }else{
      return OutPut::Response('',__('messages.password_change_error'),403);
    }
  }

  public function logout(Request $request){
    if(Auth::check()){
        $valid=Validator::make($request->all(),[
            'device_id'=>'required|Filled|string',
        ]);
        if($valid->fails()){
            return OutPut::Response('',$valid->Errors(),403);
        }
      $currentToken=$request->user()->token()->id;
      $token=Auth::user()->tokens->find($currentToken);
      $token->delete();
        $user=Auth::user();
       $pushToken=\App\Pushtoken::where('user_id',$user->id)->where('device_id',$request->device_id)->first();
       if($pushToken) {
           $pushToken->token='';
           $pushToken->save();
       }

      return OutPut::Response('','',200);
    }
    return OutPut::Response('','',403);
  }
// send mail to user with link to form where he can enter his new one
  public function forgetpassword(Request $request){
      if(!empty($request->user_lang )) {
          app()->setLocale($request->user_lang);
      }
      else {
          app()->setLocale('ar');
      }
      $valid=Validator::make($request->all(),[
        'email'=>'required|Filled|email|string',
          'user_lang'=>'Filled|string',
      ]);
      if($valid->fails()){
        return OutPut::Response('',$valid->Errors(),403);
      }
      $userCheck = User::where('email', $request->email)->first();
      if(!$userCheck) {
          return OutPut::Response('',__('messages.email_not_registered_before'),403);
      }
      if($userCheck->verified==0) {
          return OutPut::Response('',__('messages.verify_account'),403);
      }
      if($userCheck->disabled==1 || $userCheck->deleted_at!=Null) {
          return OutPut::Response('',__('messages.sending_reset_mail_error'),403);
      }

        $response = $this->broker()->sendResetLink($request->only('email'));
        if(Password::RESET_LINK_SENT){
          return OutPut::Response('',__('messages.forget_password_email_successful'),200);
        }else{
          return OutPut::Response('',__('messages.sending_reset_mail_error'),403);
        }


  }

  function resendVerifiedEmail(Request $request)
  {
      if(!empty($request->user_lang )) {
          app()->setLocale($request->user_lang);
      }
      else {
          app()->setLocale('ar');
      }
      $valid=Validator::make($request->all(),[
          'email'=>'required|Filled|email|string',
          'user_lang'=>'Filled|string',
      ]);
      if($valid->fails()){
          return OutPut::Response('',$valid->Errors(),403);
      }

    $user = new User ();
      $userExists = $user->getUserByEmail($request->email);
     $userVerified =  $user->checkUserverification($userExists->token);
      if(!$userExists) {
          return OutPut::Response('',__('messages.worng_eamil'),403);
      }
      if(($userVerified == 1)) {
          return OutPut::Response('',__('messages.already_verified'),403);
      }
      else {
          Mail::to($userExists)->send(new EmailVerification($userExists->token ));
          return OutPut::Response('',__('messages.review_mail'),200);
      }
  }
}
