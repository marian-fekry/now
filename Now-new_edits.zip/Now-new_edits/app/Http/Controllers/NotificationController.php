<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Notification;
use Validator;
use Auth;
use App\User;
use App\MedicalProvider;
class NotificationController extends Controller
{
  use OutPut;

  public function __construct()
  {
      $this->middleware('auth:api');
  }

  /*
  in case of doctor - patient - medical provider you will get your notifications
  in case of secretary - departement secretary you will get notifications of the related medical provider
  */
  public function getnotifiactions(Request $request){
    $valid=Validator::make($request->all(),[
      'page'=>'numeric',
    ]);
    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }
    $user=Auth::user();
    $notifications=new Notification;
    return OutPut::Response($notifications->getnotifications($user),'',200);
  }
  /*
  mark notification as read
  */
  public function readnotifiactions(){
    $user=Auth::user();
    $notification=new Notification;
    return OutPut::Response('',$notification->markAsRead(Auth::user()->id),200);
  }
}
