<?php

namespace App\Http\Controllers;


class AuthController extends \TCG\Voyager\Http\Controllers\VoyagerAuthController
{
    protected function credentials(\Illuminate\Http\Request $request)
    {
        //return $request->only($this->username(), 'password');
        return ['email' => $request->{$this->username()}, 'password' => $request->password, 'disabled' => 0];
    }

}
