<?php

namespace App\Http\Controllers;

use App\Doctor;
use Illuminate\Http\Request;
use Validator;
use Auth;
use App\MedicalProvider ;
use App\Request as RequestModel ;
class DoctorController extends Controller
{
  use OutPut;

  public function __construct()
  {
      $this->middleware('auth:api');
  }

  public function edit(Request $request){
    // patient can edit his name-email-mobile-birthdate-gender
      $user=Auth::user();
      if(!$user->isDoctor()) {
          return OutPut::Response('',__('messages.auth_error'),401);
      }
      app()->setLocale($user->token()->user_lang);
    $valid=Validator::make($request->all(),[
      'email'=>'required_without_all:name,name_en,specialty,jobtitle|Unique:users|email|string',
      'name'=>'required_without_all:name_en,email,specialty,jobtitle|string',
        'name_en'=>'required_without_all:email,name,specialty,jobtitle|string',
      'specialty'=>'required_without_all:email,name,name_en,jobtitle|numeric',
      'jobtitle'=>'required_without_all:email,name,name_en,specialty|numeric',
    ]
        );
    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }


    $email=$request->input('email','');
    $name=$request->input('name','');
    $specialty=$request->input('specialty','');
    $jobtitle=$request->input('jobtitle','');
      $name_en=$request->input('name_en','');

    $user=\App\User::find($user->id);
    if(!empty($name) ||!empty($email) || !empty($name_en)){
      if(!empty($name)){$user->fullname=$name;}
      if(!empty($email)){$user->email=$email;}
        if(!empty($name_en)){$user->fullname_en=$name_en;}
      $user->save();
    }
    if(!empty($specialty) ||!empty($jobtitle) || !empty($name_en)){
      $doctor=\App\Doctor::where('user_id',$user->id)->first();
      if(!empty($specialty)){$doctor->speciality_id=$specialty;}
      if(!empty($jobtitle)){$doctor->jobtitle=$jobtitle;}
        if(!empty($name_en)){$doctor->name_en=$name_en;}
      $doctor->save();
    }


    return OutPut::Response('',__('messages.update_successful'),200);
  }

  public function search(Request $request){
    if(Auth::user()->hasPermission('browse_doctors')){
        $user=Auth::user();
       app()->setLocale($user->token()->user_lang);
        $lang = Auth::user()->token()->user_lang;
      $valid=Validator::make($request->all(),[
          'doctor_name'=>'Filled|string',
          'medical_name'=>'Filled|string',
        'degree'=>'Filled|numeric',
        'region'=>'Filled|numeric',
        'governrate'=>'Filled|numeric',
          'specialty'=>'Filled|numeric',
          'service' => 'Filled|numeric',
        'min_price'=>'required_with:max_price|Filled|numeric',
        'max_price'=>'required_with:min_price|Filled|numeric',
          'request_date'=>'required|Filled|date|date_format:Y-m-d',
          'request_time'=>'required|date_format:H:i:s',

//         'doctor_name'=>'required_without_all:specialty,degree,region,governrate,service,min_price,max_price|Filled|numeric',
//         'degree'=>'required_without_all:doctor_name,specialty,region,governrate,service,min_price,max_price|Filled|numeric',
//         'region'=>'required_without_all:doctor_name,specialty,degree,governrate,service,min_price,max_price|Filled|numeric',
//         'governrate'=>'required_without_all:doctor_name,specialty,degree,region,service,min_price,max_price|Filled|numeric',
//         'specialty'=>'required_without_all:doctor_name,degree,region,governrate,service,min_price,max_price|Filled|numeric',
//         'service' => 'required_without_all:doctor_name,degree,region,governrate,specialty,min_price,max_price|Filled|numeric',
//         'min_price'=>'required_with:max_price|Filled|numeric',
//         'max_price'=>'required_with:min_price|Filled|numeric',

      ]
    );

      if($valid->fails()){
        return OutPut::Response('',$valid->Errors(),403);
      }

      // setting the variables
      $doctor_name = $request->input('doctor_name','');
      $medical_name = $request->input('medical_name','');
      $speciality_id = $request->input('specialty',0);
      $region_id = $request->input('region',0);
      $governrate_id= $request->input('governrate',0);
      $degree_id=$request->input('degree',0);
      $service_id=$request->input('service',0);
      $minPrice=$request->input('min_price',0);
      $maxPrice =$request->input('max_price',0);
      $page=$request->page === null ? 1 :$request->page;
      // adding the request
      $medicalprovider=new MedicalProvider();
      $doctorsresponse=$medicalprovider->detailedDoctorsSearch($doctor_name , $medical_name,$speciality_id , $region_id , $governrate_id ,$degree_id , $service_id ,$minPrice , $maxPrice , Auth::user()->id,$page,$lang);

      return OutPut::Response($doctorsresponse,'',200);
    }else{
      return OutPut::Response('',__('messages.auth_error'),401);
    }
  }

  public function apiDashboard(){
      $user=Auth::user();
      if(!$user->isDoctor()) {
          return OutPut::Response('',__('messages.auth_error'),401);
      }
      $doctorModel = new RequestModel();
       $currentRequestscount = $doctorModel->currentRequestCount('doctor_id' , $user->doctor->id );
      $oldRequestscount = $doctorModel->oldRequestCount('doctor_id' , $user->doctor->id );
      $pendingRequestsCount=$doctorModel->pendingRequestCount('doctor_id' , $user->doctor->id , 'Request');
      $waitingRequestsCount=$doctorModel->pendingRequestCount('doctor_id' , $user->doctor->id , 'Approve');
      return OutPut::Response([
          "current_requests_count"=> $currentRequestscount,
          "old_requests_count"=> $oldRequestscount,
          "pending_requests_count"=> $pendingRequestsCount,
          'waiting_requests_count'=>$waitingRequestsCount,
      ],'',200);

  }

  public function pendingRequests (){
      $user=Auth::user();
      if(!$user->isDoctor()) {
          return OutPut::Response('',__('messages.auth_error'),401);
      }
      $doctorModel = new RequestModel();
      $pendingRequests=$doctorModel->pendingRequests('doctor_id' , $user->doctor->id ,$user ,'Request');
      return OutPut::Response($pendingRequests,'',200);

  }
}
