<?php

namespace App\Http\Controllers;
use App\Patient;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Str;
use phpDocumentor\Reflection\Types\Array_;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
use TCG\Voyager\Http\Controllers\VoyagerBaseController as BaseVoyagerController;
use Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Storage;
use Image;
use Illuminate\Pagination\Paginator;
use Illuminate\Pagination\LengthAwarePaginator;
use Mail;
class patientVoyagerController extends BaseVoyagerController
{
    public function index(Request $request)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', 'patients')->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $patients=Patient::orderBy('id', 'DESC')->paginate(10);
            $i=0;
            $dataTypeContent=[];
            foreach ($patients as $key=>$patient)
            {
                $user=User::find($patient->user_id);
                if($user)
                {
                    $dataTypeContent[$i]=$user;
                    $i++;
                }
            }
            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;

            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

            $view = "vendor.voyager.patients.browse";

            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($dataTypeContent) && !empty($dataTypeContent['0']->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $dataTypeContent['0']->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }
            return Voyager::view($view, compact(
                'actions',
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'patients'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
    public function update(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Compatibility with Model binding.
        $id = $id instanceof Model ? $id->{$id->getKeyName()} : $id;

        $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

        // Check permission
        $this->authorize('edit', $data);

        // Validate fields with ajax
        // $val = $this->validateBread($request->all(), $dataType->editRows, $dataType->name, $id);

        //if ($val->fails()) {
        //  return response()->json(['errors' => $val->messages()]);
        //}
        $valid=Validator::make($request->all(),[
            'name' => [
                'required', 'Filled' ,'string' ,
                Rule::unique('users')->ignore( $id),
            ],
            'email' => [
                'required', 'Filled','E-Mail', 'string' ,
                Rule::unique('users')->ignore( $id),
            ],
//            'fullname' => [
//                'required', 'Filled','regex:/^[\pL\s\-]+$/u','string' ,
//            ],
            'mobile' => [
                'required', 'Filled',
            ],
            'gender' => [
                'required', 'Filled',
            ],
            'birthdate' => [
                'required', 'Filled',
            ],
        ]);
        if($valid->fails()) {
            //return response()->json(['errors' => $valid->messages()]);
            return redirect()->back()
                ->withErrors( $valid->messages())
                ->withInput();
        }
        if (!$request->ajax()) {
            $patient= User::find($id);
            $patient->name=$request->name;
            $patient->email=$request->email;
            $patient->fullname=$request->fullname;
            $patient->mobile=$request->mobile;
            $patient->gender=$request->gender;
            $patient->birthdate=$request->birthdate;
            if($request->password != "")
            {
                $patient->password=bcrypt($request->password);
            }
            $patient->save();
            if(!empty($request->file('profile'))) {
                $imagePath = $request->file('profile')->store('');
                $image = Image::make(Storage::get($imagePath))->encode();
                Storage::put($imagePath,$image);
                User::where('id', $patient->id)->update(['avatar' => "users/".$imagePath]);
            }
            $countParametersUrl = count(explode('&', $request->redirects_to));
            if($countParametersUrl>1) {
                $parametersString = explode('?', $request->redirects_to);
                preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
                $parameterString = "";
                for ($i = 0; $i < $countParametersUrl; $i++) {
                    $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
                }
                $routeName = "patient.search";
            }
            else{
                $previousUrl = explode('page=' , $request->redirects_to);
                $routeName = "voyager.patients.index";
                $parameterString= "page=";
                $parameterString.= $previousUrl['1'] ?? 1;
            }
            event(new BreadDataUpdated($dataType, $data));
            return redirect()
                ->route($routeName , [$parameterString])
                ->with([
                    'message'    => __('voyager::generic.successfully_updated')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function edit(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? app($dataType->model_name)->findOrFail($id)
            : DB::table($dataType->name)->where('id', $id)->first(); // If Model doest exist, get data from table name

        foreach ($dataType->editRows as $key => $row) {
            $dataType->editRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }

        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'edit');

        // Check permission
        $this->authorize('edit', $dataTypeContent);

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable'));
    }

    public function create(Request $request)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? new $dataType->model_name()
            : false;
        $dataTypeContent->avatar="users/default.png";
        foreach ($dataType->addRows as $key => $row) {
            $dataType->addRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }

        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'add');

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable'));
    }
    public function store(Request $request)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        // Validate fields with ajax
        //$val = $this->validateBread($request->all(), $dataType->addRows);

        //if ($val->fails()) {
        // return response()->json(['errors' => $val->messages()]);
        //}
        $valid=Validator::make($request->all(),[
            'name' => [
                'required', 'Filled' ,'string' ,
                Rule::unique('users')->ignore( $request->user_id),
            ],
            'email' => [
                'required', 'Filled','E-Mail', 'string' ,
                Rule::unique('users')->ignore( $request->user_id),
            ],
//            'fullname' => [
//                'required', 'Filled','regex:/^[\pL\s\-]+$/u','string' ,
//            ],
            'password' => [
                'required', 'Filled',
            ],
            'mobile' => [
                'required', 'Filled',
            ],
            'gender' => [
                'required', 'Filled',
            ],
            'birthdate' => [
                'required', 'Filled',
            ],
        ])->validate();
//        if($valid->fails()) {
//            return response()->json(['errors' => $valid->messages()]);
//        }

        if (!$request->has('_validate')) {
            $request['lang']= 'en';
            $request['verified']= 0;
            $request['disabled']= 0;
            $data = $this->insertUpdateData($request, $slug, $dataType->addRows, new $dataType->model_name());
            User::where('id', $data->id)->update(['token' =>Str::random(32) , 'role_id'=>2]);
            $user_id=User::where("id","=",$data->id)->get();
            $newPatient= new Patient();
            $newPatient->user_id=$user_id[0]->id;
            $newPatient->save();
            DB::table('user_roles')->insert(
                ['user_id' => $user_id[0]->id ,'role_id' => 4]
            );
            if(!empty($request->file('profile'))) {
                $imagePath = $request->file('profile')->store('');
                $image = Image::make(Storage::get($imagePath))->encode();
                Storage::put($imagePath,$image);
                User::where('id', $data->id)->update(['avatar' => "users/".$imagePath]);
            }
            Mail::to($user_id)->send(new \App\Mail\NewPatient($request->email,$request->password , $request->fullname , $user_id[0]->token));
            event(new BreadDataAdded($dataType, $data));

            if ($request->ajax()) {
                return response()->json(['success' => true, 'data' => $data]);
            }

            return redirect()
                ->route("voyager.patients.index")
                ->with([
                    'message'    => __('voyager::generic.successfully_added_new')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function Deletepatient(Request $request)
    {

        $ids = [];
        // Bulk delete, get IDs from POST
        $ids =  $request->row_id;
        foreach($ids as $id)
        {
            if(!empty($id)) {
                $user = User::find($id);
                if (!$user) {
                    return 'false';
                } else {
                    $user->delete();
                }
            }
        }
        return 'true';
    }
    public function delete_single($id)
    {
        $user = User::find($id);
        if ($user) {
            $user->delete();
        }
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "patient.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.patients.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName , [$parameterString]);
    }
    public function show(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $dataTypeContent = call_user_func([$model, 'findOrFail'], $id);
        } else {
            // If Model doest exist, get data from table name
            $dataTypeContent = DB::table($dataType->name)->where('id', $id)->first();
        }

        // Replace relationships' keys for labels and create READ links if a slug is provided.
        $dataTypeContent = $this->resolveRelations($dataTypeContent, $dataType, true);

        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'read');

        // Check permission
        $this->authorize('read', $dataTypeContent);

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "patient.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.patients.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        $view = 'voyager::bread.read';
        if (view()->exists("voyager::$slug.read")) {
            $view = "voyager::$slug.read";
        }
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable' , 'routeName' , 'parameterString'));
    }
    public function patientSearch(Request $request)
    {
        $emailSearch = $request->email;
        $nameArSearch = $request->name_ar;
        $nameEnSearch = $request->name_en;
        $statusSearch = $request->status;
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = "patients";
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', 'patients')->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $patients=Patient::orderBy('id', 'DESC')->whereHas('user',function($query) use ($emailSearch , $nameArSearch , $nameEnSearch ,$statusSearch){
                if($emailSearch!='')
                    $query->where('email','like' , '%'.$emailSearch .'%');
                if($nameArSearch!='')
                    $query->where('fullname','like' , '%'.$nameArSearch.'%');
                if($nameEnSearch!='')
                    $query->where('fullname_en','like','%'.$nameEnSearch.'%');
                if($statusSearch!='')
                    $query->where('verified',$statusSearch);
            })->paginate(10);
            $patients->appends(['email' => $emailSearch ,'name_ar' =>$nameArSearch ,'name_en'=>$nameEnSearch,'status'=>$statusSearch]);
            $i=0;
            $dataTypeContent=[];
            foreach ($patients as $key=>$patient)
            {
                $user=User::find($patient->user_id);
                if($user)
                {
                    $dataTypeContent[$i]=$user;
                    $i++;
                }
            }
            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;

            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

            $view = "vendor.voyager.patients.browse";

            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($dataTypeContent) && !empty($dataTypeContent['0']->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $dataTypeContent['0']->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }
            return Voyager::view($view, compact(
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'patients',
                'emailSearch',
                'nameArSearch',
                'nameEnSearch',
                'statusSearch',
                'actions'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
}
