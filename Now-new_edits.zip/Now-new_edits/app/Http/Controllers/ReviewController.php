<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Review;
use Validator;
use Auth;
use App\Patient;
use App\Appointment;
class ReviewController extends Controller
{
  use OutPut;

  public function __construct()
  {
      $this->middleware('auth:api');
  }

  public function addreview(Request $request){
        $user=Auth::user();
      app()->setLocale($user->token()->user_lang);
    $valid=Validator::make($request->all(),[
      'rate'=>'required|Filled|numeric',
      'comment'=>'string|nullable',
      'appointment_id'=>'required|Filled|numeric',
    ]);
    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }


    // get request data

    $appointmentId=$request->input('appointment_id');
    $rate=$request->input('rate');
    $comment=$request->input('comment','');
    $req=\App\Request::whereHas('appointments',function($query) use($appointmentId){
      return $query->where('id',$appointmentId);
    })->with('appointments')->first();
      $patient = Patient::find($req->patient_id);
     $reviewExists = Review::where('appointment_id',$appointmentId)->first();

    if($user->id == $patient->user_id){
      if ($reviewExists){
        return OutPut::Response('',__('messages.repeat_review_not_allowed'),403);
      }else{
        if($req->date<date('Y-m-d') || ($req->date==date('Y-m-d')&&$req->time < date('H:i:s'))){
          $review=new Review;
          $review->addDoctorReview($user->id,$req->doctor_id,$rate,$appointmentId,$comment);
          \App\notifications::sendDataMessage(Auth::user()->id,'review_request',Auth::user()->id,$req->id,'','','updateOldRequest');

            return OutPut::Response('',__('messages.review_successful'),200);
        }else{
            return OutPut::Response('',__('messages.future_review_not_allowed'),403);
        }
      }
    }else{
      return OutPut::Response('',__('messages.auth_error'),403);
    }


  }
}
