<?php

namespace App\Http\Controllers;

use App\Appointment;
use App\Patient;
use App\MedicalProvider;
use App\Doctor;
use App\Review;
use App\Service;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use phpDocumentor\Reflection\Types\Array_;
use PhpParser\Comment\Doc;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
use TCG\Voyager\Http\Controllers\VoyagerBaseController as BaseVoyagerController;
use Redirect;
use App\Request as requestModel;
use Response;
use Illuminate\Support\Facades\Validator;


class requestVoyagerController extends BaseVoyagerController
{
    public function index(Request $request)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);

        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object) ['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%'.$search->value.'%';
                $query->where($search->key, $search_filter, $search_value);
            }

            if ($orderBy && in_array($orderBy, $dataType->fields())) {
                $querySortOrder = (!empty($sortOrder)) ? $sortOrder : 'desc';
                $requestdata = call_user_func([
                    $query->orderBy($orderBy, $querySortOrder),
                    $getter,
                ]);
            } elseif ($model->timestamps) {
                $requestdata = call_user_func([$query->latest($model::CREATED_AT), $getter]);
            } else {
                $requestdata = call_user_func([$query->orderBy($model->getKeyName(), 'DESC'), $getter]);
            }

            // Replace relationships' keys for labels and create READ links if a slug is provided.
            $requestdata = $this->resolveRelations($requestdata, $dataType);

        } else {
            // If Model doesn't exist, get data from table name
            $requestdata = call_user_func([DB::table($dataType->name), $getter]);
            $model = false;
        }

        // Check if BREAD is Translatable
        if (($isModelTranslatable = is_bread_translatable($model))) {
            $requestdata->load('translations');
        }
        $requestdata=requestModel::orderBy('id', 'DESC')->paginate(10);
        $dataTypeContent=[];
        $i=0;
        foreach ($requestdata as $data)
        {
            $dataTypeContent[$i]=$data;
            $patient=Patient::where("id","=",$data->patient_id)->get();
            if($patient)
            {
                $patient=$patient->toArray();
                $patientuser=User::withTrashed()->find($patient[0]['user_id']);
                $dataTypeContent[$i]['patient_name']=$patientuser['name'];
            }
            $doctor=Doctor::where("id","=",$data->doctor_id)->get();
            if($doctor)
            {
                $doctor=$doctor->toArray();
                $doctoruser=User::withTrashed()->find($doctor[0]['user_id']);
                $dataTypeContent[$i]['doctor_name']=$doctoruser->fullname_en;
            }
            $medical=MedicalProvider::where("id","=",$data->medical_provider_id)->get();

            if($medical)
            {
                $medical=$medical->toArray();
                $medicaluser=User::withTrashed()->find($medical[0]['user_id']);
                $dataTypeContent[$i]['medical_name']=$medicaluser->fullname_en;
            }
            $appointment=Appointment::where("request_id","=",$data->id)->get();
            if($appointment)
            {
                $appointment=$appointment->toArray();
            }
            $dataTypeContent[$i]['rating']="";
            $dataTypeContent[$i]['comment']="";
            if(!empty($appointment))
            {
                $review=Review::where("appointment_id","=",$appointment[0]['id'])->get();
                if(count($review)>0) {
                    $dataTypeContent[$i]['rating'] = $review[0]['rating'];
                    $dataTypeContent[$i]['comment'] = $review[0]['comment'];
                }
            }
            $dataTypeContent[$i]['date_time']=$data->date." ".$data->time;
            $dataTypeContent[$i]['date']=$data->date;
            $dataTypeContent[$i]['time']=$data->time;
            $dataTypeContent[$i]['service']=$data->service->name_en ?? '';
            $i++;
        }

        // Check if server side pagination is enabled
        $isServerSide = isset($dataType->server_side) && $dataType->server_side;

        // Check if a default search key is set
        $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

        $view = 'voyager::bread.browse';

        if (view()->exists("voyager::$slug.browse")) {
            $view = "voyager::$slug.browse";
        }

        return Voyager::view($view, compact(
            'dataType',
            'dataTypeContent',
            'isModelTranslatable',
            'search',
            'orderBy',
            'orderColumn',
            'sortOrder',
            'searchable',
            'isServerSide',
            'defaultSearchKey',
            'requestdata'
        ));
    }
    public function indexsearch(Request $request,$id)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = 'requests';

        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object) ['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%'.$search->value.'%';
                $query->where($search->key, $search_filter, $search_value);
            }

            if ($orderBy && in_array($orderBy, $dataType->fields())) {
                $querySortOrder = (!empty($sortOrder)) ? $sortOrder : 'desc';
                $requestdata = call_user_func([
                    $query->orderBy($orderBy, $querySortOrder),
                    $getter,
                ]);
            } elseif ($model->timestamps) {
                $requestdata = call_user_func([$query->latest($model::CREATED_AT), $getter]);
            } else {
                $requestdata = call_user_func([$query->orderBy($model->getKeyName(), 'DESC'), $getter]);
            }

            // Replace relationships' keys for labels and create READ links if a slug is provided.
            $requestdata = $this->resolveRelations($requestdata, $dataType);

        } else {
            // If Model doesn't exist, get data from table name
            $requestdata = call_user_func([DB::table($dataType->name), $getter]);
            $model = false;
        }

        // Check if BREAD is Translatable
        if (($isModelTranslatable = is_bread_translatable($model))) {
            $requestdata->load('translations');
        }
        $requestdata=User::find($id);
        $dataTypeContent=[];
        $i=0;
        $patient=Patient::where("user_id","=",$requestdata->id)->get();
        $medicalprovider=MedicalProvider::where("user_id","=",$requestdata->id)->get();
        if(!$patient->isEmpty())
        {
            $patientrequests=requestModel::where("patient_id","=",$patient[0]->id)->get();
            if(!$patientrequests->isEmpty())
            {
                $dataTypeContent[$i]['name']=$requestdata->name;
                foreach ($patientrequests as $data)
                {
                    $doctor=Doctor::where("id","=",$data->doctor_id)->get();
                    $doctor=$doctor->toArray();
                    $medical=MedicalProvider::where("id","=",$data->medical_provider_id)->get();
                    $medical=$medical->toArray();
                    $appointment=Appointment::where("request_id","=",$data->id)->get();
                    $appointment=$appointment->toArray();
                    $dataTypeContent[$i]['rating']="";
                    $dataTypeContent[$i]['comment']="";
                    if(!empty($appointment))
                    {
                        $review=Review::where("appointment_id","=",$appointment[0]['id'])->get();
                        $dataTypeContent[$i]['rating']=$review[0]['rating'];
                        $dataTypeContent[$i]['comment']=$review[0]['comment'];
                    }
                    $doctoruser=User::find($doctor[0]['user_id']);
                    $medicaluser=User::find($medical[0]['user_id']);
                    $dataTypeContent[$i]['patient_name']=$requestdata->name;
                    $dataTypeContent[$i]['doctor_name']=$doctoruser->name;
                    $dataTypeContent[$i]['medical_name']=$medicaluser->name;
                    $dataTypeContent[$i]['date_time']=$data->date." ".$data->time;
                    $dataTypeContent[$i]['id']=$patientrequests[0]->id;
                    $dataTypeContent[$i]['disabled']=$patientrequests[0]->disabled;
                    $dataTypeContent[$i]['status']=$patientrequests[0]->status;
                    $i++;
                }
            }
        }
        else if(!$medicalprovider->isEmpty())
        {
            $medicalrequests=requestModel::where("medical_provider_id","=",$medicalprovider[0]->id)->get();
            if(!$medicalrequests->isEmpty()){
                $dataTypeContent[$i]['name']=$requestdata->name;
                foreach ($medicalrequests as $data)
                {
                    $doctor=Doctor::where("id","=",$data->doctor_id)->get();
                    $doctor=$doctor->toArray();
                    $patient=Patient::where("id","=",$data->patient_id)->get();
                    $patient=$patient->toArray();
                    $appointment=Appointment::where("request_id","=",$data->id)->get();
                    $appointment=$appointment->toArray();
                    $dataTypeContent[$i]['rating']="";
                    $dataTypeContent[$i]['comment']="";
                    if(!empty($appointment))
                    {
                        $review=Review::where("appointment_id","=",$appointment[0]['id'])->get();
                        $dataTypeContent[$i]['rating']=$review[0]['rating'];
                        $dataTypeContent[$i]['comment']=$review[0]['comment'];
                    }
                    $doctoruser=User::find($doctor[0]['user_id']);
                    $patientuser=User::find($patient[0]['user_id']);
                    $dataTypeContent[$i]['patient_name']=$patientuser->name;
                    $dataTypeContent[$i]['doctor_name']=$doctoruser->name;
                    $dataTypeContent[$i]['medical_name']=$requestdata->name;
                    $dataTypeContent[$i]['date_time']=$data->date." ".$data->time;
                    $dataTypeContent[$i]['id']=$medicalrequests[0]->id;
                    $dataTypeContent[$i]['disabled']=$medicalrequests[0]->disabled;
                    $dataTypeContent[$i]['status']=$medicalrequests[0]->status;
                    $i++;
                }
            }
        }
        // Check if server side pagination is enabled
        $isServerSide = isset($dataType->server_side) && $dataType->server_side;

        // Check if a default search key is set
        $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

        $view = 'voyager::bread.browse';

        if (view()->exists("voyager::$slug.browse")) {
            $view = "voyager::$slug.browse";
        }

        return Voyager::view($view, compact(
            'dataType',
            'dataTypeContent',
            'isModelTranslatable',
            'search',
            'orderBy',
            'orderColumn',
            'sortOrder',
            'searchable',
            'isServerSide',
            'defaultSearchKey'
        ));
    }
    public function indexsearchdate(Request $request,$date)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = 'requests';

        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object) ['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%'.$search->value.'%';
                $query->where($search->key, $search_filter, $search_value);
            }

            if ($orderBy && in_array($orderBy, $dataType->fields())) {
                $querySortOrder = (!empty($sortOrder)) ? $sortOrder : 'desc';
                $requestdata = call_user_func([
                    $query->orderBy($orderBy, $querySortOrder),
                    $getter,
                ]);
            } elseif ($model->timestamps) {
                $requestdata = call_user_func([$query->latest($model::CREATED_AT), $getter]);
            } else {
                $requestdata = call_user_func([$query->orderBy($model->getKeyName(), 'DESC'), $getter]);
            }

            // Replace relationships' keys for labels and create READ links if a slug is provided.
            $requestdata = $this->resolveRelations($requestdata, $dataType);

        } else {
            // If Model doesn't exist, get data from table name
            $requestdata = call_user_func([DB::table($dataType->name), $getter]);
            $model = false;
        }

        // Check if BREAD is Translatable
        if (($isModelTranslatable = is_bread_translatable($model))) {
            $requestdata->load('translations');
        }
        $requestdata=requestModel::where("date","=",$date)->get();
        $dataTypeContent=[];
        $i=0;
        foreach ($requestdata as $data)
        {
            $dataTypeContent[$i]=$data;
            $patient=Patient::where("id","=",$data->patient_id)->get();
            $patient=$patient->toArray();
            $doctor=Doctor::where("id","=",$data->doctor_id)->get();
            $doctor=$doctor->toArray();
            $medical=MedicalProvider::where("id","=",$data->medical_provider_id)->get();
            $medical=$medical->toArray();
            $appointment=Appointment::where("request_id","=",$data->id)->get();
            $appointment=$appointment->toArray();
            $dataTypeContent[$i]['rating']="";
            $dataTypeContent[$i]['comment']="";
            if(!empty($appointment))
            {
                $review=Review::where("appointment_id","=",$appointment[0]['id'])->get();
                $dataTypeContent[$i]['rating']=$review[0]['rating'];
                $dataTypeContent[$i]['comment']=$review[0]['comment'];
            }
            $patientuser=User::find($patient[0]['user_id']);
            $doctoruser=User::find($doctor[0]['user_id']);
            $medicaluser=User::find($medical[0]['user_id']);
            $dataTypeContent[$i]['patient_name']=$patientuser->name;
            $dataTypeContent[$i]['doctor_name']=$doctoruser->name;
            $dataTypeContent[$i]['medical_name']=$medicaluser->name;
            $dataTypeContent[$i]['date_time']=$data->date." ".$data->time;
            $i++;
        }


        // Check if server side pagination is enabled
        $isServerSide = isset($dataType->server_side) && $dataType->server_side;

        // Check if a default search key is set
        $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

        $view = 'voyager::bread.browse';

        if (view()->exists("voyager::$slug.browse")) {
            $view = "voyager::$slug.browse";
        }

        return Voyager::view($view, compact(
            'dataType',
            'dataTypeContent',
            'isModelTranslatable',
            'search',
            'orderBy',
            'orderColumn',
            'sortOrder',
            'searchable',
            'isServerSide',
            'defaultSearchKey'
        ));

    }
    public function create(Request $request)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? new $dataType->model_name()
            : false;

        foreach ($dataType->addRows as $key => $row) {
            $dataType->addRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }

        $allpatients=Patient::whereHas('user',function($query){
            return $query->where('deleted_at', '=', Null)->where('disabled','=',0);
        })->paginate(10);
        $patients=[];
        $i=0;
        if($allpatients)
        {
            foreach ($allpatients as $patient)
            {
                $user=User::where('id','=',$patient->user_id)->get();
                if($user)
                {
                    $patients[$i]=$patient;
                    $patients[$i]['name']=$user['0']->id;
                    $i++;
                }
            }
        }

        $doctors=Doctor::whereHas('user',function($query){
            return $query->where('deleted_at', '=', Null)->where('disabled','=',0);
        })->paginate(10);
        $alldoctors=[];
        $i=0;
        if($doctors)
        {
            foreach ($doctors as $doctor)
            {
                $user=User::where('id','=',$doctor->user_id)->get();
                if($user)
                {
                    $alldoctors[$i]=$doctor;
                    //$alldoctors[$i]['name']=$user[0]->name;
                    $i++;
                }
            }
        }
        $allmedicalProviders=MedicalProvider::whereHas('user',function($query){
            return $query->where('deleted_at', '=', Null)->where('disabled','=',0);
        })->paginate(10);
        $medicalProviders=[];
        $i=0;
        if($allmedicalProviders)
        {
            foreach ($allmedicalProviders as $medicalProvider) {
                $user=User::withTrashed()->where('id','=',$medicalProvider->user_id)->get();
                if($user)
                {
                    $medicalProviders[$i]=$medicalProvider;
                    $medicalProviders[$i]['name']=$user[0]->name;
                    $i++;
                }
            }
        }
        $allServices=Service::where('deleted_at', '=', Null)->where('disabled','=',0)->paginate(10);
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'add');

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';
        if($request->ajax())
        {
            $data= DB::table("patients")->paginate(10);
            $view = 'voyager::bread.edit-add';
            return Voyager::view($view, compact('data','dataType', 'dataTypeContent', 'isModelTranslatable','allpatients','patients','medicalProviders','allmedicalProviders','doctors','alldoctors'))->render();
        }
        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        if(!is_null($request->old('hidden_add_patient'))){
            $newPatientName = Patient::find($request->old('hidden_add_patient'));
            $dataTypeContent['patient_name']= $newPatientName->user->name ;
        }
        if(!is_null($request->old('hidden_add_medical'))){
            $newMedicalName = MedicalProvider::find($request->old('hidden_add_medical'));
            $dataTypeContent['medical_name']= $newMedicalName->user->fullname_en ;
        }
        if(!is_null($request->old('add_doctor'))){
        $newDoctorName = Doctor::find($request->old('add_doctor'));
        $dataTypeContent['doctor_name']= $newDoctorName->user->fullname_en ;
        }
        if(!is_null($request->old('add_service'))){
            $newServiceName = Service::find($request->old('add_service'));
            $dataTypeContent['service_name']= $newServiceName->name_en ;
        }
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable','allpatients','patients','medicalProviders','allmedicalProviders','doctors','alldoctors' ,'allServices'));
    }
    public function store(Request $request)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        // Validate fields with ajax
//        $val = $this->validateBread($request->all(), $dataType->addRows);
//
//        if ($val->fails()) {
//            return response()->json(['errors' => $val->messages()]);
//        }
        $valid=Validator::make($request->all(),[
            'hidden_add_patient' => [
                'required', 'Filled',
            ],
            'hidden_add_medical' => [
                'required', 'Filled',
            ],
            'add_doctor' => [
                'required', 'Filled',
            ],
            'add_service' => [
                'required', 'Filled',
            ],
            'date' => [
                'required', 'Filled',
            ],
            'time_hours' => [
                'required', 'Filled',
            ],
            'time_minutes' => [
                'required', 'Filled',
            ],
            'time_a' => [
                'required', 'Filled',
            ],
        ], ['add_doctor.required' => 'Please Select Doctor' , 'add_doctor.Filled' => 'Please Select Doctor','hidden_add_patient.required' => 'Please Select Patient' , 'hidden_add_patient.Filled' => 'Please Select Patient','hidden_add_medical.required' => 'Please Select Medical Provider' , 'hidden_add_medical.Filled' => 'Please Select Medical Provider'  , 'add_service.required' => 'Please Select Service' , 'add_service.Filled' => 'Please Select Service',] )->validate();
//        if($valid->fails()) {
//            return response()->json(['errors' => $valid->messages()]);
//        }
        if (!$request->has('_validate')) {
            $obj=new requestModel();
            $requestDate=date("Y-m-d", strtotime($request->request_date_time));
            //$requestTime = $request->time_hours.":".$request->time_minutes.$request->time_a;
            //$requestTime = date("H:i", strtotime($requestTime));
            $requestTime = date("H:i", strtotime($request->request_date_time));
            $newrequest=$obj->addrequest($request->hidden_add_patient,$request->add_doctor,$request->hidden_add_medical,$request->add_service,$requestDate,$requestTime);

            if ($request->ajax()) {
                return response()->json(['success' => true]);
            }

            return redirect()
                ->route("voyager.{$dataType->slug}.index")
                ->with([
                    'message'    => __('voyager::generic.successfully_added_new')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function edit(Request $request, $id)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();
        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? app($dataType->model_name)->findOrFail($id)
            : DB::table($dataType->name)->where('id', $id)->first(); // If Model doest exist, get data from table name

        $this->authorize('edit', $dataTypeContent);
        $singlerequest = requestModel::find($id);
        $patient=Patient::where("id","=",$singlerequest->patient_id)->get();
        $patient=$patient->toArray();
        $doctor=Doctor::where("id","=",$singlerequest->doctor_id)->get();
        $doctor=$doctor->toArray();
        $medical=MedicalProvider::where("id","=",$singlerequest->medical_provider_id)->get();
        $medical=$medical->toArray();
        $patientuser=User::withTrashed()->find($patient[0]['user_id']);
        $doctoruser=User::withTrashed()->find($doctor[0]['user_id']);
        $medicaluser=User::withTrashed()->find($medical[0]['user_id']);
        $dataTypeContent->patient_name=$patientuser->name;
        $dataTypeContent->doctor_name=$doctoruser->name;
        $dataTypeContent->medical_name=$medicaluser->name;
        $dataTypeContent->date_time=$singlerequest->date." ".$singlerequest->time;
        $dataTypeContent->time=$singlerequest->time;
        $dataTypeContent->time_hours = date("g", strtotime($singlerequest->time));
        $dataTypeContent->time_minutes = date("i", strtotime($singlerequest->time));
        $dataTypeContent->time_a = date("a", strtotime($singlerequest->time));
        $dataTypeContent->service=$singlerequest->service;
        $allpatients=Patient::whereHas('user',function($query){
            return $query->where('deleted_at', '=', Null);
        })->paginate(10);
        $patients=[];
        $i=0;
        if(!$allpatients->isEmpty())
        {
            foreach ($allpatients as $patient)
            {
                $user=User::find($patient->user_id);
                $patients[$i]=$patient;
                $patients[$i]['name']=$user['name'];
                $i++;
            }
        }
        $doctors = DB::table('doctor_has_medical_provider')->where('medical_provider_id', '=',$singlerequest->medical_provider_id)->paginate(10);
        if ($doctors) {
            $doctor_from_doctors = [];
            $i = 0;
            foreach ($doctors as $id) {
                $doctor = Doctor::find($id->doctor_id);
                if ($doctor) {
                    $doctor_from_doctors[$i] = $doctor;
                    $i++;
                }
            }
            $alldoctors = [];
            $j = 0;
            for ($i = 0; $i < count($doctor_from_doctors); $i++) {
                $doctor = User::where('id', '=', $doctor_from_doctors[$i]->user_id)->where('disabled', '=', 0)->get();
                if (!$doctor->isEmpty()) {
                    $alldoctors[$j] = $doctor_from_doctors[$i];
                    $alldoctors[$j]['name'] = $doctor[0]->name;
                    $j++;
                }
            }
        }
        $allmedicalProviders=MedicalProvider::whereHas('user',function($query){
            return $query->where('deleted_at', '=', Null);
        })->paginate(10);
        $medicalProviders=[];
        $i=0;
        if($allmedicalProviders)
        {
            foreach ($allmedicalProviders as $medicalProvider) {
                $medicalProviders[$i]=$medicalProvider;
                $user=User::find($medicalProvider->user_id);
                if($user)
                {
                    $medicalProviders[$i]['name']=$user->name;
                    $i++;
                }
            }
        }
        foreach ($dataType->editRows as $key => $row) {
            $dataType->editRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }
        $allServices = DB::table('medical_provider_has_specialties')
            ->join('medical_provider_specialty_has_services', 'medical_provider_has_specialties.id', '=', 'medical_provider_specialty_has_services.medical_provider_has_speciality_id')
            ->join('services', 'services.id', '=', 'medical_provider_specialty_has_services.service_id')
            ->where('medical_provider_id' ,$singlerequest->medical_provider_id)
            ->where('services.deleted_at', '=', Null)->where('services.disabled','=',0)
            ->select([DB::RAW('DISTINCT(services.id)'), 'services.name_ar', 'services.name_en'])
            ->paginate(10);

        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'edit');

        // Check permission


        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable','patients','medicalProviders','doctors','allpatients','alldoctors','allmedicalProviders', 'allServices'));
    }
    public function update(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Compatibility with Model binding.
        $id = $id instanceof Model ? $id->{$id->getKeyName()} : $id;

        $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

        // Check permission
        $this->authorize('edit', $data);

        // Validate fields with ajax
        //$val = $this->validateBread($request->all(), $dataType->editRows, $dataType->name, $id);

//        if ($val->fails()) {
//            return response()->json(['errors' => $val->messages()]);
//        }

        if($request->edit_medical != "")
        {
            $valid=Validator::make($request->all(),[
                'hidden_doctor' => [
                    'required', 'Filled',
                ],
                'hidden_service' => [
                    'required', 'Filled',
                ],
                'time_hours' => [
                    'required', 'Filled',
                ],
                'time_minutes' => [
                    'required', 'Filled',
                ],
                'time_a' => [
                    'required', 'Filled',
                ],
            ], ['hidden_doctor.required' => 'Please Reselect Doctor',
                'hidden_doctor.Filled' => 'Please Reselect Doctor',
                'hidden_service.required' => 'Please Reselect Service' ,
                'hidden_service.Filled' => 'Please Reselect Service'
            ] )->validate();
//            if($valid->fails()) {
//                return response()->json(['errors' => $valid->messages()]);
//            }
        }
        if(!$request->ajax()) {
             $requestDate=date("Y-m-d", strtotime($request->request_date_time));
             $requestTime = date("H:i", strtotime($request->request_date_time));
            //$requestTime = $request->time_hours.":".$request->time_minutes.$request->time_a;
            //$requestTime = date("H:i", strtotime($requestTime));
            $requestUpadte= \App\Request::find($id);
            $requestUpadte->patient_id=$request->edit_patient;
            $requestUpadte->doctor_id=$request->hidden_doctor;
            $requestUpadte->medical_provider_id=$request->edit_medical;
            $requestUpadte->service_id= $request->hidden_service ;
            $requestUpadte->date=$requestDate;
            $requestUpadte->time=$requestTime;
            $requestUpadte->save();
            event(new BreadDataUpdated($dataType, $data));
            $countParametersUrl = count(explode('&', $request->redirects_to));
            if($countParametersUrl>1) {
                $parametersString = explode('?', $request->redirects_to);
                preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
                $parameterString = "";
                for ($i = 0; $i < $countParametersUrl; $i++) {
                    $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
                }
                $routeName = "request.search";
            }
            else{
                $previousUrl = explode('page=' , $request->redirects_to);
                $routeName = "voyager.{$dataType->slug}.index";
                $parameterString= "page=";
                $parameterString.= $previousUrl['1'] ?? 1;
            }

            return redirect()
                ->route($routeName , [$parameterString])
                ->with([
                    'message'    => __('voyager::generic.successfully_updated')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function selectDoctor(Request $request)
    {


        $alldoctors = DB::table('doctor_has_medical_provider')->select(DB::raw('doctor_id'))->where('medical_provider_id', '=', $request->medicalProviderId)->paginate(10);
        $doctors=[];
        $i=0;
        $alldoctors=$alldoctors->toArray();
        foreach ($alldoctors as $doctor) {
            $doctors[$i]['id']=$doctor->doctor_id;
            $doc=Doctor::find($doctor->doctor_id);
            $user=User::find($doc->user_id);
            $doctors[$i]['name']=$user->name;
            $i++;
        }
        return response()->json($doctors);
    }
    public function selectService(Request $request)
    {
        $allServices =  DB::table('medical_provider_has_specialties')
            ->join('medical_provider_specialty_has_services', 'medical_provider_has_specialties.id', '=', 'medical_provider_specialty_has_services.medical_provider_has_speciality_id')
            ->where('medical_provider_id' ,$request->medicalProviderId)
            ->paginate(10);
        $services=[];
        $i=0;
        $allServices=$allServices->toArray();
        foreach ($allServices as $service) {
            $services[$i]['id']=$service->service_id;
            $serviceInfo=\App\Service::find($service->service_id);
            $services[$i]['name']=$serviceInfo->name_en;
            $i++;
        }
        return response()->json($services);
    }
    public function DeleteRequest(Request $request)
    {

        $ids = [];

        // Bulk delete, get IDs from POST
        $ids =  $request->row_id;
        foreach($ids as $id)
        {
            if(!empty($id)) {
                $req = requestModel::find($id);
                if (!$req) {
                    return 'false';
                } else {
                    $req->delete();
                }
            }
        }
        return 'true';
    }
    public function delete_single($id)
    {
        $req = requestModel::find($id);
        if ($req) {
            $req->delete();
        }
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "request.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.requests.index";
            $parameterString= "page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()
            ->route($routeName , [$parameterString]);
    }
    public function show(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $dataTypeContent = call_user_func([$model, 'findOrFail'], $id);
        } else {
            // If Model doest exist, get data from table name
            $dataTypeContent = DB::table($dataType->name)->where('id', $id)->first();
        }

        // Replace relationships' keys for labels and create READ links if a slug is provided.
        $dataTypeContent = $this->resolveRelations($dataTypeContent, $dataType, true);

        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'read');

        // Check permission
        $this->authorize('read', $dataTypeContent);

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $singlerequest = requestModel::find($id);
        $patient=Patient::where("id","=",$singlerequest->patient_id)->get();
        $patient=$patient->toArray();
        $doctor=Doctor::where("id","=",$singlerequest->doctor_id)->get();
        $doctor=$doctor->toArray();
        $medical=MedicalProvider::where("id","=",$singlerequest->medical_provider_id)->get();
        $medical=$medical->toArray();
        $appointment=Appointment::where("request_id","=",$singlerequest->id)->get();
        $appointment=$appointment->toArray();
        $dataTypeContent->date_time=$singlerequest->date." ".$singlerequest->time;
        $dataTypeContent->date=$singlerequest->date;
        $dataTypeContent->time=$singlerequest->time;
        $dataTypeContent->rating="";
        $dataTypeContent->comment="";
        if(!empty($appointment))
        {
            $review=Review::where("appointment_id","=",$appointment[0]['id'])->get();
            if(count($review)>0) {
                $dataTypeContent->rating=$review[0]['rating'];
                $dataTypeContent->comment=$review[0]['comment'];
            }
        }
        $patientuser=User::withTrashed()->find($patient[0]['user_id']);
        $doctoruser=User::withTrashed()->find($doctor[0]['user_id']);
        $medicaluser=User::withTrashed()->find($medical[0]['user_id']);
        $dataTypeContent->patient_name=$patientuser->name;
        $dataTypeContent->doctor_name=$doctoruser->name;
        $dataTypeContent->medical_name=$medicaluser->name;
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "request.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.requests.index";
            $parameterString= "page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        $view = 'voyager::bread.read';

        if (view()->exists("voyager::$slug.read")) {
            $view = "voyager::$slug.read";
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable' , 'routeName', 'parameterString'));
    }
    function fetch(Request $request)
    {
        if($request->get('query'))
        {
            $query = $request->get('query');
            $data = DB::table('users')
                ->where('name', 'LIKE', "%{$query}%")
                ->get();
            $output = '<ul class="dropdown-menu col-lg-4" style="display:block; position:relative; width: 100%; margin: 0px; z-index: 5;">';
            foreach($data as $row)
            {
                $output .= '
       <li><a href='.route('indexsearch',$row->id).'>'.$row->name.'</a></li>
       ';
            }
            $output .= '</ul>';
            echo $output;
        }
    }
    function fetchdate(Request $request)
    {
        if($request->get('query'))
        {
            $query = $request->get('query');
            $data = DB::table('requests')
                ->where('date', 'LIKE', "%{$query}%")
                ->get();
            $output = '<ul class="dropdown-menu col-lg-4" style="display:block; position:relative; width: 100%; margin: 0px; z-index: 5;">';
            foreach($data as $row)
            {
                $output .= '
       <li><a href='.route('indexsearchdate',$row->date).'>'.$row->date.'</a></li>
       ';
            }
            $output .= '</ul>';
            echo $output;
        }
    }
    function filter_search(Request $request)
    {
        if($request->get('type') == 1)
        {
            $query=$request->get('query')!==null? $request->get('query') : "" ;
            $allpatients = User::where('name', 'LIKE', "%{$query}%")->where('disabled','=',0)->where('deleted_at' , "=",null)->has('patient')->paginate(10);
            $patients=[];
            $i=0;
            if($allpatients)
            {
                foreach ($allpatients as $patient)
                {
                    $user=Patient::where('user_id','=',$patient->id)->get();
                    if($user)
                    {
                        $patients[$i]=$user[0];
                        $patients[$i]['name']=$patient->name;
                        $i++;
                    }
                }
            }
            return Voyager::view('vendor.voyager.requests.paginate_data', compact('allpatients','patients'))->render();
        }
        else if($request->get('type') == 2)
        {
            $query=$request->get('query')!==null? $request->get('query') : "" ;
            $allmedicalProviders = User::where('name', 'LIKE', "%{$query}%")->where('disabled','=',0)->where('deleted_at' , "=",null)->has('medicalprovider')->paginate(10);
            $medicalProviders=[];
            $i=0;
            if($allmedicalProviders)
            {
                foreach ($allmedicalProviders as $medical)
                {
                    $user=MedicalProvider::where('user_id','=',$medical->id)->get();
                    if($user)
                    {
                        $medicalProviders[$i]=$user[0];
                        $medicalProviders[$i]['name']=$medical->name;
                        $i++;
                    }
                }
            }
            return Voyager::view('vendor.voyager.requests.paginate_medical', compact('allmedicalProviders','medicalProviders'))->render();
        }
        else if($request->get('type') == 3) {
            $query = $request->get('query') !== null ? $request->get('query') : "";
            $doctors = DB::table('doctor_has_medical_provider')->where('medical_provider_id', '=', $request->get('medical_provider'))->paginate(10);
            if ($doctors) {
                $doctor_from_doctors = [];
                $i = 0;
                foreach ($doctors as $id) {
                    $doctor = Doctor::find($id->doctor_id);
                    if ($doctor) {
                        $doctor_from_doctors[$i] = $doctor;
                        $i++;
                    }
                }
                $alldoctors = [];
                $j=0;
                for ($i = 0; $i < count($doctor_from_doctors); $i++) {
                    $doctor = User::where('fullname', 'LIKE', "%{$query}%")->where('id', '=', $doctor_from_doctors[$i]->user_id)->where('disabled', '=', 0)->where('deleted_at' , "=",null)->get();
                    if (!$doctor->isEmpty()) {
                        $alldoctors[$j] = $doctor_from_doctors[$i];
                        $alldoctors[$j]['name'] = $doctor[0]->name;
                        $j++;
                    }
                }
                return Voyager::view('vendor.voyager.requests.paginate_doctor', compact('alldoctors', 'doctors'))->render();
            }
        }
        else if($request->get('type') == 4) {
              $query = $request->get('query') !== null ? $request->get('query') : "";
            $allServices = DB::table('medical_provider_has_specialties')
                ->join('medical_provider_specialty_has_services', 'medical_provider_has_specialties.id', '=', 'medical_provider_specialty_has_services.medical_provider_has_speciality_id')
                ->join('services', 'services.id', '=', 'medical_provider_specialty_has_services.service_id')
                ->where('medical_provider_id' ,$request->get('medical_provider'))
                ->where('services.deleted_at', '=', Null)->where('services.disabled','=',0)
                ->where('services.name_ar' ,'like' , '%'.$query.'%')
                ->select([DB::RAW('DISTINCT(services.id)'), 'services.name_ar', 'services.name_en'])
                ->paginate(10);
                return Voyager::view('vendor.voyager.requests.paginate_service', compact('allServices'))->render();
        }
    }
    public function requestSearch(Request $request)
    {
        $requestDateSearch = $request->requestDate;
        $medicalSearch = $request->medical;
        if (preg_match('/[اأإء-ي]/ui', $medicalSearch)) {
            $medical_name_ar = $medicalSearch ;
            $medical_name_en = '';
        } else {
            $medical_name_en = $medicalSearch ;
            $medical_name_ar = '';
        }
        $patientSearch = $request->patient;
        $doctorSearch = $request->doctor;
        $requestStatusSearch = $request->requestStatus;
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = "requests";

        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object) ['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%'.$search->value.'%';
                $query->where($search->key, $search_filter, $search_value);
            }

            if ($orderBy && in_array($orderBy, $dataType->fields())) {
                $querySortOrder = (!empty($sortOrder)) ? $sortOrder : 'desc';
                $requestdata = call_user_func([
                    $query->orderBy($orderBy, $querySortOrder),
                    $getter,
                ]);
            } elseif ($model->timestamps) {
                $requestdata = call_user_func([$query->latest($model::CREATED_AT), $getter]);
            } else {
                $requestdata = call_user_func([$query->orderBy($model->getKeyName(), 'DESC'), $getter]);
            }

            // Replace relationships' keys for labels and create READ links if a slug is provided.
            $requestdata = $this->resolveRelations($requestdata, $dataType);

        } else {
            // If Model doesn't exist, get data from table name
            $requestdata = call_user_func([DB::table($dataType->name), $getter]);
            $model = false;
        }

        // Check if BREAD is Translatable
        if (($isModelTranslatable = is_bread_translatable($model))) {
            $requestdata->load('translations');
        }
        $query = requestModel::query();
        if($requestDateSearch!='') {
            $query->where('date', $requestDateSearch);
        }
        if($requestStatusSearch!='') {
            $query->where('status', $requestStatusSearch);
        }
        $query->wherehas('medical_provider' ,function($query) use ( $medical_name_ar , $medical_name_en)
        {
            if($medical_name_ar!='') {
                $query->wherehas('userRequest' ,function($query) use ( $medical_name_ar )
                {
                    $query->where('fullname', 'like' , '%'.$medical_name_ar.'%');
                });
            }
            if($medical_name_en!='') {
                $query->wherehas('userRequest' ,function($query) use ( $medical_name_en )
                {
                    $query->where('fullname_en', 'like' , '%'.$medical_name_en.'%');
                });
            }

        });
        $query->wherehas('patient' ,function($query) use ( $patientSearch )
        {
            if($patientSearch!='') {
                $query->wherehas('userRequest' ,function($query) use ( $patientSearch )
                {
                    $query->where('name', 'like' , '%'.$patientSearch.'%');
                });
            }
        });
        $query->wherehas('doctor' ,function($query) use ( $doctorSearch )
        {
            if($doctorSearch!='') {
                $query->wherehas('userRequest' ,function($query) use ( $doctorSearch )
                {
                    $query->where('fullname', 'like' , '%'.$doctorSearch.'%')->orWhere('fullname_en', 'like' , '%'.$doctorSearch.'%');
                });
            }
        });
        $requestdata = $query->paginate(10);
        $requestdata->appends(['requestDate' => $requestDateSearch ,'medical' =>$medicalSearch ,'patient'=>$patientSearch,'requestStatus'=>$requestStatusSearch]);
        //$requestdata=requestModel::where('date',$requestDateSearch)->where('status',$requestStatusSearch)->orderBy('id', 'DESC')->paginate(10);
        $dataTypeContent=[];
        $i=0;
        foreach ($requestdata as $data)
        {
            $dataTypeContent[$i]=$data;
            $patient=Patient::where("id","=",$data->patient_id)->get();
            if($patient)
            {
                $patient=$patient->toArray();
                $patientuser=User::withTrashed()->find($patient[0]['user_id']);
                $dataTypeContent[$i]['patient_name']=$patientuser['name'];
            }
            $doctor=Doctor::where("id","=",$data->doctor_id)->get();
            if($doctor)
            {
                $doctor=$doctor->toArray();
                $doctoruser=User::withTrashed()->find($doctor[0]['user_id']);
                $dataTypeContent[$i]['doctor_name']=$doctoruser->fullname_en;
            }
            $medical=MedicalProvider::where("id","=",$data->medical_provider_id)->get();
            if($medical)
            {
                $medical=$medical->toArray();
                $medicaluser=User::withTrashed()->find($medical[0]['user_id']);
                $dataTypeContent[$i]['medical_name']=$medicaluser->fullname_en;
            }
            $appointment=Appointment::where("request_id","=",$data->id)->get();
            if($appointment)
            {
                $appointment=$appointment->toArray();
            }
            $dataTypeContent[$i]['rating']="";
            $dataTypeContent[$i]['comment']="";
            if(!empty($appointment))
            {
                $review=Review::where("appointment_id","=",$appointment[0]['id'])->get();
                if(count($review)>0) {
                    $dataTypeContent[$i]['rating'] = $review[0]['rating'];
                    $dataTypeContent[$i]['comment'] = $review[0]['comment'];
                }
            }
            $dataTypeContent[$i]['date_time']=$data->date." ".$data->time;
            $dataTypeContent[$i]['date']=$data->date;
            $dataTypeContent[$i]['time']=$data->time;
            $i++;
        }
        // Check if server side pagination is enabled
        $isServerSide = isset($dataType->server_side) && $dataType->server_side;

        // Check if a default search key is set
        $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

        $view = 'voyager::bread.browse';

        if (view()->exists("voyager::$slug.browse")) {
            $view = "voyager::$slug.browse";
        }
        $actions = [];
        if (!empty($dataTypeContent) &&!empty($dataTypeContent['0']->first())) {
            foreach (Voyager::actions() as $action) {
                $action = new $action($dataType, $dataTypeContent['0']->first());

                if ($action->shouldActionDisplayOnDataType()) {
                    $actions[] = $action;
                }
            }
        }
        return Voyager::view($view, compact(
            'dataType',
            'dataTypeContent',
            'isModelTranslatable',
            'search',
            'orderBy',
            'orderColumn',
            'sortOrder',
            'searchable',
            'isServerSide',
            'defaultSearchKey',
            'requestdata',
            'requestDateSearch',
            'medicalSearch',
            'patientSearch',
            'requestStatusSearch',
            'doctorSearch',
            'actions'
        ));
    }
}
