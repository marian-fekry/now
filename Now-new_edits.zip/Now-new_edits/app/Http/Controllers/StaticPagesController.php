<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Auth;
use App\Staticpage;
use App\User;
class StaticPagesController extends Controller
{
    use OutPut;

  public function __construct()
  {
      $this->middleware('auth:api');
  }
  public function getpage(Request $request,$slug){
      $valid=Validator::make($request->all(),[
      'slug'=>'required|Unique:staticpages|string',
    ]);
    if(!isset($slug)||empty($slug)){
      return OutPut::Response('',__('messages.get_page_error'),505);
    }

    $lang=(Auth::user()->token()->user_lang=='en')?Auth::user()->token()->user_lang:'ar';
    $page= new Staticpage;
    $pageData=$page->getpage($slug,$lang);

    return OutPut::Response($pageData,'',200);
  }

}
