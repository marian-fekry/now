<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Auth;
use App\MedicalProvider;
use App\Request as requestModel;
use App\User;
use App\Patient;
use App\Doctor;
use App\Notification ;
use DB;
use Carbon\Carbon ;
class RequestController extends Controller
{

  use OutPut;

  public function __construct()
  {
      $this->middleware('auth:api');
  }
  public function addrequest(Request $request){
    if(Auth::user()->hasPermission('add_requests')){
      // doctor id -provider id -> add one request
      // search parameters ->make bulk request
        $user=Auth::user();
        // set the user current Language
        app()->setLocale($user->token()->user_lang);
      $valid=Validator::make($request->all(),[
        //profile data validation
        'doctor_id'=>'required|Filled|numeric',
        'provider_id'=>'required|Filled|numeric',
        'service_id'=>'required|Filled|numeric',
        'date'=>'date_format:Y-m-d|required|Filled',
        'time'=>'date_format:H:i:s|required|Filled',
      ]);

      if($valid->fails()){
        return OutPut::Response('',$valid->Errors(),403);
      }

      // adding the request
      $req=new \App\Request;
      $patient=Patient::where('user_id',$user->id)->first();
      $existsRequest = \App\Request::where('patient_id',$patient->id)->where('doctor_id', $request->input('doctor_id'))->where('service_id', $request->input('service_id'))->where('medical_provider_id', $request->input('provider_id'))->where('status' , '!=' , 'Confirm')->where('status' , '!=' , 'Canceled')->where('status' , '!=' , 'Expired')->first();
      if(!$existsRequest) {
          $requestresponse = $req->addrequest($patient->id, $request->input('doctor_id'), $request->input('provider_id'), $request->input('service_id') , $request->input('date'), $request->input('time'));
          if ($requestresponse) {
              return OutPut::Response('', __('messages.request_added_successful'), 200);
          } else {
              return OutPut::Response('', __('messages.adding_request_error'), 403);
          }
      }
      else {
          return OutPut::Response('', __('messages.repeated_request'), 403);
      }
    }else{
      return OutPut::Response('',__('messages.auth_error'),401);
    }
  }

    public function addbulkrequest(Request $request){
        if(Auth::user()->hasPermission('add_requests')){
            $user=Auth::user();
            app()->setLocale($user->token()->user_lang);

            // doctor id -provider id -> add one request
            // search parameters ->make bulk request
            $valid=Validator::make($request->all(),[
                'doctor_name'=>'Filled',
                'degree'=>'Filled|numeric',
                'region'=>'required|Filled|numeric',
                'governrate'=>'required|Filled|numeric',
                'specialty'=>'required|Filled|numeric',
                'service' => 'required|Filled|numeric',
                'min_price'=>'required_with:max_price|Filled|numeric',
                'max_price'=>'required_with:min_price|Filled|numeric',
                'request_date'=>'required|Filled|date|date_format:Y-m-d',
                'request_time'=>'required|date_format:H:i:s',
            ]);

            if($valid->fails()){
                return OutPut::Response('',$valid->Errors(),403);
            }

            // setting the variables

            $doctor_name = $request->input('doctor_name',0);
            $specialty_id = $request->input('specialty',0);
            $region_id = $request->input('region',0);
            $governrate_id= $request->input('governrate',0);
            $degree_id=$request->input('degree',0);
            $service_id=$request->input('service',0);
            $minPrice=$request->input('min_price',0);
            $maxPrice=$request->input('max_price',0);
            $requestDate =$request->input('request_date',0);
            $requestTime =$request->input('request_time',0);
            // adding the request
            $medicalprovider=new MedicalProvider;
            $patient=Patient::where('user_id',$user->id)->first();
            $doctorsresponse=$medicalprovider->liteDoctorsSearch($doctor_name , $specialty_id , $region_id , $governrate_id ,$degree_id , $service_id ,$minPrice , $maxPrice , $patient->id );
            $medicalArray=[];
            foreach ($doctorsresponse as $medical) {
                array_push($medicalArray , $medical['provider_id']);
            }
            $medicals =\App\GoverneratesTimeReservations::where('governrate_id', $governrate_id)
                ->wherehas('subscriptionOrder' ,function($q) use ($medicalArray){
                    $q->where('status','Active')->where('disabled',0);
                    $q->whereIn('medical_provider_id',$medicalArray);
                })->orderBy('from', 'asc')->get();
            $medicalNewTimeArray=[];
            $s=0;
            foreach ($medicals as $medical){
                if($s==0){
                    $newFromTime=0;
                    $newToTime=$newFromTime +($medical->to - $medical->from);
                }
                else{
                    $newFromTime=$newToTime+1;
                    $newToTime=$newFromTime +($medical->to - $medical->from);
                }
                array_push($medicalNewTimeArray , ['medical_id'=>$medical->medical_provider_id , 'from'=>$newFromTime , 'to'=>$newToTime]);
               $s++;
            }
            if(!empty($doctorsresponse)){
                $i=0;
                $req=new \App\Request;
                $group=str_random(30);
                foreach($doctorsresponse AS $doctor){
                    $requestExists = \App\Request::where('patient_id',$patient->id )
                        ->where('doctor_id',$doctor['doctor_id'])
                        ->where('medical_provider_id',$doctor['provider_id'])
                        ->where(function($q) {
                            $q->where('status','=','Request')
                                ->orWhere(function($q) {
                                    $q->where('status','=','Approve');
                                });
                        })->count();
                    if($requestExists==0) {
                      //                        $requestSubscriptionOrders= \App\SubscriptionOrder::where('subscription_plan_id',3)
                      //                            ->where('status','Active')->where('disabled',0)
                      //                            ->where('medical_provider_id',$doctor['provider_id'])
                      //                            ->wherehas('requestOrder' ,function($q) use ($governrate_id) {
                      //                                $q->where('governrate_id', $governrate_id);
                      //                            })->first();
                        $requestSubscriptionOrders = array_search($doctor['provider_id'], array_column($medicalNewTimeArray, 'medical_id'));
                        if($requestSubscriptionOrders !== false) {
                             $sendDateTime= Carbon::now()->addMinutes($medicalNewTimeArray[$requestSubscriptionOrders]['from']);
                        }
                        else{
                      //                            $requestOrders =\App\GoverneratesTimeReservations::where('governrate_id', $governrate_id)
                      //                                ->wherehas('subscriptionOrder' ,function($q) use ($medicalArray){
                      //                                    $q->where('status','Active')->where('disabled',0);
                      //                                    $q->whereIn('medical_provider_id',$medicalArray);
                      //                                })->orderBy('to', 'desc')->first();
                            $requestOrders = end($medicalNewTimeArray);
                            if($requestOrders) {
                                $from=$requestOrders['to'] + 1;
                                $sendDateTime= Carbon::now()->addMinutes($from);
                            }
                            else {
                                $sendDateTime=Carbon::now();
                            }
                        }
                        $bulkRequestQueue = \App\BulkRequestQueueTasks::where('patient_id',$patient->id )
                            ->where('doctor_id',$doctor['doctor_id'])
                            ->where('medical_provider_id',$doctor['provider_id'])
                            ->count();
                        if($bulkRequestQueue==0){
                            $req->addbulkRequestQueue($patient->id, $doctor['doctor_id'], $doctor['provider_id'], $service_id ,$requestDate, $requestTime, $group,$sendDateTime);
                        }
                        $i++;
                    }
                }
                if($i>0) {
                    return OutPut::Response('',__('messages.requests_added_successful' ,  ['requestsCounter' => $i ]),200);
                }
                else {
                    return OutPut::Response('',__('messages.no_request'),403 );
                }
            }else{
                return OutPut::Response('',__('messages.no_result'),403);
            }

        }else{
            return OutPut::Response('',__('messages.auth_error'),401);
        }
    }

  public function addbulkrequestOld(Request $request){
    if(Auth::user()->hasPermission('add_requests')){
        $user=Auth::user();
        app()->setLocale($user->token()->user_lang);

      // doctor id -provider id -> add one request
      // search parameters ->make bulk request
      $valid=Validator::make($request->all(),[
          'doctor_name'=>'Filled',
          'degree'=>'Filled|numeric',
          'region'=>'required|Filled|numeric',
          'governrate'=>'required|Filled|numeric',
          'specialty'=>'required|Filled|numeric',
          'service' => 'required|Filled|numeric',
          'min_price'=>'required_with:max_price|Filled|numeric',
          'max_price'=>'required_with:min_price|Filled|numeric',
          'request_date'=>'required|Filled|date|date_format:Y-m-d',
          'request_time'=>'required|date_format:H:i:s',
          ]);

      if($valid->fails()){
        return OutPut::Response('',$valid->Errors(),403);
      }

      // setting the variables

        $doctor_name = $request->input('doctor_name',0);
        $specialty_id = $request->input('specialty',0);
        $region_id = $request->input('region',0);
        $governrate_id= $request->input('governrate',0);
        $degree_id=$request->input('degree',0);
        $service_id=$request->input('service',0);
        $minPrice=$request->input('min_price',0);
        $maxPrice=$request->input('max_price',0);
        $requestDate =$request->input('request_date',0);
        $requestTime =$request->input('request_time',0);
      // adding the request
      $medicalprovider=new MedicalProvider;
      $patient=Patient::where('user_id',$user->id)->first();
      $doctorsresponse=$medicalprovider->liteDoctorsSearch($doctor_name , $specialty_id , $region_id , $governrate_id ,$degree_id , $service_id ,$minPrice , $maxPrice , $patient->id );
      $medicalArray=[];
      foreach ($doctorsresponse as $medical) {
        array_push($medicalArray , $medical['provider_id']);
      }
      if(!empty($doctorsresponse)){
          $i=0;
        $req=new \App\Request;
          $group=str_random(30);
        foreach($doctorsresponse AS $doctor){
            $patientIdLabel ='patientIdLabel'.$patient->id;
            $doctorIdLabel='doctorIdLabel'.$doctor['doctor_id'];
            $medicalIdLabel='medicalIdLabel'.$doctor['provider_id'];
            $groupLabel='groupLabel'.$group;
            $requestExists = \App\Request::where('patient_id',$patient->id )
               ->where('doctor_id',$doctor['doctor_id'])
               ->where('medical_provider_id',$doctor['provider_id'])
                ->where(function($q) {
                  $q->where('status','=','Request')
                      ->orWhere(function($q) {
                          $q->where('status','=','Approve');
                      });
              })->count();
          if($requestExists==0) {
              $requestSubscriptionOrdersGov= \App\SubscriptionOrder::where('subscription_plan_id',3)
                  ->where('status','Active')->where('disabled',0)
                  ->wherehas('requestOrder' ,function($q) use ($governrate_id) {
                      $q->where('governrate_id', $governrate_id);
                  })->count();
              if($requestSubscriptionOrdersGov >0 ) {
                  $requestSubscriptionOrders= \App\SubscriptionOrder::where('subscription_plan_id',3)
                      ->where('status','Active')->where('disabled',0)
                      ->where('medical_provider_id',$doctor['provider_id'])
                      ->wherehas('requestOrder' ,function($q) use ($governrate_id) {
                          $q->where('governrate_id', $governrate_id);
                      })->first();
                  if($requestSubscriptionOrders) {
                      if($requestSubscriptionOrders->requestOrder->from == 0) {
                          //SendRequest::dispatch($user->id,$patient->id,$doctor['doctor_id'],$doctor['provider_id'] , $requestDate ,$requestTime ,$group,'Request',$patientIdLabel,$doctorIdLabel,$medicalIdLabel,$groupLabel);
                          $req->addrequest($patient->id,$doctor['doctor_id'],$doctor['provider_id'] , $service_id ,$requestDate ,$requestTime ,$group);
                      }
                      else{
                          //SendRequest::dispatch($user->id,$patient->id,$doctor['doctor_id'],$doctor['provider_id'] , $requestDate ,$requestTime ,$group,'Request',$patientIdLabel,$doctorIdLabel,$medicalIdLabel,$groupLabel)->delay(now()->addMinutes($requestSubscriptionOrders->requestOrder->from));
                          $req->addrequest($patient->id,$doctor['doctor_id'],$doctor['provider_id'] , $service_id , $requestDate ,$requestTime ,$group,'Waiting',$requestSubscriptionOrders->requestOrder->from);
                      }
                  }
                  else
                  {
                      $requestOrders =\App\GoverneratesTimeReservations::where('governrate_id', $governrate_id)
                          ->wherehas('subscriptionOrder' ,function($q) use ($medicalArray){
                              $q->where('status','Active')->where('disabled',0);
                              $q->whereIn('medical_provider_id',$medicalArray);
                          })->orderBy('to', 'desc')->first();
                      if($requestOrders) {
                          $endTime=$requestOrders->to + 1;
                      }
                      else {
                          $endTime=0;
                      }
                      $req->addrequest($patient->id,$doctor['doctor_id'],$doctor['provider_id'] , $service_id ,$requestDate ,$requestTime ,$group,'Waiting',$endTime);
                      //SendRequest::dispatch($user->id,$patient->id,$doctor['doctor_id'],$doctor['provider_id'] , $requestDate ,$requestTime ,$group,'Request',$patientIdLabel,$doctorIdLabel,$medicalIdLabel,$groupLabel)->delay(now()->addMinutes($endTime));
                  }
              }
              else {
                  //SendRequest::dispatch($user->id,$patient->id,$doctor['doctor_id'],$doctor['provider_id'] , $requestDate ,$requestTime ,$group,'Request',$patientIdLabel,$doctorIdLabel,$medicalIdLabel,$groupLabel);
                  $req->addrequest($patient->id,$doctor['doctor_id'],$doctor['provider_id'] , $service_id ,$requestDate ,$requestTime ,$group);
              }
                $i++;
            }
        }
        if($i>0) {
            return OutPut::Response('',__('messages.request_added_successful'),200);
        }
        else {
            return OutPut::Response('',__('messages.repeated_request'),403);
        }
      }else{
        return OutPut::Response('',__('messages.no_result'),403);
      }

    }else{
      return OutPut::Response('',__('messages.auth_error'),401);
    }
  }

  public function respondrequest(Request $request){
      $user=Auth::user();
      // set the user current Language
      app()->setLocale($user->token()->user_lang);
    if(Auth::user()->hasPermission('edit_requests')){
      // doctor id -provider id -> add one request
      // search parameters ->make bulk request
      $valid=Validator::make($request->all(),[
        'request_id'=>'required|Filled|numeric',
        'respond'=>'required|Filled|string',// respond can have 3 values y -n -r (reschedule)
        'date'=>'required_if:respond,r|Filled|date_format:Y-m-d',
        'time'=>'required_if:respond,r|Filled|date_format:H:i:s',
      ]);

      if($valid->fails()){
        return OutPut::Response('',$valid->Errors(),403);
      }

        $req=DB::table('requests')->where('id', $request->input('request_id'))->first();
      //$req=App\Request::find($request->input('request_id'));
      if(!empty($req)){
          $obj= new requestModel();

        if($user->hasRole('ROLE_PATIENT') && $user->userCanRespondRequest($user,$req)) {
          if($request->input('respond')=='y'){

            if ($req->status!='Confirm') {
              if($obj->confirmrequest($req->id,$user)===false){
                return OutPut::Response('',__('messages.time_passed'),200);
              }
            }
            return OutPut::Response('',__('messages.confirm_successful'),200);
          }else if ($request->input('respond')=='n'){
            if ($req->status!='Canceled') {
              $obj->cancelRequest($req->id); // change status of request to approve
            }

           return OutPut::Response('',__('messages.request_cancelled'),200);
          }else{
            return OutPut::Response('',__('messages.unknown_response'),403);
          }
        }else if (($user->hasRole('ROLE_DOCTOR')||$user->hasRole('ROLE_SECRETARY')
                 ||$user->hasRole('ROLE_PRIVATE_RESERVATION')||$user->hasRole('ROLE_HOSPITAL')
                 ||$user->hasRole('ROLE_PRIVATE_CLINIC')||$user->hasRole('ROLE_SHARED_CLINIC')
                 ||$user->hasRole('ROLE_MEDICAL_PROVIDER')) && $user->userCanRespondRequest($user,$req)){
          if($request->input('respond')=='y'){

            if ($req->status!='Approve') {
              if($obj->approverequest($req->id,$user)===false){
                return OutPut::Response('',__('messages.time_passed'),200);
              }
            }
            return OutPut::Response('',__('messages.approve_successful'),200);
          }else if ($request->input('respond')=='n'){
            if ($req->status!='Canceled') {
              $obj->cancelRequest($req->id); // change status of request to cancel
            }
            return OutPut::Response('',__('messages.request_cancelled'),200);
          }else if ($request->input('respond')=='r'){
              $obj->reschedulerequest($req->id,$request->input('date'),$request->input('time'));

            return OutPut::Response('',__('messages.reschedule_successful'),200);
          }else{
            return OutPut::Response('',__('messages.unknown_response'),403);
          }
        }else{
          return OutPut::Response('',__('messages.auth_error'),403);
        }
      }else{
        return OutPut::Response('',__('messages.request_not_found'),403);
      }




    }else{
      return OutPut::Response('',__('messages.auth_error'),401);
    }
  }

  public function ViewRequests(Request $request)
  {
      $user_id=Auth::id();
      $user=Auth::user();
      $type=$request->input('type','');
      $obj= new requestModel();
      if($user->isPatient())
      {
          if(Auth::user()->hasPermission('browse_requests')==1) {
            if($type=="new"){
              $newRequests=$obj->get_requests_patient();
              return OutPut::Response($newRequests,'',200);

            }else if($type=="current"){
              $currentRequests=$obj->get_current_requests_patient();
              return OutPut::Response($currentRequests,'',200);
            }else if ($type="old"){
              $oldRequests=$obj->get_old_requests_patient();
              return OutPut::Response($oldRequests,'',200);
            }else{
              return OutPut::Response('',__('messages.undefiend_request_type'),403);
            }
          } else {
              return OutPut::Response('',__('messages.auth_error'),401);
          }
      }
      else if($user->isMedicalProvider() || $user->isPrivateClinic() || $user->isSharedClinic() || $user->isHospital() )
      {
           if(Auth::user()->hasPermission('browse_requests')==1) {


                if($type=="new"){
                  $newRequests=$obj->get_requests_medicalProvider();
                  return OutPut::Response($newRequests,'',200);

                }else if($type=="current"){
                  $currentRequests=$obj->get_current_requests_medicalProvider();
                  return OutPut::Response($currentRequests,'',200);
                }else if ($type="old"){
                  $oldRequests=$obj->get_old_requests_medicalProvider();
                  return OutPut::Response($oldRequests,'',200);
                }else{
                  return OutPut::Response('',__('messages.undefiend_request_type'),403);
                }
              } else {
                  return OutPut::Response('',__('messages.auth_error'),401);
              }
      }
      else if($user->isDoctor()) {
          $doctorRequests=$obj->getDoctorsRequests($type);
          return OutPut::Response($doctorRequests,'',200);
      }
      else if($user->isSecretary()) {
          $doctorRequests=$obj->getDoctorsRequests($type , true);
          return OutPut::Response($doctorRequests,'',200);
      }
      else if($user->isPrivateReservation()) {
          $privateReservationRequests=$obj->getPrivateReservationRequests($type , true);
          return OutPut::Response($privateReservationRequests,'',200);
      }

  }

  public function medicalProviderInfo (Request $request)
  {
      $user=Auth::user();
      app()->setLocale($user->token()->user_lang);

      if(!$user->id) {
          return OutPut::Response('','couldn\'t found you request',505);
      }
      $valid=Validator::make($request->all(),[
          'request_id'=>'required|Filled|numeric',
      ]);


      if($valid->fails()){
          return OutPut::Response('',$valid->Errors(),403);
      }
      $requestId = $request->input('request_id');
      $requestInfo = requestModel::find($requestId);
      if(!$requestInfo) {
          return OutPut::Response('',$valid->Errors(),403);
      }
      $obj= new requestModel();
      $medicalProviderInfo = $obj->medicalProviderInfo($requestInfo);
      return OutPut::Response($medicalProviderInfo,'',200);


  }
}
