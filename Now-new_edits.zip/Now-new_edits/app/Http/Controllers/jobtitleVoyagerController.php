<?php

namespace App\Http\Controllers;
use App\Jobtitle;
use App\Patient;
use Exception;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use phpDocumentor\Reflection\Types\Array_;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
use TCG\Voyager\Http\Controllers\VoyagerBaseController as BaseVoyagerController;
use Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Carbon\Carbon ;

class jobtitleVoyagerController extends BaseVoyagerController
{
    public function index(Request $request)
    {

        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();
        // Check permission

        $this->authorize('browse', app($dataType->model_name));
        $getter = $dataType->server_side ? 'paginate' : 'get';
        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');
            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');
            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            //$dataTypeContent= DB::table('jobtitles')->orderBy("id","desc")->where('deleted_at' , '=' , Null)->paginate(10);
            $dataTypeContent=Jobtitle::orderBy("id","desc")->where('deleted_at' , '=' , Null)->paginate(10);
            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }

            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;
            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;
            $view = "vendor.voyager.jobtitles.browse";
            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($dataTypeContent->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $dataTypeContent->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }

            return Voyager::view($view, compact(
                'actions',
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }

    public function Deletejobtitles(Request $request)
    {

        $ids = [];
        // Bulk delete, get IDs from POST
        $ids =  $request->row_id;
        foreach($ids as $id)
        {
            if(!empty($id)) {
                $user = Jobtitle::find($id);
                if ($user->doctors()->count() > 0) {
                    return 'false' ;
                }
                $user->deleted_at = Carbon::now();
                $user->save();
            }
        }
        return 'true';

    }
    public function delete_single($id)
    {
        $jobTitle = Jobtitle::find($id);
        if ($jobTitle->doctors()->count() > 0) {
            throw new Exception(__('messages.this_jobtitle_have_doctors') , '23000');
        }
        $jobTitle->deleted_at = Carbon::now();
        $jobTitle->save();
        $previousUrl = explode('page=' , url()->previous());
        $page = $previousUrl['1'] ?? 1 ;
        return redirect()->route("voyager.jobtitles.index" ,['page'=>$page]);
    }

    public function joptitleDeactivate($id)
    {
        $jobTitle = Jobtitle::find($id);
        $jobTitle->disabled = 1;
        $jobTitle->save();
        $previousUrl = explode('page=' , url()->previous());
        $page = $previousUrl['1'] ?? 1 ;
        return redirect()->route("voyager.jobtitles.index" , ['page'=>$page]);
    }

    public function joptitleActivate($id)
    {
        $jobTitle = Jobtitle::find($id);
        $jobTitle->disabled = 0;
        $jobTitle->save();
        $previousUrl = explode('page=' , url()->previous());
        $page = $previousUrl['1'] ?? 1 ;
        return redirect()->route("voyager.jobtitles.index" , ['page'=>$page]);
    }
    public function jobtitleSearch(Request $request)
    {

        $nameArSearch = $request->name_ar;
        $nameEnSearch = $request->name_en;
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = "jobtitles";
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();
        // Check permission

        $this->authorize('browse', app($dataType->model_name));
        $getter = $dataType->server_side ? 'paginate' : 'get';
        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');
            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');
            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $dataTypeContent= DB::table('jobtitles')->orderBy("id","desc")->where('deleted_at' , '=' , Null)->where('name_ar','like' ,'%'.$nameArSearch.'%')->where('name_en','like','%'.$nameEnSearch.'%')->paginate(10);
            $dataTypeContent->appends(['name_ar' => $nameArSearch ,'name_en' =>$nameEnSearch ]);

            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }

            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;
            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;
            $view = "vendor.voyager.jobtitles.browse";
            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }


            return Voyager::view($view, compact(
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'nameArSearch',
                'nameEnSearch'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
}
