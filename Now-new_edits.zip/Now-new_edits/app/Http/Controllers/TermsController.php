<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Auth;
use App\Staticpage;
use App\User;

class TermsController extends Controller
{
    use OutPut;

    public function getTerms (Request $request,$slug){
      $valid=Validator::make($request->all(),[
        'slug'=>'required|Unique:staticpages|string',
      ]);
      if(!isset($slug)||empty($slug)){
        return OutPut::Response('',__('messages.get_page_error'),505);
      }

      $lang=$request->lang;
      $page= new Staticpage;
      $pageData=$page->getpage($slug,$lang);

      return OutPut::Response($pageData,'',200);
    }
}
