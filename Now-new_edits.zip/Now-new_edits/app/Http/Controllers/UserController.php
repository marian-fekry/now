<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
use Validator;
use App\MedicalProvider;
class UserController extends Controller
{
  use OutPut;

  public function __construct()
  {
      $this->middleware('auth:api');
  }
  public function uploadimage(Request $request){
      $user=Auth::user();
      app()->setLocale($user->token()->user_lang);
    $valid=Validator::make($request->all(),[
      'image'=>'required|string',
    ]);
    if($valid->fails()){
      return OutPut::Response('',$valid->Errors(),403);
    }
    $image=$request->image;
    $image=str_replace('data:image/png;base64,','',$image);
    $image=str_replace(' ','+',$image);
    $imageName=str_random(15).'.'.'png';
    \File::put(storage_path().'/app/public/users/'.$imageName,base64_decode($image));
    //$Image=request()->file('image')->store('/public/images');

    $user=new User;
    $userResponse=$user->changeUserImage(Auth::user()->id,$imageName);
    if($userResponse){
      return OutPut::Response(array("image"=>url('/').'/storage/users/'.$imageName),__('messages.image_change_successful'),200);
    }else{
      return OutPut::Response('',__('messages.image_change_error'),403);
    }
  }

  public function KeepLogin(Request $request)
    {
        $valid=Validator::make($request->all(),[
            'email'=>'required|string',
        ]);
        if($valid->fails()){
            return OutPut::Response('',$valid->Errors(),403);
        }
        $user=Auth::user();
        if($request->email==$user->email)
        {
            $userRole='';
            if($user->isPatient()){
                $userRole='patient';
            }else if($user->isDoctor()){
                $userRole='doctor';
            }else if($user->isSecretary()){
                $userRole='secretary';
            }else if($user->isPrivateReservation()){
                $userRole='private_reservation';
            }else if($user->isHospital()){
                $userRole='hospital';
            }else if($user->isSharedClinic()){
                $userRole='shared_clinic';
            }else if($user->isPrivateClinic()){
                $userRole='private_clinic';
            }else if($user->isMedicalProvider()){
                $userRole='medical_provider';
            }
            if($user->verified==1){
                if($userRole=='doctor'){
                    $doctor=\App\Doctor::where('user_id',$user->id)->with('speciality')->with('jobTitle')->first();
                    $doctorspecialty='';
                    $doctorjobtitle='';
                    if(null!==$doctor){
                        $doctorspecialty=($user->token()->user_lang=='ar')?$doctor->speciality->name_ar:$doctor->speciality->name_en;
                        $doctorjobtitle=($user->token()->user_lang=='ar')?$doctor->jobTitle->name_ar:$doctor->jobTitle->name_en;
                    }


                    return OutPut::Response([
                        "name"=> $user->fullname,
                        "name_en"=> $user->fullname_en,
                        "email"=> $user->email,
                        "doctorspecialty"=>  $doctorspecialty,
                        "doctorjobtitle"=>  $doctorjobtitle,
                        "lang"=>  $user->token()->user_lang,
                        "image"=>url('/').'/storage/'.$user->avatar,
                        "id"=> $user->id,
                        "type"=>$userRole,
                         "notifications"=>$user->notifications],'',200);
                }else if($userRole=='private_clinic'){
                    $doctor=\App\Doctor::where('user_id',$user->id)->with('jobTitle')->first();

                    $doctorjobtitle='';
                    if(null!==$doctor){
                        $doctorjobtitle=($user->lang=='ar')?$doctor->jobTitle->name_ar:$doctor->jobTitle->name_en;
                    }
                    return OutPut::Response([
                        "name"=> $user->fullname,
                        "name_en"=> $user->fullname_en,
                        "email"=> $user->email,
                        "birthdate"=>  $user->birthdate,
                        "gender"=>  $user->gender,
                        "mobile"=>  $user->mobile,
                        "lang"=>  $user->token()->user_lang,
                        "image"=>url('/').'/storage/'.$user->avatar,
                        "id"=> $user->id,
                        "doctorjobtitle"=>  $doctorjobtitle,
                        "type"=>$userRole,
                        "notifications"=>$user->notifications],'',200);


                }
                else if($userRole=='hospital' || $userRole=='shared_clinic' || $userRole=='medical_provider') {
                    return OutPut::Response([
                        "name"=> $user->fullname,
                        "name_en"=> $user->fullname_en,
                        "email"=> $user->email,
                        "birthdate"=>  $user->birthdate,
                        "gender"=>  $user->gender,
                        "mobile"=>  $user->mobile,
                        "lang"=>  $user->token()->user_lang,
                        "image"=>url('/').'/storage/'.$user->avatar,
                        "id"=> $user->id,
                        "type"=>$userRole,
                        "notifications"=>$user->notifications],'',200);
                }
                else{
                    return OutPut::Response([
                        "name"=> $user->name,
                        "email"=> $user->email,
                        "birthdate"=>  $user->birthdate,
                        "gender"=>  $user->gender,
                        "mobile"=>  $user->mobile,
                        "lang"=>  $user->token()->user_lang,
                        "image"=>url('/').'/storage/'.$user->avatar,
                        "id"=> $user->id,
                        "type"=>$userRole,
                        "notifications"=>$user->notifications],'',200);
                }

            }else{
                return OutPut::Response('',__('messages.verify_account'),403);
            }
        }
        else{
            return OutPut::Response('',__('messages.login_error'),403);
        }

    }
/*
  public function edit(Request $request){
    $user=Auth::user();
    if($user->isHospital() || $user->isHospital()){
      $hospital=new MedicalProvider;
      return $hospital->editHospital($request);
    }
  }
  */
}
