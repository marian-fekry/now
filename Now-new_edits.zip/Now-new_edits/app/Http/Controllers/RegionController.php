<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Region;
use Illuminate\Support\Facades\Auth;
class RegionController extends Controller
{
    //

    public function __construct()
    {
        $this->middleware('auth:api')->except(['index']);
    }

    public function index(Request $request)
    {
          $region=new Region();
          $regions = $region->index($request->lang);
        return OutPut::Response($regions,'',200);
    }
}
