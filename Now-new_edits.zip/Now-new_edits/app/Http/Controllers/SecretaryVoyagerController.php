<?php

namespace App\Http\Controllers;

use App\Doctor;
use App\Secretary;
use Exception;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Str;
use phpDocumentor\Reflection\Types\Array_;
use PhpParser\Comment\Doc;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
use TCG\Voyager\Http\Controllers\VoyagerBaseController as BaseVoyagerController;
use Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Mail;

class SecretaryVoyagerController extends BaseVoyagerController
{
    public function index(Request $request)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }

            $dataTypeContent=User::whereHas('secretary')->orderBy('id', 'DESC')->paginate(10);
            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;

            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

            $view = "vendor.voyager.secretaries.browse";

            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($dataTypeContent->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $dataTypeContent->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }

            return Voyager::view($view, compact(
                'actions',
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey'
            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
    public function update(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        // Compatibility with Model binding.
        $id = $id instanceof Model ? $id->{$id->getKeyName()} : $id;

        $data = call_user_func([$dataType->model_name, 'findOrFail'], $id);

        // Check permission
        $this->authorize('edit', $data);

        // Validate fields with ajax
//        $val = $this->validateBread($request->all(), $dataType->editRows, $dataType->name, $id);

//        if ($val->fails()) {
//            return response()->json(['errors' => $val->messages()]);
//        }
        $valid=Validator::make($request->all(),[
            'name' => [
                'required', 'Filled','regex:/^[\pL\s\-]+$/u' ,'string' ,
                Rule::unique('users')->ignore( $id),
            ],
            'email' => [
                'required', 'Filled','E-Mail', 'string' ,
                Rule::unique('users')->ignore( $id),
            ],
            'fullname' => [
                'required', 'Filled','regex:/^[\pL\s\-]+$/u','string' ,
            ],
        ])->validate();
//        if($valid->fails()) {
//            //return response()->json(['errors' => $valid->messages()]);
//            return redirect()->back()
//                ->withErrors( $valid->messages())
//                ->withInput();
//        }
        if (!$request->ajax()) {
            $insert=User::find($id);
            $insert->name=$request->name;
            $insert->fullname=$request->fullname;
            $insert->email=$request->email;
            $insert->gender=$request->gender;
            if($request->password != "")
            {
                $insert->password=bcrypt($request->password);
            }
            $insert->save();
            $user_id=User::where("id","=",$insert->id)->get();
            $secretary=Secretary::where("user_id","=",$user_id[0]->id)->get();
            $secretary[0]->doctor_id=$request->hidden_doctor;
            $secretary[0]->save();

            event(new BreadDataUpdated($dataType, $data));
            $countParametersUrl = count(explode('&', $request->redirects_to));
            if($countParametersUrl>1) {
                $parametersString = explode('?', $request->redirects_to);
                preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
                $parameterString = "";
                for ($i = 0; $i < $countParametersUrl; $i++) {
                    $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
                }
                $routeName = "secretary.search";
            }
            else{
                $previousUrl = explode('page=' , $request->redirects_to);
                $routeName = "voyager.secretaries.index";
                $parameterString= "page=";
                $parameterString.= $previousUrl['1'] ?? 1;
            }

            return redirect()
                ->route($routeName , [$parameterString])
                ->with([
                    'message'    => __('voyager::generic.successfully_updated')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function edit(Request $request, $id)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();
        $dataTypeContent = (strlen("App\User") != 0)
            ? app("App\User")->findOrFail($id)
            : DB::table('users')->where('id', $id)->first(); // If Model doest exist, get data from table name
        foreach ($dataType->editRows as $key => $row) {
            $dataType->editRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }
        $dataTypeContent->specifiDoctor=DB::table('secretaries')->Where("user_id","=",$dataTypeContent->id)->get();
        $dataTypeContent->userid=$dataTypeContent->specifiDoctor[0]->doctor_id;
        $doctors=Doctor::whereHas('user',function($query){
            return $query->where('deleted_at', '=', Null)->where('disabled','=',0);
        })->paginate(10);
        $alldoctors=[];
        $i=0;
        if($doctors)
        {
            foreach ($doctors as $doctor)
            {
                $user=User::where('id','=',$doctor->user_id)->get();
                if($user)
                {
                    $alldoctors[$i]=$doctor;
                    $alldoctors[$i]['name']=$user[0]->name;
                    $i++;
                }
            }
        }
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'edit');
        // Check permission

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        if(!is_null($request->old('hidden_doctor'))){
            $newdoctorName = Doctor::find($request->old('hidden_doctor'));
            $dataTypeContent['doctor_name']= $newdoctorName->user->fullname ;
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable','alldoctors','doctors'));
    }
    public function create(Request $request)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        $dataTypeContent = (strlen($dataType->model_name) != 0)
            ? new $dataType->model_name()
            : false;

        foreach ($dataType->addRows as $key => $row) {
            $dataType->addRows[$key]['col_width'] = isset($row->details->width) ? $row->details->width : 100;
        }
        $doctors=Doctor::whereHas('user',function($query){
            return $query->where('deleted_at', '=', Null)->where('disabled','=',0);
        })->paginate(10);
        $alldoctors=[];
        $i=0;
        if($doctors)
        {
            foreach ($doctors as $doctor)
            {
                $user=User::where('id','=',$doctor->user_id)->where('deleted_at' , "=",null)->get();
                if($user)
                {
                    $alldoctors[$i]=$doctor;
                    $alldoctors[$i]['name']=$user[0]->name;
                    $i++;
                }
            }
        }
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'add');

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);

        $view = 'voyager::bread.edit-add';

        if (view()->exists("voyager::$slug.edit-add")) {
            $view = "voyager::$slug.edit-add";
        }
        if(!is_null($request->old('add_doctor'))){
             $newdoctorName = Doctor::find($request->old('add_doctor'));
             $dataTypeContent['doctor_name']= $newdoctorName->user->fullname ;
        }

        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable','alldoctors','doctors'));
    }
    public function store(Request $request)
    {
        $slug = $this->getSlug($request);

        $dataType = Voyager::model('DataType')->where('slug','=', 'userstable')->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        // Validate fields with ajax
        $val = $this->validateBread($request->all(), $dataType->addRows);
        // if ($val->fails()) {
        //    return response()->json(['errors' => $val->messages()]);
        //}
        $valid=Validator::make($request->all(),[
            'name' => [
                'required', 'Filled','regex:/^[\pL\s\-]+$/u' ,'string' ,
                Rule::unique('users')->ignore( $request->user_id),
            ],
            'email' => [
                'required', 'Filled','E-Mail', 'string' ,
                Rule::unique('users')->ignore( $request->user_id),
            ],
            'fullname' => [
                'required', 'Filled','regex:/^[\pL\s\-]+$/u','string' ,
            ],
            'password' => [
                'required', 'Filled',
            ],
            'add_doctor' => [
                'required', 'Filled',
            ],
        ],["add_doctor.required"=>" Doctor Is Required","add_doctor.Filled"=>" Doctor Is Required"])->validate();
//        if($valid->fails()) {
//            return response()->json(['errors' => $valid->messages()]);
//        }
        if (!$request->has('_validate')) {
            $doctorExitst= Secretary::where('doctor_id', $request->add_doctor)->first();
            if($doctorExitst) {
                throw new Exception(__('messages.selected_doctor_have_another_secretary') , '23000');
            }
            $request['lang']='en';
            $request['verified']= 0;
            $request['disabled']= 0;
            $data = $this->insertUpdateData($request, $slug, $dataType->addRows, new $dataType->model_name());
            User::where('id', $data->id)->update(['token' => Str::random(32)]);
            $user_id=User::where("id","=",$data->id)->get();
            $newsecretary= new Secretary();
            $newsecretary->user_id=$user_id[0]->id;
            $newsecretary->doctor_id=$request->add_doctor;
            $newsecretary->save();
            DB::table('user_roles')->insert(
                ['user_id' => $user_id[0]->id,'role_id'=> 9]
            );
            Mail::to($user_id)->send(new \App\Mail\NewSecretary($request->email,$request->password,$request->fullname,$user_id[0]->token));


            event(new BreadDataAdded($dataType, $data));

            if ($request->ajax()) {
                return response()->json(['success' => true, 'data' => $data]);
            }

            return redirect()
                ->route("voyager.secretaries.index")
                ->with([
                    'message'    => __('voyager::generic.successfully_added_new')." {$dataType->display_name_singular}",
                    'alert-type' => 'success',
                ]);
        }
    }
    public function Deletesecretary(Request $request)
    {

        $ids = [];

        // Bulk delete, get IDs from POST
        $ids =  $request->row_id;
        foreach($ids as $id)
        {
            if(!empty($id)) {
                $user = User::find($id);
                if (!$user) {
                    return 'false';
                } else {
                    Secretary::where('id', $user->secretary->id)->update(['doctor_id' => 0]);
                    $user->delete();
                }
            }
        }
        return 'true';
    }
    public function delete_single($id)
    {
        $user = User::find($id);
        if ($user) {
            Secretary::where('id', $user->secretary->id)->update(['doctor_id' => 0]);
            $user->delete();
        }
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "secretary.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.secretaries.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return redirect()->route($routeName , [$parameterString]);
    }
    public function show(Request $request, $id)
    {
        $slug = $this->getSlug($request);
        $dataType = Voyager::model('DataType')->where('slug', '=', 'userstable')->first();

        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $dataTypeContent = call_user_func([$model, 'findOrFail'], $id);
        } else {
            // If Model doest exist, get data from table name
            $dataTypeContent = DB::table($dataType->name)->where('id', $id)->first();
        }

        // Replace relationships' keys for labels and create READ links if a slug is provided.
        $dataTypeContent = $this->resolveRelations($dataTypeContent, $dataType, true);
        $secretary=Secretary::where("user_id","=",$id)->get();
        $secretary=$secretary->toArray();
        $doctor=Doctor::find($secretary[0]['doctor_id']);
        $doctorfromuser=User::find($doctor->user_id);
        $doctorname=$doctorfromuser->name;
        // If a column has a relationship associated with it, we do not want to show that field
        $this->removeRelationshipField($dataType, 'read');

        // Check permission
        $this->authorize('read', $dataTypeContent);

        // Check if BREAD is Translatable
        $isModelTranslatable = is_bread_translatable($dataTypeContent);
        $view = 'voyager::bread.read';
        if (view()->exists("voyager::$slug.read")) {
            $view = "voyager::$slug.read";
        }
        $countParametersUrl = count(explode('&', url()->previous()));
        if($countParametersUrl>1) {
            $parametersString = explode('?', url()->previous());
            preg_match_all("/([^=&]+)=([^=&]*+)/", $parametersString['1'], $r);
            $parameterString = "";
            for ($i = 0; $i < $countParametersUrl; $i++) {
                $parameterString .= $r[1][$i] . "=" . $r[2][$i] . "&";
            }
            $routeName = "secretary.search";
        }
        else{
            $previousUrl = explode('page=' , url()->previous());
            $routeName = "voyager.secretaries.index";
            $parameterString= "'page=";
            $parameterString.= $previousUrl['1'] ?? 1;
        }
        return Voyager::view($view, compact('dataType', 'dataTypeContent', 'isModelTranslatable','doctorname' , 'routeName' , 'parameterString'));
    }
    function paginate_doctor(Request $request)
    {
        $querySearch = $request->get('query') !== null ? $request->get('query') : "";
        $doctors=Doctor::whereHas('user',function($query) use ($querySearch) {
            $query->where('fullname', 'LIKE', "%{$querySearch}%")->orWhere('fullname_en', 'LIKE', "%{$querySearch}%")->where('disabled', '=', 0);
        })->paginate(10);
        return Voyager::view('vendor.voyager.secretaries.paginate_doctor', compact('doctors'))->render();

    }
    public function secretarySearch(Request $request)
    {
        $nameSearch = $request->name;
        $emailSearch = $request->email;
        $doctorSearch = $request->doctor;
        $statusSearch = $request->status;
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = "secretaries";
        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));

        $getter = $dataType->server_side ? 'paginate' : 'get';

        $search = (object)['value' => $request->get('s'), 'key' => $request->get('key'), 'filter' => $request->get('filter')];
        $searchable = $dataType->server_side ? array_keys(SchemaManager::describeTable(app($dataType->model_name)->getTable())->toArray()) : '';
        $orderBy = $request->get('order_by', $dataType->order_column);
        $sortOrder = $request->get('sort_order', null);
        $orderColumn = [];
        if ($orderBy) {
            $index = $dataType->browseRows->where('field', $orderBy)->keys()->first() + 1;
            $orderColumn = [[$index, 'desc']];
            if (!$sortOrder && isset($dataType->order_direction)) {
                $sortOrder = $dataType->order_direction;
                $orderColumn = [[$index, $dataType->order_direction]];
            } else {
                $orderColumn = [[$index, 'desc']];
            }
        }

        // Next Get or Paginate the actual content from the MODEL that corresponds to the slug DataType
        if (strlen($dataType->model_name) != 0) {
            $model = app($dataType->model_name);
            $query = $model::select('*');

            // If a column has a relationship associated with it, we do not want to show that field
            $this->removeRelationshipField($dataType, 'browse');

            if ($search->value && $search->key && $search->filter) {
                $search_filter = ($search->filter == 'equals') ? '=' : 'LIKE';
                $search_value = ($search->filter == 'equals') ? $search->value : '%' . $search->value . '%';
                $query->where($search->key, $search_filter, $search_value);
            }
            $query = User::query();
            if($emailSearch!='') {
                $query->where('email','like' , '%'.$emailSearch .'%');
            }
            if($nameSearch!='') {
                $query->where('fullname','like' , '%'.$nameSearch.'%');
            }
            if($statusSearch!=''){
                $query->where('verified',$statusSearch);
            }
            $query->whereHas('secretary',function($query) use ($doctorSearch) {
                $query->whereHas('doctor',function($query) use ($doctorSearch){
                    if($doctorSearch!='')
                    {
                        $query->wherehas('user' ,function($query) use ( $doctorSearch )
                        {
                            $query->where('fullname_en', 'like' , '%'.$doctorSearch.'%');
                            $query->orWhere('fullname', 'like' , '%'.$doctorSearch.'%');
                        });
                    }
                });
            });

            $query->orderBy('id', 'DESC');
            $dataTypeContent=$query->paginate(10);

            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }

            $dataTypeContent->appends(['email' => $emailSearch ,'name' =>$nameSearch ,'doctor'=>$doctorSearch,'status'=>$statusSearch]);
            if (($isModelTranslatable = is_bread_translatable($model))) {
                $dataTypeContent->load('translations');
            }
            // Check if server side pagination is enabled
            $isServerSide = isset($dataType->server_side) && $dataType->server_side;

            // Check if a default search key is set
            $defaultSearchKey = isset($dataType->default_search_key) ? $dataType->default_search_key : null;

            $view = "vendor.voyager.secretaries.browse";

            if (view()->exists("voyager::$slug.browse")) {
                $view = "voyager::$slug.browse";
            }
            $actions = [];
            if (!empty($dataTypeContent->first())) {
                foreach (Voyager::actions() as $action) {
                    $action = new $action($dataType, $dataTypeContent->first());

                    if ($action->shouldActionDisplayOnDataType()) {
                        $actions[] = $action;
                    }
                }
            }
            return Voyager::view($view, compact(
                'actions',
                'dataType',
                'dataTypeContent',
                'isModelTranslatable',
                'search',
                'orderBy',
                'orderColumn',
                'sortOrder',
                'searchable',
                'isServerSide',
                'defaultSearchKey',
                'emailSearch',
                'nameSearch',
                'doctorSearch',
                'statusSearch'

            ));
            // GET THE SLUG, ex. 'posts', 'pages', etc.
        }
    }
}
