<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Service;

class ServicesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }
    public function services_func(){
        if(Auth::user()->hasPermission('browse_services')==1) {
            $obj=new Service();
            $allservices =$obj->services();
            return OutPut::Response($allservices,'',200);
        } else {
            return OutPut::Response('',__('messages.auth_error_services'),401);
        }
    }
    public function Addservice(Request $request){
        $valid=Validator::make($request->all(),[
            'service'=>'required|Filled|integer',
        ]);
        if($valid->fails()){
            return OutPut::Response('',$valid->Errors(),403);
        }
        if(Auth::user()->hasPermission('add_services')==1) {
            $obj=new Service();
            $checkadding =$obj->add_services($request->input('service'));
            if( $checkadding == false )
            {
                return "please check your service";
            }
            return OutPut::Response('','service added correctly',200);
        } else {
            return OutPut::Response('','You are not Authorized ',401);
        }
    }}
