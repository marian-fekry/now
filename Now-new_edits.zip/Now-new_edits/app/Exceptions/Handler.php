<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * @param  \Exception  $exception
     * @return void
     */
    public function report(Exception $exception)
    {

        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Exception  $exception
     * @return \Illuminate\Http\Response
     */
    public function render($request, Exception $exception)
    {
        if($exception instanceof \Swift_TransportException){
            if ($request->is('api/*')) {
                $Output = array(
                    'data' => '',
                    'message' => __('messages.mail_error'),
                    'status' => 403
                );
                return response($Output, 403);
            }
            return redirect()->back()->with('message', __('messages.mail_error'));
        }
        if($exception->getCode()==23000)
        {
            return redirect()->back()->with('message', $exception->getMessage());
        }
        if($exception instanceof \Illuminate\Auth\Access\AuthorizationException){
            return redirect(url('/'));
        }
        return parent::render($request, $exception);
    }
}
