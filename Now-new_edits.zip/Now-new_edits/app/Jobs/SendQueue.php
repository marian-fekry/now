<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\notifications ;
use Log;
use Auth;
class SendQueue implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    protected $patientUserId;
    protected $userId;
    protected $requestId;
    protected $patientId;
    protected $authUser;
    protected $notificationName;
    protected $notificationType;
    protected $date;
    protected $time;
    protected $notificationNameMessage;
    protected $notificationTypeMessage;
    protected $secondMessage;
    protected $secondNotificationTypeMessage;
    protected $requestIdLabel;
    public function __construct($patientUserId,$notificationName,$userId,$requestId,$date,$time,$notificationType,$patientId,$authUser,$notificationNameMessage,$notificationTypeMessage,$secondMessage='N',$secondNotificationTypeMessage='',$requestIdLabel='')
    {
        $this->patientUserId=$patientUserId;
        $this->userId=$userId;
        $this->requestId=$requestId;
        $this->patientId=$patientId;
        $this->authUser=$authUser;
        $this->notificationName=$notificationName;
        $this->notificationType=$notificationType;
        $this->date=$date;
        $this->time=$time;
        $this->notificationNameMessage=$notificationNameMessage;
        $this->notificationTypeMessage=$notificationTypeMessage;
        $this->secondMessage=$secondMessage;
        $this->secondNotificationTypeMessage=$secondNotificationTypeMessage;
        $this->requestIdLabel=$requestIdLabel;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        try{
        //notifications::sendDataMessage($this->patientId,$this->notificationNameMessage,$this->userId,$this->requestId ,$this->date,$this->time,$this->notificationTypeMessage);
        if($this->secondMessage=='Y') {
        //\App\notifications::sendDataMessage($this->patientId,$this->notificationNameMessage,$this->userId,$this->requestId,$this->date,$this->time,$this->secondNotificationTypeMessage);
        }
        
        notifications::sendNotification($this->patientUserId,$this->notificationName,$this->userId,$this->requestId,$this->date,$this->time,$this->notificationType,'queue',$this->authUser,$this->requestIdLabel);

        }catch(\Exception $e){
            Log::error($e->getMessage());
        }
    }
}
