<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Request;
use App\BulkRequestQueueTasks;
use Carbon\Carbon ;
use DB;
class Bulkrequest extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Request:bulk';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Request bulk';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $requests = BulkRequestQueueTasks::where(function($q) {
        })->where('send_date_time', '<=', Carbon::now())->get();
        foreach ($requests as $request){
            $patient=\App\Patient::find($request->patient_id);
            $req=new Request;
            $req->addrequest($request->patient_id,$request->doctor_id,$request->medical_provider_id ,$request->service_id, $request->date ,$request->time ,$request->bulk_request_group,'Request',0,$patient->user_id);
            DB::table('bulk_request_queue_tasks')->where('id',  $request->id)->delete();

        }
    }
}
