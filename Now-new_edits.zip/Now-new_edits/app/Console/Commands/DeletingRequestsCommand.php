<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Request;
use Carbon\Carbon ;
class DeletingRequestsCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Request:delete';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'expired requests';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info("delete");
        $now = Carbon::now()->subDays(2);
        $request = new Request();
        $requestsPassed = Request::where(function($q) {
        $q->where('status','=','Request')->orWhere('status','=','Approve');
    })->where('date', '<', $now)->get();
        foreach ($requestsPassed as $requestPassed) {
            $request->ExpiredRequest($requestPassed->id);
        }
    }
}
