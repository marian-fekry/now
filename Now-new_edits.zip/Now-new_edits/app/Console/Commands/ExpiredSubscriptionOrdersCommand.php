<?php

namespace App\Console\Commands;

use App\SubscriptionOrder;
use Illuminate\Console\Command;
use App\Request;
use Illuminate\Support\Facades\DB;
use Carbon;
class ExpiredSubscriptionOrdersCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'SubscriptionOrder:expired';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'expired subscriptionOrder';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info("expired");
        $expiredOrders = SubscriptionOrder::where('status', 'Active')->get();
        foreach ($expiredOrders as $expiredOrder) {
            if ($expiredOrder->subscriptionPlans->frequency == 'Month') {
                $expireDate = $expiredOrder->created_at->addMonths(1)->toDateString();
            }
            else {
                    $expireDate = $expiredOrder->created_at->addWeeks(1)->toDateString();
                }
                if ($expireDate < (Carbon\Carbon::now()->toDateString())) {
                    DB::table('subscription_orders')->where('id', $expiredOrder->id)->update(['status' => 'Expired']);
                }
            }
    }
}
