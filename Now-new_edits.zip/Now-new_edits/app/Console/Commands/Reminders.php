<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use \App\Request;
use Carbon\Carbon ;
use DB;

class Reminders extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Reminder:send';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send reminders';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info("start");
      $now = Carbon::now();
      $requestsConfirm = Request::where('status','Confirm')->where(function($query){
        $query->where('date','>',date('Y-m-d'))->orwhere(function($query){
          $query->where('date','=',date('Y-m-d'))->where('time','>=',Carbon::now()->subHours(3)->format('H:i:s'));
        });
      })->get();
        
      foreach ($requestsConfirm as $request) {
          $dif=$now->diffInMinutes($request->date.' '.$request->time,false);
          
          $reqtime=new Carbon($request->date.' '.$request->time);
          if($dif==(5760)){ // 5760 minutes in 4 days
            $patient=\App\Patient::find($request->patient_id);
            \App\notifications::sendReminder($request->id,$patient->user_id,'4_days_before');
          }else if($dif==(1440)){ //1440 minutes in 1 day
            $patient=\App\Patient::find($request->patient_id);
            \App\notifications::sendReminder($request->id,$patient->user_id,'1_day_before');
          }else if($dif==(180)){ // 180 minutes in 3 houres
            $patient=\App\Patient::find($request->patient_id);
            \App\notifications::sendReminder($request->id,$patient->user_id,'3_hours_before');
          }else if($dif==(60)){ // 60 minutes in 1 hour
            $patient=\App\Patient::find($request->patient_id);
            \App\notifications::sendReminder($request->id,$patient->user_id,'1_hour_before');
          }else if($dif==-1){
            $patient=\App\Patient::find($request->patient_id);
            \App\notifications::sendReminder($request->id,$patient->user_id,'patient_arrive_patient');
            
            \App\notifications::sendDataMessage($patient->user_id,'',$patient->user_id,$request->id,'','','updateOldRequest');
            \App\notifications::sendDataMessage($patient->user_id,'',$patient->user_id,$request->id,'','','updateCurrentRequest');


          }else if($dif==(-120)){
            $patient=\App\Patient::find($request->patient_id);
            \App\notifications::sendReminder($request->id,$patient->user_id,'2_hours_after');
          }
      }
    }
}
