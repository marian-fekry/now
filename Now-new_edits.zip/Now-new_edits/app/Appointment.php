<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Appointment extends Model
{
  use SoftDeletes;
  protected $dates=['deleted_at'];
  
  protected $hidden = [
      'created_at','updated_at','disabled'
  ];

  public function request(){
    return $this->hasOne('App\Request');
  }
  public function disable($id){
    $appointment=Appointment::find($id);
    $appointment->disabled=1;
    if($appointment->save()){
      return true;
    }else{
      return false;
    }

    return;
  }
}
