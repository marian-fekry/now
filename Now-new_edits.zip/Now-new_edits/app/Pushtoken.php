<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pushtoken extends Model
{
  protected $fillable = [
      'token', 'device_id'
  ];
  protected $hidden = [
      'created_at', 'updated_at'
  ];
    public function addtoken($userId,$token,$deviceId){
        $deviceExists=Pushtoken::where('device_id',$deviceId)->first();
        if(null!==$deviceExists) {
            Pushtoken::where('device_id', $deviceId)->update(['token' => '']);
        }
        $record=Pushtoken::where('device_id',$deviceId)->where('user_id',$userId)->first();
      if(null!==$record){
        $record->token=$token;
        $record->save();
      }else{
        $record=new Pushtoken;
        $record->user_id=$userId;
        $record->token=$token;
        $record->device_id=$deviceId;
        $record->save();
      }
      return;
    }
    public function sendnotification($userId,$title,$body){
      $tokens=Pushtoken::where('user_id',$userId)->get();
      $messages=array();
      foreach($tokens AS $token){
        array_push($messages,(array("to"=>$token->token,"title"=>$title,"body"=>$body)));
      }

      $messages=json_encode($messages);
      $url="https://exp.host/--/api/v2/push/send";
      $header=array('Content-Type:application/json');
      $ch=curl_init();
      curl_setopt($ch, CURLOPT_URL,$url);
      curl_setopt($ch, CURLOPT_POST,true);
      curl_setopt($ch, CURLOPT_HTTPHEADER,$header);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
      curl_setopt($ch, CURLOPT_POSTFIELDS,$messages);

      $result=curl_exec($ch);
      if(!$result){
      }
      curl_close($ch);
    }
}
