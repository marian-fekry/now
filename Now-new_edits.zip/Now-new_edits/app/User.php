<?php

namespace App;
use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Secretary;
use App\Doctor;
use App\MedicalProvider;
use App\Traits\MySoftDeletes;
use DB;
use Carbon\Carbon;
use Illuminate\Support\Str;

use Illuminate\Database\Eloquent\SoftDeletes;
use App\Notifications\ResetPassword as ResetPasswordNotification;
class User extends \TCG\Voyager\Models\User
{
    use HasApiTokens,Notifiable;
    //use SoftDeletes;
    use MySoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $dates = ['created_at', 'updated_at', 'token_created_at','deleted_at'];
    protected $fillable = [
        'name', 'email','avatar','role_id', 'password','fullname','fullname_en','type','mobile','gender','birthdate' , 'token' , 'token_created_at'
    ];


    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token','created_at','updated_at','disabled'
    ];
    // Relations
    public function patient(){
      return $this->hasOne('App\Patient');
    }

    public function doctor(){
      return $this->hasOne('App\Doctor');
    }

    public function medicalprovider(){
      return $this->hasOne('App\MedicalProvider');
    }
    public function secretary(){
      return $this->hasOne('App\Secretary');
    }
    public function privatereservation(){
      return $this->hasOne('App\PrivateReservation');
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    ////check users roles
    public function isDoctor(){
       return (($this->doctor instanceof Doctor)&& ($this->hasRole('ROLE_DOCTOR')));
    }
    public function isPatient(){
       return (($this->patient instanceof Patient)&& ($this->hasRole('ROLE_PATIENT')));
    }
    public function isSecretary(){
       return (($this->secretary instanceof Secretary)&& ($this->hasRole('ROLE_SECRETARY')));
    }
    public function isMedicalProvider(){
       return (($this->medicalprovider instanceof MedicalProvider)&& ($this->hasRole('ROLE_MEDICAL_PROVIDER')));
    }
    public function isPrivateReservation(){
       return (($this->privatereservation instanceof PrivateReservation)&& ($this->hasRole('ROLE_PRIVATE_RESERVATION')));
    }
    public function isPrivateClinic(){
       return (($this->medicalprovider instanceof MedicalProvider)&& ($this->hasRole('ROLE_PRIVATE_CLINIC')));
    }
    public function isSharedClinic(){
       return (($this->medicalprovider instanceof MedicalProvider)&& ($this->hasRole('ROLE_SHARED_CLINIC')));
    }
    public function isHospital(){
       return (($this->medicalprovider instanceof MedicalProvider)&& ($this->hasRole('ROLE_HOSPITAL')));
    }
    public function isOwner(){
      return (
        ($this->medicalprovider instanceof MedicalProvider&& (
        $this->hasRole('ROLE_MEDICAL_PROVIDER')||
        $this->hasRole('ROLE_PRIVATE_CLINIC')||
        $this->hasRole('ROLE_SHARED_CLINIC')||
        $this->hasRole('ROLE_HOSPITAL')))
      );
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    public function createUser($data=array()){
        $tokenCreatedAt = Carbon::now();
        $tokenCreatedAt->toDateTimeString();
        $user_avatar = 'users/default.png';
        if($data['type']=='patient'){
            $user_avatar = 'users/default_patient.png';
        }
        $user=User::create([
          'name'=>$data['name'],
          'email'=>$data['email'],
          'avatar'=>$user_avatar ,
          'role_id'=>2,
          'password'=>bcrypt($data['password']),
          'fullname'=>$data['fullNameAr'],
          'fullname_en'=>(null!=$data['fullNameEn']&&$data['fullNameEn']!='')?$data['fullNameEn']:null,
          'type'=>$data['type'],
            'token'=>Str::random(32),
            'token_created_at'=>$tokenCreatedAt,
        ]);
        // add user role in the user_roles table
        $defaultRole=($data['type']=='patient')?4:11; // 4 is the patient role in the database, 11 is the medical provider in the database
        DB::insert('insert into user_roles(user_id,role_id) values (?,?)',[$user->id,$defaultRole]);
        return $user;
    }

    public function resetPassword($newPassword,$userId){
        $user=User::find($userId);
        $user->password=bcrypt($newPassword);

        if($user->save()){
    			return true;
    		}else{
    			return false;
    		}

        return;
    }

    /*
      return the doctor user id linked to this secretary user id
    */
    public function getDoctorUserIdFromSecretary($secretaryUserId){
      $secretaryData=Secretary::where('user_id',$secretaryUserId)->with('doctor')->first();
      $data= (null!=$secretaryData->doctor)?$secretaryData->doctor->user_id:0;
      return $data;
    }


    /*
      return the all doctors user ids linked to this medical provider
    */
    public function getDoctorsUserIdInProvider($ProviderUserId){
      $providerDoctors=MedicalProvider::with('doctor')->where('user_id',$ProviderUserId)->first();
      $doctors=array();
      foreach($providerDoctors->doctor AS $doctor){
         array_push($doctors,$doctor->id);
      }
      return $doctors;
    }

/*
      return the all doctors user ids linked to this medical provider in specific specialty
    */
    public function getDoctorsUserIdInPrivateReservation($privateReservationUserId){
      $privateReservation=PrivateReservation::where('user_id',$privateReservationUserId)->first() ;
      $data=DB::select('select * from medical_provider_has_specialties where departement_secretary_id=?',[$privateReservation->id]);
      $data=$data[0];
      $specialityId=$data->speciality_id;
      $providerDoctors=MedicalProvider::with('doctor')->where('id',$data->medical_provider_id)->whereHas('doctor',function($query) use($specialityId){
        return $query->where('speciality_id',$specialityId);
      })->get();
      $doctors=array();
      foreach($providerDoctors AS $providerDoctor){
        foreach($providerDoctor->doctor AS $doctor){
          array_push($doctors,$doctor->user_id);
        }
      }
      return $doctors;
    }


    public function setLang($user,$lang){
      $user->lang=$lang;
      if($user->save()){
        return true;
      }else{
        return false;
      }

      return;
    }

    public function setLangByToken($user,$lang ,$token){
        $updateLang =DB::table('oauth_access_tokens')->where('user_id', $user)->where('id', $token)->update(['user_lang' => $lang]);
        if($updateLang){
            return true;
        }else{
            return false;
        }

        return;
    }


    public function chekUserToken($token)
    {
        $user = User::where('token' ,$token)->first();
        if($user)
        {
            return $user->token_created_at  ;
        }
        return false ;

    }

    public function checkUserverification($token)
    {
        $user = User::where('token', $token )->first();
        return $user->verified ;
    }

    public function verifyUser ($token)
    {
        User::where('token', $token)->update(['verified' => 1]);
        return true;
    }

    public function createNewToken($token)
    {
        $tokenCreatedAt = Carbon::now();
        $tokenCreatedAt->toDateTimeString();
        $user = User::where('token', $token)->update(['token' => Str::random(32) , 'token_created_at'=>$tokenCreatedAt]);
        return $user;
    }

    public function getUserByEmail ($email)
    {
        $user = User::where('email', $email )->first();
        return $user ;
    }

    public function disable($id){
        $user=User::find($id);
        $user->disabled=1;
        if($user->save()){
            return true;
        }else{
            return false;
        }

        return;
    }


    public function changeUserImage($id,$Image){
      $user=User::find($id);
      $user->avatar='users/'.$Image;
      if($user->save()){
        return true;
      }else{
        return false;
      }

      return;
    }

    public function userCanRespondRequest($user,$req){
      if($user->hasRole('ROLE_PATIENT')){
        $patient=\App\Patient::where('user_id',$user->id)->first();
        if($patient->id == $req->patient_id){
          return true;
        }else{
          return false;
        }
      }else if ($user->hasRole('ROLE_DOCTOR')) {
        $doctor=\App\Doctor::where('user_id',$user->id)->first();
        if($doctor->id == $req->doctor_id){
          return true;
        }else{
          return false;
        }
      }
      // if user is secretary
      else if ($user->hasRole('ROLE_SECRETARY')){
        $secretary=Secretary::where('user_id',$user->id)->first();
        if(  $secretary->doctor_id== $req->doctor_id){
          return true;
        }else{
          return false;
        }
      }
      // if user is private reservation
      else if ($user->hasRole('ROLE_PRIVATE_RESERVATION')){
        $privateReservation=\App\PrivateReservation::where('user_id',$user->id)->first();
        $data=DB::select('select * from medical_provider_has_specialties where departement_secretary_id=?',[$privateReservation->id]);
        $data=$data[0];
        if($data->medical_provider_id == $req->medical_provider_id){
          return true;
        }else{
          return false;
        }

      }
      // if user medical provider
      else if ($user->hasRole('ROLE_HOSPITAL')||$user->hasRole('ROLE_PRIVATE_CLINIC')||$user->hasRole('ROLE_SHARED_CLINIC')||$user->hasRole('ROLE_MEDICAL_PROVIDER')) {
        $medicalProvider=\App\MedicalProvider::where('user_id',$user->id)->first();
        if($medicalProvider->id == $req->medical_provider_id){
          return true;
        }else{
          return false;
        }
      }else{
        return false;
      }

      return;
    }


    public function sendPasswordResetNotification($token)
    {
        $this->notify(new ResetPasswordNotification($token));
    }


}
