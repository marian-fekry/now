<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Staticpage extends Model
{
    use SoftDeletes;
    protected $dates=['deleted_at'];

    protected $hidden = [
        'created_at','updated_at','disabled'
    ];
    public function getpage($slug,$lang='en'){

        if($lang=='ar'){

            $page= Staticpage::where('slug',$slug)->where('disabled',0)->get(['title_ar','arabic']);
            $page=$page->toArray();

            if(!empty($page)){
                $page=$page[0];
                return array('title'=>$page['title_ar'],'content'=>$page['arabic']);
            }else{
                return array();
            }

        }else{
            $page= Staticpage::where('slug',$slug)->where('disabled',0)->get(['title','english']);
            if(!empty($page)){
                $page=$page[0];
                return array('title'=>$page['title'],'content'=>$page['english']);
            }else{
                return array();
            }


        }

      return ;
    }
}
