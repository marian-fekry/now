<?php

namespace App;

use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;
class Jobtitle extends Model
{
    //
    use SoftDeletes;
    protected $dates=['deleted_at'];

    protected $hidden = [
        'created_at','updated_at','disabled'
    ];
    protected $fillable = [
        'name_ar', 'name_en'
    ];

    public function doctors ()
    {
       return $this->hasMany('App\Doctor' , 'jobtitle');
    }
    protected static function boot() {
        parent::boot();
        static::deleting(function($jobtitle) {
            if ($jobtitle->doctors()->count() > 0) {
                throw new Exception(__('messages.this_jobtitle_have_doctors') , '23000');
            }
        });
    }

    public function index()
    {
        if(Auth::user()->token()->user_lang=='ar') {
            $lan = "name_ar As name";
            $orderCol= "name_ar";
        }
        else {
            $lan = "name_en As name";
            $orderCol= "name_en";
        }
        $jobTitles = Jobtitle::where('deleted_at' , '=' , Null)->where('disabled' , '=' , 0)->select(['id' ,$lan])->orderBy($orderCol, 'asc')->paginate(30);
        return $jobTitles;
    }

}
