<?php

    namespace App;

    use Illuminate\Database\Eloquent\Model;

    class GoverneratesTimeReservations extends Model
    {
        protected $fillable = [
            'medical_provider_id',
            'governrate_id',
            'subscription_order_id',
            'from',
            'to'
        ];
        protected $hidden = [
            'created_at', 'updated_at'
        ];
        public function governrate()
        {
            return $this->belongsTo('App\Governrate', 'governrate_id', 'id');
        }
        public function subscriptionOrder()
        {
            return $this->hasOne('App\SubscriptionOrder', 'id', 'subscription_order_id');
        }
        public function getGovernerateReservedMinutes($governrateId)
        {
            $lastReserved = \App\GoverneratesTimeReservations::where('governrate_id', $governrateId)->with('subscriptionOrder')->whereHas('subscriptionOrder', function ($query) {
                $query->where('status', 'Active');
            })->orderBy('to', 'desc')->first();
            $reservedTo = 0;
            if (null !== $lastReserved) {
                $reservedTo = $lastReserved->to;
            }
            return $reservedTo;
        }
        public function setGovernerateReservedMinutes($medicalProviderId, $governrateId, $duration, $subscriptionOrderId)
        {
            $lastReserved = \App\GoverneratesTimeReservations::where('governrate_id', $governrateId)->with('subscriptionOrder')->whereHas('subscriptionOrder', function ($query) {
                $query->where('status', 'Active');
            })->orderBy('to', 'desc')->first();
            $reservedTo = 0;
            if (null !== $lastReserved) {
                $reservedTo = $lastReserved->to;
            }
            $reservedTo =( $reservedTo ==0)? $reservedTo :( $reservedTo +1);
            $user = GoverneratesTimeReservations::create([
                'medical_provider_id' => $medicalProviderId,
                'governrate_id' => $governrateId,
                'subscription_order_id' => $subscriptionOrderId,
                'from' => $reservedTo ,
                'to' => $reservedTo + ($duration)
            ]);
        }
    }
