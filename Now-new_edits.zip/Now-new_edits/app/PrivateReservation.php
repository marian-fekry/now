<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Mail;
use App\User;
use DB;
use Illuminate\Support\Str;
class PrivateReservation extends Model
{
  protected $hidden = [
      'created_at','updated_at'
  ];

    public function medicalProvider(){
        return $this->belongsToMany('App\MedicalProvider','medical_provider_has_specialties' , 'departement_secretary_id');
    }
    public function privateReservationSpecialty(){
        return $this->belongsToMany('App\Specialty','medical_provider_has_specialties' , 'departement_secretary_id' , 'speciality_id');
    }
    public function user(){
        return $this->belongsTo('App\User');
    }
    public function addDepartementSecretary($email,$medicalProviderId,$specialtyId){

        if($email==NULL){
          return;
        }
        //check if this mail found previously or not
        $user=User::where('email',$email)->get();
        if($user->isEmpty()){
          $user=new User;
          $user->email=$email;
          $name=explode("@",$email);
          $user->name=$name[0];
          $user->fullname=$name[0];
          $user->role_id=2;
          $password=bin2hex(openssl_random_pseudo_bytes(4));
          $user->password=bcrypt($password);
          $user->token= Str::random(32);

          if($user->save()){
            DB::insert('insert into user_roles(user_id,role_id) values (?,?)',[$user->id,10]);
            $privateReservation=new PrivateReservation;
            $privateReservation->user_id=$user->id;


            if($privateReservation->save()){
              // add departement secretary to departement
              $A=\App\MedicalProviderHasSpecialties::where('medical_provider_id',$medicalProviderId)->where('speciality_id',$specialtyId)->update(['departement_secretary_id'=>$privateReservation->id]);
              // send email to departement secretary
              if($A){Mail::to($user)->send(new \App\Mail\NewDepartementSecretary($email,$password,'' ,$user->token));}
              return true;
            }else{
              return false;
            }
          }else{
            return false;
          }
        }else{
            if($user->isPrivateReservation()){
                $user->email=$email;
                $user->save();
                $PrivateReservation=PrivateReservation::where('user_id',$user->id)->first();
                $isFoundBeforePrivateReservation=\App\MedicalProviderHasSpecialties::where('medical_provider_id',$medicalProviderId)->where('speciality_id',$specialtyId)->where('departement_secretary_id',$privateReservation->id);
                if($isFoundBeforePrivateReservation!==null){
                    return 'already_linked_to_departement';
                }
                $A=\App\MedicalProviderHasSpecialties::where('medical_provider_id',$medicalProviderId)->where('speciality_id',$specialtyId)->update(['departement_secretary_id'=>$privateReservation->id]);
                // send email to departement secretary
               // if($A){Mail::to($user)->send(new \App\Mail\NewDepartementSecretary($email,$password,'' ,$user->token));}
                return true;
              }else{
                return 'email_is_not_private_reservation';
              }
        }
        return;
    }
    public function removeDepartementSecretary($privateReservationId,$medicalProviderId,$specialtyId){
        DB::update('update medical_provider_has_specialties set departement_secretary_id=NULL  where medical_provider_id=? and speciality_id=?',[$medicalProviderId,$specialtyId]);
        return;
    }
    public function editDepartementSecretary($email,$medicalProviderId,$specialtyId){
        //check if this mail found previously or not
        $isFound=User::where('email',$email)->get();
        if($isFound->isEmpty()){

          $user=new User;
          $user->name='Departement Secretary';
          $user->email=$email;
          $password=bin2hex(openssl_random_pseudo_bytes(4));
          $user->password=bcrypt($password);

          if($user->save()){
            DB::insert('insert into user_roles(user_id,role_id) values (?,?)',[$user->id,10]);
            $privateReservation=new PrivateReservation;
            $privateReservation->user_id=$user->id;

          }else{
            return false;
          }
        }
        return;
    }

    public function addPrivateReservationAdmin($name,$email, $password  ,$speciality_id  ,$medicalProviderId){
        //check if this mail found previously or not
        $isFound=User::where('email',$email)->get(); // check made in users table so mails not repeated between different types of users
        if(count($isFound)==0){
            $user=new User;
            $user->name = $name;
            $user->email = $email;
            $user->password=bcrypt($password);
            $user->role_id='2';
            $user->token= Str::random(32);

            if($user->save()){
                DB::table('user_roles')->insert(['user_id' => $user->id, 'role_id' => 10]);
                $privateReservation=new PrivateReservation;
                $privateReservation->user_id=$user->id;
                if($privateReservation->save()){
                    DB::table('medical_provider_has_specialties')->where('medical_provider_id', $medicalProviderId)->where('speciality_id' , $speciality_id )->update(['departement_secretary_id' => $privateReservation->id]);
                    Mail::to($user)->send(new \App\Mail\NewDepartementSecretary($email,$password,$name,$user->token));
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }

    }
    public function editPrivateReservationAdmin($email,$name,$speciality_id  ,$medicalProviderId,$privateReservationId,$password=''){
        $privateReservationModel =new PrivateReservation;
        DB::table('medical_provider_has_specialties')->where('medical_provider_id', $medicalProviderId)->where('speciality_id' , $speciality_id )->update(['departement_secretary_id' => $privateReservationId]);
        $privateReservation = $privateReservationModel->find($privateReservationId);
        if($privateReservation){
            $userModel = new User;
            $user = $userModel::find($privateReservation->user_id);
            $user->email = $email;
            $user->name = $name;
            if($password!=''){$user->password=bcrypt($password);}

            if($user->save()){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }

    }

    public function currentRequestCount($doctors , $medicalId){
        $currentRequestCount = \App\Request::where('medical_provider_id', $medicalId)->whereIn('doctor_id',$doctors)->where('status', 'Confirm')->where(function($q) {
            $q->where('date','>',date('Y-m-d'))
                ->orWhere(function($q) {
                    $q->where('date', '=', date('Y-m-d'))
                        ->Where('time', '>', date('H:i:s'));
                });
        })->where("disabled","=",0)->where("deleted_at","=",null)->count();
        return $currentRequestCount ;
    }

    public function oldRequestCount($doctors , $medicalId){
        $oldRequestCount = \App\Request::where('medical_provider_id', $medicalId)->whereIn('doctor_id',$doctors)->where('status', 'Confirm')->where(function($q) {
            $q->where('date','<',date('Y-m-d'))
                ->orWhere(function($q) {
                    $q->where('date', '=', date('Y-m-d'))
                        ->Where('time', '<', date('H:i:s'));
                });
        })->where("disabled","=",0)->where("deleted_at","=",null)->count();
        return $oldRequestCount ;
    }
    public function pendingFromPrivateReservationsRequestCount($doctors , $medicalId){
        $pendingRequestCount = \App\Request::where('medical_provider_id', $medicalId)->whereIn('doctor_id',$doctors)->where('status', 'Request')
            ->where("disabled","=",0)->where("deleted_at","=",null)
            ->count();
        return $pendingRequestCount ;
    }
    public function pendingFromPatientRequestCount($doctors , $medicalId){
        $pendingRequestCount = \App\Request::where('medical_provider_id', $medicalId)->whereIn('doctor_id',$doctors)->where('status', 'Approve')
            ->where("disabled","=",0)->where("deleted_at","=",null)
            ->count();
        return $pendingRequestCount ;
    }
    public function pendingRequests($doctors , $medicalId , $user){
        $pendingRequests = \App\Request::where('medical_provider_id', $medicalId)->whereIn('doctor_id',$doctors)->where('status', 'Request')
            ->where("disabled","=",0)->where("deleted_at","=",null)
            ->paginate();
        $responseArray = array();
        foreach ($pendingRequests as $request){
            if($user->lang=='ar') {
                $medical_provider_name = $request->medical_provider->user->fullname;
                $doctor_name = $request->doctor->user->fullname;
                $doctor_job_title = $request->doctor->jobTitle->name_ar;
                $speciality_name = $request->doctor->speciality->name_ar ;
            }else{
                $medical_provider_name = $request->medical_provider->user->fullname_en;
                $doctor_name = $request->doctor->user->fullname_en;
                $doctor_job_title = $request->doctor->jobTitle->name_en;
                $speciality_name = $request->doctor->speciality->name_en ;
            }
            array_push($responseArray , [
                'request_id'=>$request->id ,
                'medical_provider_id' => $request->medical_provider->id,
                'medical_provider_name'=>$medical_provider_name ,
                'doctor_name'=>$doctor_name ,
                'doctor_job_title'=>$doctor_job_title ,
                'patient_name'=>$request->patient->userRequest->fullname ,
                "speciality_name"=>$speciality_name  ,
                'request_date'=>$request->date ,
                'request_time'=>$request->time ,
                'request_status'=>$request->status]);
        }
        $response =   ['data'=>$responseArray , 'current_page'=>$pendingRequests->currentPage() ,'total' =>$pendingRequests->total() , 'count' =>$pendingRequests->count(),'last_page'=>$pendingRequests->lastPage()];
        return $response ;
    }

}
