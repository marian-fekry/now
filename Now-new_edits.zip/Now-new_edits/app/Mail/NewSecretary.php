<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class NewSecretary extends Mailable
{
    use Queueable, SerializesModels;

    public $email,$password,$fullName;
    protected $token ;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($email='',$password='',$fullName='' , $token='')
    {
        $this->fullName=$fullName;
        $this->email=$email;
        $this->password=$password;
        $this->token = $token;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('Now - Your Login Details')->view('mails.newSecretary')->with(["email"=>$this->email,"password"=>$this->password,'fullName'=>$this->fullName , 'email_token' => $this->token]);
    }
}
