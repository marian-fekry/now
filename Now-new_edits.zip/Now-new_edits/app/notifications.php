<?php

namespace App;
use \App\Request;
use \App\User;
use \App\Pushtoken;
use \App\Doctor;
use \App\MedicalProvider;
use \App\Notification;
use \App\Patient;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Auth;
class notifications
{

  /*
  new_request
  reschedule_request
  confirm_request
  approve_request
  */
  public static function sendNotification($patientUserId=0,$notificationName,$senderUserId,$requestId,$date='',$time='',$notificationType='',$typeSendData='',$authuserId='',$requestIdLabel=''){
      $request=Request::find($requestId);
      $sender=User::find($senderUserId);

      if($typeSendData!='queue'){
          $userTimeZone=(Auth::user()->user_time_zone!=null)?Auth::user()->user_time_zone:'UTC';
      }
      else{
          $authuser=User::find($authuserId);
          $userTimeZone=($authuser->user_time_zone!=null)?$authuser->user_time_zone:'UTC';
      }

      $time_from=new \DateTimeZone('UTC');
      $time_to=new \DateTimeZone($userTimeZone);

      $originTime=new \DateTime($request->date." ".$request->time,$time_from);
      $newTime= $originTime->setTimezone($time_to);


      $date=$newTime->format('Y-m-d');
      $time=$newTime->format('H:i:s');
      $doctorName = "" ;
      $medicalProviderName = "";
      $senderName="";

      $specialtyId=isset($request->doctor->speciality_id)?$request->doctor->speciality_id:0;
      if($typeSendData!='queue'){
          $userLang=Auth::user()->token()->user_lang;
      }
      else{
          $userLang=$authuser->lang;
      }
      if($userLang=='ar') {
          $doctorName = $request->doctor->user->fullname ;
          $medicalProviderName = $request->medical_provider->user->fullname ;
          $senderName=$sender->fullname;
      }
      else {
          $doctorName = $request->doctor->user->fullname_en;
          $medicalProviderName = $request->medical_provider->user->fullname_en ;
          if($sender->isPatient()||$sender->isSecretary()||$sender->isPrivateReservation()){
            $senderName = $sender->fullname;
          }else{
            $senderName = $sender->fullname_en;
          }
      }


      $notificationsTexts=array(
      "new_request"=>array(
        //"patient"=>array("title"=>__('notifications.new_request_title'),"content"=>__('notifications.new_request_content_patient')),
        "medical_provider"=>array("title"=>__('notifications.new_request'),"content"=>__('notifications.new_request_content_mp' , ['patientName' => $request->patient->user->name ])),
      ),
      "approve_request"=>array(
        "patient"=>array("title"=>__('notifications.approve_request'),"content"=>__('notifications.approve_request_content_patient' , ['senderName' => $senderName])),
        "medical_provider"=>array("title"=>__('notifications.approve_request'),"content"=> __('notifications.approve_request_content_mp' , ['senderName' => $senderName , 'patientName' => $request->patient->user->name ])),
      ),
      "confirm_request"=>array(
        //"patient"=>array("title"=>__('notifications.confirm_request'),"content"=>__('notifications.confirm_request_content_patient')),
        "medical_provider"=>array("title"=>__('notifications.confirm_request'),"content"=>__('notifications.confirm_request_content_mp' , ['patientName' => $request->patient->user->name  , 'date'=>$date , 'time'=>$time])),
      ),
      "patient_cancel_request"=>array(
         "medical_provider"=>array("title"=>__('notifications.cancel_request'),"content"=>__('notifications.cancel_request_content_mp' , ['patientName' => $request->patient->user->name  , 'date'=>$date , 'time'=>$time])),
      ),
      "mp_cancel_request"=>array(
        "patient"=>array("title"=>__('notifications.cancel_request'),"content"=>__('notifications.cancel_request_content_patient' ,  ['senderName'=>$senderName,'patientName' => $request->patient->user->name  , 'date'=>$date , 'time'=>$time])),

      ),
      "reschedule_request"=>array(
        "patient"=>array("title"=>__('notifications.reschedule_request_title'),"content"=>__('notifications.reschedule_request_content_patient' ,['doctorName' => $doctorName , 'date'=>$date , 'time'=>$time] )),
        "medical_provider"=>array("title"=>__('notifications.reschedule_request_title'),
            "content"=> __('notifications.reschedule_request_content_mp' , ['senderName'=>$senderName , 'patientName' => $request->patient->user->name , 'date'=>$date  , 'time'=>$time])),

      ),
          "patient_arrive"=>array(
          //"patient"=>array("title"=>__('notifications.new_request_title'),"content"=>__('notifications.new_request_content_patient')),
          "medical_provider"=>array("title"=>__('notifications.patient_arrive'),"content"=>__('notifications.patient_arrive_content_mp' , ['patientName' => $request->patient->user->name ] )),
      )
    );

    // get notification recievers

    $doctorUserId=0;
    $secretaryUserId=0;
    $medicalProviderUserId=0;
    $privateReservationUserId=0;

    $notification=new Notification();
      if($typeSendData!='queue'){
          $permissionAddRequest=Auth::user()->hasPermission('add_requests');
      }
      else {
          $permissionAddRequest=$authuser->hasPermission('add_requests');
      }
    if($notificationName=='new_request' && $permissionAddRequest){
      $doctorUser=Doctor::find($request->doctor_id);
      $doctorUserId=$doctorUser->user_id;

      $medicalProviderUser=MedicalProvider::find($request->medical_provider_id);
      $medicalProviderUserId=$medicalProviderUser->user_id;

      $secretaryUser=Secretary::where('doctor_id',$request->doctor_id)->first();
      $secretaryUserId=0;

      if(isset($secretaryUser->user_id)&&!empty($secretaryUser->user_id)){
         $secretaryUserId=$secretaryUser->user_id;
        }

      $privateReservation= DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $request->medical_provider_id)->where('speciality_id',$specialtyId)->first();
      if(null!==$privateReservation&&null!=$privateReservation->departement_secretary_id){
        $privateReservationUser=PrivateReservation::find($privateReservation->departement_secretary_id);
        $privateReservationUserId=$privateReservationUser->user_id;
      }
      $notification->setnotification($senderUserId,$doctorUserId,$request->id,'Opened');

      if($doctorUserId!==$medicalProviderUserId){
        $notification->addNotifiaction($doctorUserId);
      }
      
      $notification->addNotifiaction($secretaryUserId);
      $notification->addNotifiaction($medicalProviderUserId);
      $notification->addNotifiaction($privateReservationUserId);


    }else if($sender->isPatient() && $notificationName=='confirm_request'){
      $doctorUser=Doctor::find($request->doctor_id);
      $doctorUserId=$doctorUser->user_id;

      $medicalProviderUser=MedicalProvider::find($request->medical_provider_id);
      $medicalProviderUserId=$medicalProviderUser->user_id;

      $secretaryUser=Secretary::where('doctor_id',$request->doctor_id)->first();
      $secretaryUserId=0;
      if(isset($secretaryUser->user_id)&&!empty($secretaryUser->user_id)){
         $secretaryUserId=$secretaryUser->user_id;
      }

      $privateReservation= DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $request->medical_provider_id)->where('speciality_id',$specialtyId)->first();
      if(null!==$privateReservation&&null!=$privateReservation->departement_secretary_id){
        $privateReservationUser=PrivateReservation::find($privateReservation->departement_secretary_id);
        $privateReservationUserId=$privateReservationUser->user_id;
      }

      $notification->setnotification($senderUserId,$doctorUserId,$request->id,'Confirmed');


      if($doctorUserId!==$medicalProviderUserId){
        $notification->addNotifiaction($doctorUserId);
      }
      $notification->addNotifiaction($secretaryUserId);
      $notification->addNotifiaction($medicalProviderUserId);
      $notification->addNotifiaction($privateReservationUserId);

    }
    else if($sender->isSecretary() && ($notificationName=='approve_request')){
      //get doctor and medical provider
      $doctorUser=Doctor::find($request->doctor_id);
      $doctorUserId=$doctorUser->user_id;

      $medicalProviderUser=MedicalProvider::find($request->medical_provider_id);
      $medicalProviderUserId=$medicalProviderUser->user_id;

      $privateReservation= DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $request->medical_provider_id)->where('speciality_id',$specialtyId)->first();
      if(null!==$privateReservation&&null!=$privateReservation->departement_secretary_id){
        $privateReservationUser=PrivateReservation::find($privateReservation->departement_secretary_id);
        $privateReservationUserId=$privateReservationUser->user_id;
      }

      $notification->setnotification($senderUserId,$doctorUserId,$request->id,'Approved');
      if($patientUserId>0){$notification->setnotification($senderUserId,$patientUserId,$request->id,'Approved');}


      $notification->addNotifiaction($patientUserId);
      if($doctorUserId!==$medicalProviderUserId){
        $notification->addNotifiaction($doctorUserId);
      }
      $notification->addNotifiaction($secretaryUserId);
      $notification->addNotifiaction($medicalProviderUserId);
      $notification->addNotifiaction($privateReservationUserId);

    }else if($sender->isPrivateReservation() && ($notificationName=='approve_request')){
      //get doctor and medical provider
      $doctorUser=Doctor::find($request->doctor_id);
      $doctorUserId=$doctorUser->user_id;

      $medicalProviderUser=MedicalProvider::find($request->medical_provider_id);
      $medicalProviderUserId=$medicalProviderUser->user_id;

      $secretaryUser=Secretary::where('doctor_id',$request->doctor_id)->first();
      $secretaryUserId=0;
      if(isset($secretaryUser->user_id)&&!empty($secretaryUser->user_id)){
       $secretaryUserId=$secretaryUser->user_id;
      }

      $notification->setnotification($senderUserId,$doctorUserId,$request->id,'Approved');
      if($patientUserId>0){$notification->setnotification($senderUserId,$patientUserId,$request->id,'Approved');}

      $notification->addNotifiaction($patientUserId);
      if($doctorUserId!==$medicalProviderUserId){
        $notification->addNotifiaction($doctorUserId);
      }
      $notification->addNotifiaction($secretaryUserId);
      $notification->addNotifiaction($medicalProviderUserId);
      $notification->addNotifiaction($privateReservationUserId);

    }else if($sender->isOwner() && ($notificationName=='approve_request')){
      $doctorUser=Doctor::find($request->doctor_id);
      $doctorUserId=$doctorUser->user_id;

      $secretaryUser=Secretary::where('doctor_id',$request->doctor_id)->first();
      $secretaryUserId=0;
      if(isset($secretaryUser->user_id)&&!empty($secretaryUser->user_id)){
         $secretaryUserId=$secretaryUser->user_id;
        }

      $privateReservation= DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $request->medical_provider_id)->where('speciality_id',$specialtyId)->first();
      if(null!==$privateReservation&&null!=$privateReservation->departement_secretary_id){
        $privateReservationUser=PrivateReservation::find($privateReservation->departement_secretary_id);
        $privateReservationUserId=$privateReservationUser->user_id;
      }

      $notification->setnotification($senderUserId,$doctorUserId,$request->id,'Approved');
      if($patientUserId>0){$notification->setnotification($senderUserId,$patientUserId,$request->id,'Approved');}


      $notification->addNotifiaction($patientUserId);
      if($doctorUserId!==$medicalProviderUserId){
        $notification->addNotifiaction($doctorUserId);
        $doctorUserId=0;
      }
      $notification->addNotifiaction($secretaryUserId);
      $notification->addNotifiaction($medicalProviderUserId);
      $notification->addNotifiaction($privateReservationUserId);
      
    }else if($sender->isDoctor() && ($notificationName=='approve_request')){
      //$doctorUser=Doctor::find($request->doctor_id);
      //$doctorUserId=$doctorUser->user_id;

      $medicalProviderUser=MedicalProvider::find($request->medical_provider_id);
      $medicalProviderUserId=$medicalProviderUser->user_id;

      $secretaryUser=Secretary::where('doctor_id',$request->doctor_id)->first();
      $secretaryUserId=0;
      if(isset($secretaryUser->user_id)&&!empty($secretaryUser->user_id)){
         $secretaryUserId=$secretaryUser->user_id;
      }

      $privateReservation= DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $request->medical_provider_id)->where('speciality_id',$specialtyId)->first();
      if(null!==$privateReservation&&null!=$privateReservation->departement_secretary_id){
        $privateReservationUser=PrivateReservation::find($privateReservation->departement_secretary_id);
        $privateReservationUserId=$privateReservationUser->user_id;
      }

      if($patientUserId>0){$notification->setnotification($senderUserId,$patientUserId,$request->id,'Approved');}

      $notification->addNotifiaction($patientUserId);
      if($doctorUserId!==$medicalProviderUserId){
        $notification->addNotifiaction($doctorUserId);
      }
      $notification->addNotifiaction($secretaryUserId);
      $notification->addNotifiaction($medicalProviderUserId);
      $notification->addNotifiaction($privateReservationUserId);

    }

    else if($sender->isSecretary() && ($notificationName=='reschedule_request')){
      //get doctor and medical provider
      $doctorUser=Doctor::find($request->doctor_id);
      $doctorUserId=$doctorUser->user_id;

      $medicalProviderUser=MedicalProvider::find($request->medical_provider_id);
      $medicalProviderUserId=$medicalProviderUser->user_id;

      $privateReservation= DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $request->medical_provider_id)->where('speciality_id',$specialtyId)->first();
      if(null!==$privateReservation&&null!=$privateReservation->departement_secretary_id){
        $privateReservationUser=PrivateReservation::find($privateReservation->departement_secretary_id);
        $privateReservationUserId=$privateReservationUser->user_id;
      }

      $notification->setnotification($senderUserId,$doctorUserId,$request->id,'Rescheduled');
      if($patientUserId>0){$notification->setnotification($senderUserId,$patientUserId,$request->id,'Rescheduled');}


      $notification->addNotifiaction($patientUserId);
      if($doctorUserId!==$medicalProviderUserId){
        $notification->addNotifiaction($doctorUserId);
      }
      $notification->addNotifiaction($secretaryUserId);
      $notification->addNotifiaction($medicalProviderUserId);
      $notification->addNotifiaction($privateReservationUserId);

    }else if($sender->isPrivateReservation() && ($notificationName=='reschedule_request')){
      //get doctor and medical provider
      $doctorUser=Doctor::find($request->doctor_id);
      $doctorUserId=$doctorUser->user_id;

      $medicalProviderUser=MedicalProvider::find($request->medical_provider_id);
      $medicalProviderUserId=$medicalProviderUser->user_id;

      $secretaryUser=Secretary::where('doctor_id',$request->doctor_id)->first();
      $secretaryUserId=0;
      if(isset($secretaryUser->user_id)&&!empty($secretaryUser->user_id)){
       $secretaryUserId=$secretaryUser->user_id;
      }

      $notification->setnotification($senderUserId,$doctorUserId,$request->id,'Rescheduled');
      if($patientUserId>0){$notification->setnotification($senderUserId,$patientUserId,$request->id,'Rescheduled');}

      $notification->addNotifiaction($patientUserId);
      if($doctorUserId!==$medicalProviderUserId){
        $notification->addNotifiaction($doctorUserId);
      }
      $notification->addNotifiaction($secretaryUserId);
      $notification->addNotifiaction($medicalProviderUserId);
      $notification->addNotifiaction($privateReservationUserId);

    }else if($sender->isOwner() && ($notificationName=='reschedule_request')){
      $doctorUser=Doctor::find($request->doctor_id);
      $doctorUserId=$doctorUser->user_id;

      $secretaryUser=Secretary::where('doctor_id',$request->doctor_id)->first();
      $secretaryUserId=0;
      if(isset($secretaryUser->user_id)&&!empty($secretaryUser->user_id)){
         $secretaryUserId=$secretaryUser->user_id;
        }

      $privateReservation= DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $request->medical_provider_id)->where('speciality_id',$specialtyId)->first();
      if(null!==$privateReservation&&null!=$privateReservation->departement_secretary_id){
        $privateReservationUser=PrivateReservation::find($privateReservation->departement_secretary_id);
        $privateReservationUserId=$privateReservationUser->user_id;
      }

      $notification->setnotification($senderUserId,$doctorUserId,$request->id,'Rescheduled');
      if($patientUserId>0){$notification->setnotification($senderUserId,$patientUserId,$request->id,'Rescheduled');}


      $notification->addNotifiaction($patientUserId);
      if($doctorUserId!==$medicalProviderUserId){
        $notification->addNotifiaction($doctorUserId);
        $doctorUserId=0;
      }
      $notification->addNotifiaction($secretaryUserId);
      $notification->addNotifiaction($medicalProviderUserId);
      $notification->addNotifiaction($privateReservationUserId);

    }else if($sender->isDoctor() && ($notificationName=='reschedule_request')){
      //$doctorUser=Doctor::find($request->doctor_id);
      //$doctorUserId=$doctorUser->user_id;

      $medicalProviderUser=MedicalProvider::find($request->medical_provider_id);
      $medicalProviderUserId=$medicalProviderUser->user_id;

      $secretaryUser=Secretary::where('doctor_id',$request->doctor_id)->first();
      $secretaryUserId=0;
      if(isset($secretaryUser->user_id)&&!empty($secretaryUser->user_id)){
         $secretaryUserId=$secretaryUser->user_id;
      }

      $privateReservation= DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $request->medical_provider_id)->where('speciality_id',$specialtyId)->first();
      if(null!==$privateReservation&&null!=$privateReservation->departement_secretary_id){
        $privateReservationUser=PrivateReservation::find($privateReservation->departement_secretary_id);
        $privateReservationUserId=$privateReservationUser->user_id;
      }

      if($patientUserId>0){$notification->setnotification($senderUserId,$patientUserId,$request->id,'Rescheduled');}

      $notification->addNotifiaction($patientUserId);
      if($doctorUserId!==$medicalProviderUserId){
        $notification->addNotifiaction($doctorUserId);
      }
      $notification->addNotifiaction($secretaryUserId);
      $notification->addNotifiaction($medicalProviderUserId);
      $notification->addNotifiaction($privateReservationUserId);

    }

    else if($notificationName=='patient_cancel_request'){
      $doctorUser=Doctor::find($request->doctor_id);
      $doctorUserId=$doctorUser->user_id;

      $medicalProviderUser=MedicalProvider::find($request->medical_provider_id);
      $medicalProviderUserId=$medicalProviderUser->user_id;

      $secretaryUser=Secretary::where('doctor_id',$request->doctor_id)->first();
      $secretaryUserId=0;
      if(isset($secretaryUser->user_id)&&!empty($secretaryUser->user_id)){
        $secretaryUserId=$secretaryUser->user_id;
      }

      $privateReservation= DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $request->medical_provider_id)->where('speciality_id',$specialtyId)->first();
      if(null!==$privateReservation&&null!=$privateReservation->departement_secretary_id){
        $privateReservationUser=PrivateReservation::find($privateReservation->departement_secretary_id);
        $privateReservationUserId=$privateReservationUser->user_id;

      }
      $notification->setnotification($senderUserId,$doctorUserId,$request->id,'Canceled');

      if($doctorUserId!==$medicalProviderUserId){
        $notification->addNotifiaction($doctorUserId);
      }
      $notification->addNotifiaction($secretaryUserId);
      $notification->addNotifiaction($medicalProviderUserId);
      $notification->addNotifiaction($privateReservationUserId);

    }else if($notificationName=='mp_cancel_request'){
      $notification->setnotification($senderUserId,$patientUserId,$request->id,'Canceled');

      $notification->addNotifiaction($patientUserId);

    }

    $recievers=array(
      "patient"=>$patientUserId,
      "doctor"=>$doctorUserId,
      "secretary"=>$secretaryUserId,
      "medical_provider"=>$medicalProviderUserId,
      "private_reservation"=>$privateReservationUserId
    );
    if($recievers['medical_provider']==$recievers['doctor']){$recievers['doctor']=0;}
    if($notificationName=='new_request' ||$notificationName=='confirm_request'  ){
        $recievers['patient']=0;
    }
    foreach($recievers AS $key=>$val){
      $body='';
      $title='';
      $type=$notificationType;
      if($key=="patient" ){
        if($val>0){
          $body=$notificationsTexts[$notificationName]['patient']['content'];
          $title=$notificationsTexts[$notificationName]['patient']['title'];
        }
      }else {
        if($val>0){
        $body=$notificationsTexts[$notificationName]['medical_provider']['content'];
        $title=$notificationsTexts[$notificationName]['medical_provider']['title'];
        }
      }

      $userPushData=Pushtoken::where('user_id',$val)->where('token','!=','')->whereNotNull('token')->get();
      $url="https://fcm.googleapis.com/fcm/send";
      $header=array("Content-Type:application/json","Authorization:key=AAAAti-43gU:APA91bETSiRFgVVPbHuL0oPltDH9MbHnLvwa_AHJ8ploclgFzzjtDa2pi_ns-AXPsX3lk1Rl8bLjMKdKRsWG9olZmKzgC432zkPQVuCRrIMHL-Qi-2hV14TmhLJH-TyhtSc9Qbcoe49J");
      if($userPushData!=NULL){
        $ch =curl_init();
            foreach($userPushData AS $userPush){
                $data='{
                "to":"'.$userPush->token.'",
                "collapse_key":"type_a",
                "notification":{
                    "body":"'.$body.'",
                    "title":"'.$title.'",
                    },
                "data":{
                    "body":"'.$body.'",
                    "title":"'.$title.'",
                    "type":"'.$type.'",
                    "name":"'.$notificationName.'"
                }
                }';

                curl_setopt($ch,CURLOPT_URL,$url);
                curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
                curl_setopt($ch,CURLOPT_POST,1);
                curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
                curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
                $output=curl_exec($ch);
            }
            curl_close($ch);
      }


    }

  }

  public static function sendDataMessage($patientUserId=0,$notificationName,$senderUserId,$requestId,$date='',$time='',$notificationType=''){
    $request=Request::find($requestId);
    $specialtyId=isset($request->doctor->speciality_id)?$request->doctor->speciality_id:0;
    // get notification recievers
    $patientUserId=0;
    $doctorUserId=0;
    $secretaryUserId=0;
    $medicalProviderUserId=0;
    $privateReservationUserId=0;

    $doctorUser=Doctor::find($request->doctor_id);
    $doctorUserId=$doctorUser->user_id;

    $patientUser=Patient::find($request->patient_id);
    $patientUserId=$patientUser->user_id;

    $medicalProviderUser=MedicalProvider::find($request->medical_provider_id);
    $medicalProviderUserId=$medicalProviderUser->user_id;

    $secretaryUser=Secretary::where('doctor_id',$request->doctor_id)->first();
    isset($secretaryUser->user_id)&&!empty($secretaryUser->user_id)? $secretaryUserId=$secretaryUser->user_id: $secretaryUserId=0;

    $privateReservation= DB::table('medical_provider_has_specialties')->where('medical_provider_id',  $request->medical_provider_id)->where('speciality_id',$specialtyId)->first();
    if(null!==$privateReservation&&null!=$privateReservation->departement_secretary_id){
      $privateReservationUser=PrivateReservation::find($privateReservation->departement_secretary_id);
      $privateReservationUserId=$privateReservationUser->user_id;
    }
    $recievers=array(
      "patient"=>$patientUserId,
      "doctor"=>$doctorUserId,
      "secretary"=>$secretaryUserId,
      "medical_provider"=>$medicalProviderUserId,
      "private_reservation"=>$privateReservationUserId
    );
    if($recievers['medical_provider']==$recievers['doctor']){$recievers['doctor']=0;}

    foreach($recievers AS $key=>$val){
      $body='';
      $title='';
      $type=$notificationType;
      if($val==0){continue;}
      $req=new \App\Request();
      $PayLoad=array();
      
      if($key=="patient"){$PayLoad=$req->get_request_data_for_patient($requestId,$patientUserId);}
      if($key=="doctor"){$PayLoad=$req->get_request_data_for_doctor($requestId,$doctorUserId);}
      if($key=="secretary"){$PayLoad=$req->get_request_data_for_doctor($requestId,$secretaryUserId,true);}
      if($key=="medical_provider"){$PayLoad=$req->get_request_data_for_provider($requestId,$medicalProviderUserId);}
      if($key=="private_reservation"){$PayLoad=$req->get_request_data_for_private_reservation($requestId,$privateReservationUserId);}
     

      event(new \App\Events\UserEvent($val,$type,$notificationName,$PayLoad));
      /*
      $userPushData=Pushtoken::where('user_id',$val)->where('token','!=','')->whereNotNull('token')->get();

      $url="https://fcm.googleapis.com/fcm/send";
      $header=array("Content-Type:application/json","Authorization:key=AAAAti-43gU:APA91bETSiRFgVVPbHuL0oPltDH9MbHnLvwa_AHJ8ploclgFzzjtDa2pi_ns-AXPsX3lk1Rl8bLjMKdKRsWG9olZmKzgC432zkPQVuCRrIMHL-Qi-2hV14TmhLJH-TyhtSc9Qbcoe49J");
      if($userPushData!=NULL){
        $ch =curl_init();
            foreach($userPushData AS $userPush){
                $data='{
                "to":"'.$userPush->token.'",
                "collapse_key":"type_a",
                
                "data":{
                    "body":"'.$body.'",
                    "title":"'.$title.'",
                    "type":"'.$type.'",
                    "name":"'.$notificationName.'"
                }
                }';

                curl_setopt($ch,CURLOPT_URL,$url);
                curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
                curl_setopt($ch,CURLOPT_POST,1);
                curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
                curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
                $output=curl_exec($ch);
            }
            curl_close($ch);
      }
      */


    }

}


public static function sendUserDataMessage($UserId=0,$notificationName='',$data=array(),$notificationType=''){

  $body='';
  $title='';
 
  $number=0;
  if($notificationName=="has_new_notifications"){
    $number=$data['notifications_number'];
  }
  if($UserId!=0){
    event(new \App\Events\UserEvent($UserId,$notificationType,$notificationName,$data));
  }
  /*
  $userPushData=Pushtoken::where('user_id',$UserId)->where('token','!=','')->whereNotNull('token')->get();
  $url="https://fcm.googleapis.com/fcm/send";
  $header=array("Content-Type:application/json","Authorization:key=AAAAti-43gU:APA91bETSiRFgVVPbHuL0oPltDH9MbHnLvwa_AHJ8ploclgFzzjtDa2pi_ns-AXPsX3lk1Rl8bLjMKdKRsWG9olZmKzgC432zkPQVuCRrIMHL-Qi-2hV14TmhLJH-TyhtSc9Qbcoe49J");
  if($userPushData!=NULL){
    $ch =curl_init();
        foreach($userPushData AS $userPush){
            $data='{
            "to":"'.$userPush->token.'",
            
            "data":{
                "body":"'.$body.'",
                "title":"'.$title.'",
                "type":"'.$notificationType.'",
                "name":"'.$notificationName.'",
                "number":"'.$number.'"
            }
            }';

            curl_setopt($ch,CURLOPT_URL,$url);
            curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
            curl_setopt($ch,CURLOPT_POST,1);
            curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
            curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
            $output=curl_exec($ch);
        }
        curl_close($ch);
  }
*/
}
  public static function sendReminder($requestId,$userId,$notificationName){
      $request = \App\Request::find($requestId);
      $user = User::find($userId);

      $userTimeZone=($user->user_time_zone!=null)?$user->user_time_zone:'UTC';
      $time_from=new \DateTimeZone('UTC');
      $time_to=new \DateTimeZone($userTimeZone);

      $originTime=new \DateTime($request->date." ".$request->time,$time_from);
      $newTime= $originTime->setTimezone($time_to);


      $date=$newTime->format('Y-m-d');
      $time=$newTime->format('H:i:s');

      \App::setLocale($user->lang);
      $jobTitle='';
      $medical_provider_name='';
      $patientName=$request->patient->user->name ;
      $doctorName="";
      if($user->lang=='ar') {
          $doctorName = $request->doctor->user->fullname ;
          $jobTitle=$request->doctor->jobTitle->name_ar ;
          $medical_provider_name=$request->medical_provider->user->fullname;
      }
      else {
          $doctorName = $request->doctor->user->fullname_en;
          $jobTitle=$request->doctor->jobTitle->name_en ;
          $medical_provider_name=$request->medical_provider->user->fullname_en;
      }
      $notificationData=array();
      if($notificationName=='2_hours_after'||$notificationName=='patient_arrive_patient'){
        $notificationData=array(
          "request_id"=>$request->id,
          "doctor_name"=>$doctorName,
          "specialty_name"=> $jobTitle,
          "date"=>$date,
          "time"=>$time,
          "appointment_id"=>$request->appointments->id,
          "medical_provider_name"=>$medical_provider_name,
        );
      }
     $notificationsTexts=array(
      "4_days_before"=>array(
      "title"=>__('notifications.reminder'),"content"=>__('notifications.reminder_4_days_before' , ['doctorName' => $doctorName ])
      ),
      "1_day_before"=>array(
        "title"=>__('notifications.reminder'),"content"=>__('notifications.reminder_1_days_before' ,['doctorName' => $doctorName ])
      ),
      "3_hours_before"=>array(
        "title"=>__('notifications.reminder'),"content"=>__('notifications.reminder_3_hours_before' ,['doctorName' => $doctorName ])
      ),
      "1_hour_before"=>array(
        "title"=>__('notifications.reminder'),"content"=>__('notifications.reminder_1_hour_before' , ['doctorName' => $doctorName ])
      ),
      "patient_arrive_patient"=>array(
        "title"=>__('notifications.reminder'),"content"=>__('notifications.patient_arrive_patient',['doctorName'=>$doctorName])
      ),
      "patient_arrive_mp"=>array(
        "title"=>__('notifications.reminder'),"content"=>__('notifications.patient_arrive_mp',['patientName'=>$patientName])
      ),
      "2_hours_after"=>array(
        "title"=>__('notifications.reminder'),"content"=>__('notifications.reminder_2_hour_after' , ['doctorName' => $doctorName ])
      ),
    );


    $userPushData=Pushtoken::where('user_id',$userId)->where('token','!=','')->whereNotNull('token')->get();

    $url="https://fcm.googleapis.com/fcm/send";


     $header=array("Content-Type:application/json","Authorization:key=AAAAti-43gU:APA91bETSiRFgVVPbHuL0oPltDH9MbHnLvwa_AHJ8ploclgFzzjtDa2pi_ns-AXPsX3lk1Rl8bLjMKdKRsWG9olZmKzgC432zkPQVuCRrIMHL-Qi-2hV14TmhLJH-TyhtSc9Qbcoe49J");

      $ch =curl_init();
      foreach($userPushData AS $pushData){
        if($notificationName=='2_hours_after' ||$notificationName=='patient_arrive_patient'){
          $data='{
            "to":"'.$pushData->token.'",
            "collapse_key":"type_a",
            "notification":{
              "body":"'.$notificationsTexts[$notificationName]['content'].'",
              "title":"'.$notificationsTexts[$notificationName]['title'].'",
              },
              "data":{
                "body":"'.$notificationsTexts[$notificationName]['content'].'",
                "title":"'.$notificationsTexts[$notificationName]['title'].'",
                "type":"'.$notificationName.'",
                "name":"'.$notificationName.'",
                "notificationData":{
                  "request_id":"'.$notificationData['request_id'].'",
                  "doctor_name":"'.$notificationData['doctor_name'].'",
                  "specialty_name":"'.$notificationData['specialty_name'].'",
                  "date":"'.$notificationData['date'].'",
                  "time":"'.$notificationData['time'].'",
                  "appointment_id":"'.$notificationData['appointment_id'].'",
                  "medical_provider_name":"'.$notificationData['medical_provider_name'].'",
                }
              },
              "content_available":true
          }';
        }else{
          $data='{
            "to":"'.$pushData->token.'",
            "collapse_key":"type_a",
            "notification":{
              "body":"'.$notificationsTexts[$notificationName]['content'].'",
              "title":"'.$notificationsTexts[$notificationName]['title'].'",
              },
              "data":{
                "body":"'.$notificationsTexts[$notificationName]['content'].'",
                "title":"'.$notificationsTexts[$notificationName]['title'].'",
                "type":"'.$notificationName.'",
                "name":"'.$notificationName.'",
                "notificationData":""
              },
              "content_available":true
          }';
        }


        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_POST,1);
        curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
        curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
        $output=curl_exec($ch);

      }
      curl_close($ch);



  }
}
