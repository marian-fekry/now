<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */

    'accepted'             => 'ال:attribute يجب الموافقة على',
    'active_url'           => 'ال:attribute غير صحيح',
    'after'                => 'ال:attribute التاريخ يجب ان يكون بعد :date.',
    'after_or_equal'       => 'ال:attribute التاريخ يجب ان يكون بعد او يساوي :date.',
    'alpha'                => 'ال:attribute يجب ان يحتوي على احروف فقط',
    'alpha_dash'           => 'ال:attribute يجب ان يحتوي فقط على أحرف وأرقام وشرطات',
    'alpha_num'            => 'ال:attribute يجب ان يحتوي على احرف وارقام فقط',
    'array'                => 'ال:attribute يجب أن يكون مجموعة',
    'before'               => 'ال:attribute التاريخ يجب ان يكون قبل :date.',
    'before_or_equal'      => 'ال:attribute التاريخ يجب ان يكون قبل او يساوي :date.',
    'between'              => [
        'numeric' => 'ال:attribute must be between :min and :max.',
        'file'    => 'ال:attribute must be between :min and :max kilobytes.',
        'string'  => 'ال:attribute must be between :min and :max characters.',
        'array'   => 'ال:attribute must have between :min and :max items.',
    ],
    'boolean'              => 'ال:attribute يجب أن يكون صواب أو خطأ',
    'confirmed'            => 'تاكيد :attribute غير متطابق',
    'date'                 => 'ال:attribute ليس تاريخ صحيح',
    'date_format'          => 'ال:attribute لا يطابق صيغة التاريخ :format.',
    'different'            => 'ال:attribute and :other must be different.',
    'digits'               => 'ال:attribute must be :digits digits.',
    'digits_between'       => 'ال:attribute must be between :min and :max digits.',
    'dimensions'           => 'ال:attribute ابعاد الصورة غير صحيح',
    'distinct'             => 'ال:attribute field has a duplicate value.',
    'email'                => 'ال:attribute يجب أن يكون عنوان بريد إلكتروني صحيح',
    'exists'               => 'الselected :attribute is invalid.',
    'file'                 => 'ال:attribute يجب ان يكون ملفا',
    'filled'               => 'ال:attribute يجب أن يكون له قيمة',
    'gt'                   => [
        'numeric' => 'ال:attribute must be greater than :value.',
        'file'    => 'ال:attribute must be greater than :value kilobytes.',
        'string'  => 'ال:attribute must be greater than :value characters.',
        'array'   => 'ال:attribute must have more than :value items.',
    ],
    'gte'                  => [
        'numeric' => 'ال:attribute must be greater than or equal :value.',
        'file'    => 'ال:attribute must be greater than or equal :value kilobytes.',
        'string'  => 'ال:attribute must be greater than or equal :value characters.',
        'array'   => 'ال:attribute must have :value items or more.',
    ],
    'image'                => 'ال:attribute يجب أن تكون صورة',
    'in'                   => 'الselected :attribute is invalid.',
    'in_array'             => 'ال:attribute غير موجود في :other.',
    'integer'              => 'ال:attribute يجب ان يكون رقما',
    'ip'                   => 'ال:attribute must be a valid IP address.',
    'ipv4'                 => 'ال:attribute must be a valid IPv4 address.',
    'ipv6'                 => 'ال:attribute must be a valid IPv6 address.',
    'json'                 => 'ال:attribute must be a valid JSON string.',
    'lt'                   => [
        'numeric' => 'ال:attribute must be less than :value.',
        'file'    => 'ال:attribute must be less than :value kilobytes.',
        'string'  => 'ال:attribute must be less than :value characters.',
        'array'   => 'ال:attribute must have less than :value items.',
    ],
    'lte'                  => [
        'numeric' => 'ال:attribute must be less than or equal :value.',
        'file'    => 'ال:attribute must be less than or equal :value kilobytes.',
        'string'  => 'ال:attribute must be less than or equal :value characters.',
        'array'   => 'ال:attribute must not have more than :value items.',
    ],
    'max'                  => [
        'numeric' => 'ال:attribute may not be greater than :max.',
        'file'    => 'ال:attribute may not be greater than :max kilobytes.',
        'string'  => 'ال:attribute may not be greater than :max characters.',
        'array'   => 'ال:attribute may not have more than :max items.',
    ],
    'mimes'                => 'ال:attribute must be a file of type: :values.',
    'mimetypes'            => 'ال:attribute must be a file of type: :values.',
    'min'                  => [
        'numeric' => 'ال:attribute يجب على الاقل ان تكون :min.',
        'file'    => 'ال:attribute must be at least :min kilobytes.',
        'string'  => 'ال:attribute يجب على الاقل ان تكون :min احرف.',
        'array'   => 'ال:attribute must have at least :min items.',
    ],
    'not_in'               => 'الselected :attribute is invalid.',
    'not_regex'            => 'ال:attribute غير صحيح',
    'numeric'              => 'ال:attribute يجب أن يكون رقما',
    'present'              => 'ال:attribute يجب ان يكون فى المستقبل.',
    'regex'                => 'ال:attribute غير صحيح',
    'required'             => ' يجب ادخال :attribute',
    'required_if'          => 'ال:attribute field is required when :other is :value.',
    'required_unless'      => 'ال:attribute field is required unless :other is in :values.',
    'required_with'        => 'ال:attribute مطلوب  مع :values is present.',
    'required_with_all'    => 'ال:attribute field is required when :values is present.',
    'required_without'     => 'ال:attribute field is required when :values is not present.',
    'required_without_all' => 'ال:attribute مطلوب :values are present.',
    'same'                 => 'ال:attribute and :other must match.',
    'size'                 => [
        'numeric' => 'ال:attribute must be :size.',
        'file'    => 'ال:attribute must be :size kilobytes.',
        'string'  => 'ال:attribute must be :size characters.',
        'array'   => 'ال:attribute must contain :size items.',
    ],
    'string'               => 'ال:attribute يجب ان تكون كلمة.',
    'timezone'             => 'ال:attribute must be a valid zone.',
    'unique'               => 'ال:attribute مستخدم من قبل.',
    'uploaded'             => 'ال:attribute فشل فى التحميل',
    'url'                  => 'ال:attribute الرابط غير صحيح',

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | Here you may specify custom validation messages for attributes using the
    | convention "attribute.rule" to name the lines. This makes it quick to
    | specify a specific custom language line for a given attribute rule.
    |
    */

    'custom' => [
        'max_price' => [
            'required_with' => 'من فضلك ادخل الحد الاقصي',
        ],
        'min_price' => [
            'required_with' => 'من فضلك ادخل الحد الادني',
        ],
        'region' => [
            'required_if' => 'يجب ادخال المنطقة.',
        ],
        'governrate' => [
            'required_if' => 'يجب ادخال المحافظة.',
        ],
        'specialties.*.speciality_id' => [
            'numeric'=>'يجب ادخال التخصص'
        ],
        'specialties.*.speciality_id' => [
            'numeric'=>'يجب ادخال التخصص'
        ],
        'specialties.*.services.*.service_id' => [
            'required_with'=>'يجب ادخال الخدمة'
        ],
        'specialties.*.services.*.service_price' => [
            'required_with'=>'يجب ادخال سعر الخدمة',
            'numeric'=>'يجب ادخال سعر الخدمة بالارقام الانجليزية',
        ],
        'doctors' => [
            'required_without_all'=>'يجب ادخال بيانات الدكتور'
        ],
        'doctors.*.doctor_speciality_id' => [
            'required_with'=>'يجب ادخال تخصص الدكتور'
        ],
        'doctors.*.secretary_name' => [
            'required_with'=>'يجب ادخال اسم السكرتيرة'
        ],
        'doctors.*.secretary_email' => [
            'required_with'=>'يجب ادخال البريد الالكتروني للسكرتيرة'
        ],
        'specialties.*.private_reservation_email' => [
            'required_with'=>'بريد الالكتروني غير صحيح'
        ],
        'specialties.*.services.*.service_id' => [
            'required_with'=>'يجب ادخال الخدمة'
        ],
        'specialties.*.services.*.service_price' => [
            'required_with'=>'يجب ادخال سعر الخدمة'
        ],
        'doctors.*.doctor_email' => [
            'required_with'=>'يجب ادخال البريد الالكتروني للدكتور'
        ],
        'doctors.*.doctor_email' => [
            'email'=>'بريد الالكتروني غير صحيح'
        ],
        'doctors.*.doctor_speciality_id' => [
            'required_with'=>'يجب ادخال تخصص للدكتور'
        ],
        'doctors.*.secretary_name' => [
            'required_with'=>'يجب ادخال اسم السكرتيرة'
        ],
        'doctors.*.secretary_email' => [
            'required_with'=>'يجب ادخال بريد الالكترونى للسكرتيرة.'
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Attributes
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to swap attribute place-holders
    | with something more reader friendly such as E-Mail Address instead
    | of "email". This simply helps us make messages a little cleaner.
    |
    */

    'attributes' => [
        "medical_id"=>"مقدم الخدمة",
        "speciality_id"=>"التخصص",
        'doctor_id' => 'الدكتور',
        'doctor_name' => 'اسم الدكتور',
        'provider_id'=>'مقدم الخدمة',
        'date'=>'اليوم',
        'time'=>'الوقت',
        'request_id'=>'رقم الطلب',
        'respond'=>'الرد',
        'min_price'=>'السعر الاقصي',
        'min_price'=>'السعر الادني',
        'request_time'=>'الوقت',
        'email'=>'بريد الالكترونى',
        'name_en'=>'الاسم بالانجليزية',
        'name'=>'الاسم',
        'specialty'=>'التخصص',
        'jobtitle'=>'اللقب',
        'degree'=>'اللقب',
        'region'=>'المنطقة',
        'governrate'=>'المحافظة',
        'service'=>'الخدمة',
        'request_date'=>'يوم الطلب',
        'request_time'=>'ساعة الطلب',
        'brief'=>'وصف',
        'governerte_id'=>'المحافظة',
        'degree'=>'اللقب',
        'type'=>'النوع',
        'specialties.*.speciality_id'=>'التخصص',
        'specialties.*.services.*.service_id'=>'الخدمة',
        'specialties.*.services.*.service_price'=>'سعر الخدمة',
        'doctors.*.secretary_name'=>'اسم سكرتيرة الدكتور',
        'doctors.*.secretary_email'=>'بريد الالكتروني للسكرتيرة',
        'specialties.*.private_reservation_email'=>'بريد الالكتروني لقسم الحجز التخصص',
        'doctors.*.doctor_speciality_id'=>'تخصص الدكتور',
        'mobile'=>'رقم الجوال',
        'birthdate'=>'تاريخ الميلاد',
        'gender'=>'النوع',
        'appointment_id'=>'رقم الطلب',
        'rate'=>'التقييم',
        'comment'=>'التعليق',
        'speciality'=>'التخصص',
        'image'=>'الصورة',
        'password'=>'كلمة المرور',
        'newPassword'=>'كلمة المرور الجديدة',
        "password_confirmation"=>"تأكيد كلمة المرور",
        "fullName"=>"الاسم بالكامل",
    ],

];
