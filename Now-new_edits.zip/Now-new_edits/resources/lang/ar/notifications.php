<?php

return [
      "new_request_title"                      =>"طلب زيارة جديد",
      "new_request_content_patient"          =>"New Request Content Patient",
      "new_request_content_mp"                 =>"New Request Content Medical provider",
      "reminder"                              => "تذكير",
      "reminder_4_days_before"                        =>"لديك زيارة مع :doctorName بعد 4 ايام",
      "reminder_1_days_before"                          => "لديك زيارة مع :doctorName بعد يوم",
      "reminder_3_hours_before"                          => "لديك زيارة مع :doctorName بعد ثلاث ساعات",
      "reminder_1_hour_before"                        =>"لديك زيارة مع :doctorName بعد ساعة واحدة",
      "patient_arrive"                        =>"هل وصلت ؟",
      "reminder_2_hour_after"                        =>"من فضلك ادخل تقييمك لزيارة الدكتور :doctorName ",
       "new_request"                                  => "طلب زيارة جديدة",
      "new_request_content_mp"                        => ":patientName أرسل لك طلب زيارة جديد",
     "approve_request"                                => "موافقة على طلب زيارة",
    "approve_request_content_patient"                                => ":senderName وافق على طلب زيارتك",
    "approve_request_content_mp"                                => ":senderName وافق على طلب زيارة :patientName",
    "cancel_request"                                            =>"الغاء موعد",
    "cancel_request_content_mp"                          =>"تم الغاء موعد زيارة :patientName يوم :date الساعه :time",
    "cancel_request_content_patient"                     =>":senderName الغي موعد الزيارة للمريض :patientName يوم :date الساعه :time",

    "confirm_request"                                    => "تاكيد موعد" ,
    "confirm_request_content_mp"                       =>"تم تاكيد موعد زيارة :patientName يوم :date الساعه :time",
     "reschedule_request_title"                         => "اقتراح موعد اخر",
    "reschedule_request_content_patient"               =>":doctorName اقترح موعد جديد لزيارتك يوم :date الساعه :time",
    "reschedule_request__content_mp"              =>":senderName اقترح موعد جديد لزيارة :patientName يوم :date الساعه :time" ,
    
    "patient_arrive_patient"                             => "هل وصلت للطبيب :doctorName؟",
    "patient_arrive_mp"                             => "وصل المريض :patientName",
    "patient_arrive_content_mp"                             => ":patientName وصل ومستعد للزيارة",
    "reschedule_request_content_mp"                =>":medicalProviderName اقترح موعد جديد لزيارة :patientName يوم :date الساعه :time",
    "reschedule_request_content_secretary"        =>":secretaryName اقترح موعد جديد لزيارة :patientName يوم :date الساعه :time",

];
