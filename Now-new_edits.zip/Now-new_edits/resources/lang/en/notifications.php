<?php

return [
      "new_request_title"                      =>"New Request",
      "new_request_content_patient"          =>"New Request Content Patient",
      "new_request_content_mp"                 =>"New Request Content Medical provider",
       "reminder"                              => "Reminder",
      "reminder_4_days_before"                        =>"You have an appointment with :doctorName after 4 days",
      "reminder_1_days_before"                        =>"You have an appointment with :doctorName after 1 day",
      "reminder_3_hours_before"                        =>"You have an appointment with :doctorName after 3 hours ",
      "reminder_1_hour_before"                        =>"You have an appointment with :doctorName after 1 hour ",
      "patient_arrive"                                =>"Did You Arrive ? ",
      "reminder_2_hour_after"                        =>"please enter evaluate your visit with :doctorName",
       "new_request"                                  => "New Request",
       "new_request_content_mp"                        => ":patientName has sent you a new request",
       "approve_request"                                => "Approve Request",
    "approve_request_content_patient"                                => ":senderName has accepted your request",
    "approve_request_content_mp"                                => ":senderName has accepted :patientName request",
    "cancel_request"                                            =>"Cancel Request",
    "cancel_request_content_mp"                          =>":patientName has cancelled the request at  :date  :time",
    "cancel_request_content_patient"                          =>":senderName cancel request of :patientName  at :date  :time",

    "confirm_request"                                    => "Confirm Request " ,
    "confirm_request_content_mp"                       =>":patientName has confirmed request at  :date  :time",
    "reschedule_request_title"                         => "Reschedule Request",
    "reschedule_request_content_patient"               =>":doctorName has rescheduled your request on :date at :time",
    "reschedule_request_content_mp"              =>":senderName has rescheduled :patientName request on :date at :time" ,
    "patient_arrive_patient"                             => "Are you arrived at :doctorName",
    "patient_arrive_mp"                             => "patient :patientName has arrived",
    "patient_arrive_content_mp"                             => ":patientName has arrived and ready for the visit",
    "reschedule_request_content_secretary"        =>":secretaryName اقترح موعد جديد لزيارة :patientName يوم :date الساعه :time",

];
